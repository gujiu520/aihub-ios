#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
  printf '%s\n' 'This build requires macOS with the full Xcode iOS SDK installed.' >&2
  exit 1
fi
BUILD_ROOT="$PWD/build"
PRODUCT="$BUILD_ROOT/Build/Products/Release-iphoneos/AIHub.app"
STAGING="$BUILD_ROOT/package"
mkdir -p "$BUILD_ROOT"
xcodebuild -project AIHub.xcodeproj -scheme AIHub -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath "$BUILD_ROOT" CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
test -d "$PRODUCT"
test -x "$PRODUCT/AIHub"
/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$PRODUCT/Info.plist"
xcrun lipo -verify_arch arm64 "$PRODUCT/AIHub"
mkdir -p "$STAGING/Payload"
ditto "$PRODUCT" "$STAGING/Payload/AIHub.app"
# A real arm64 app is packaged; TrollStore handles installation signing on a supported device.
ditto -c -k --keepParent "$STAGING/Payload" "$BUILD_ROOT/AIHub-1.0.0-arm64-unsigned.ipa"
unzip -t "$BUILD_ROOT/AIHub-1.0.0-arm64-unsigned.ipa"
shasum -a 256 "$BUILD_ROOT/AIHub-1.0.0-arm64-unsigned.ipa"
printf '\nIPA: %s\n' "$BUILD_ROOT/AIHub-1.0.0-arm64-unsigned.ipa"
