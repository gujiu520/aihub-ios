import SwiftUI
import UIKit

private enum HubStyle {
    static let background = Color(uiColor: .systemBackground)
    static let grouped = Color(uiColor: .systemGroupedBackground)
    static let secondary = Color(uiColor: .secondarySystemGroupedBackground)
    static let accent = Color.accentColor
}

private struct EditorTarget: Identifiable {
    let id = UUID()
    var model: ModelConfiguration?
    var requiresAPIKey = false
}

@MainActor
struct ChatRootView: View {
    @EnvironmentObject private var store: ModelStore
    @State private var messages: [ChatMessage] = []
    @State private var draft = ""
    @State private var isSending = false
    @State private var failure: String?
    @State private var showModels = false
    @State private var showSettings = false
    @State private var showCatalogKey = false
    @State private var editor: EditorTarget?
    @FocusState private var composerFocused: Bool

    var body: some View {
        NavigationStack {
            Group {
                if messages.isEmpty { emptyState }
                else { conversation }
            }
            .background(HubStyle.background)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { showSettings = true } label: {
                        Image(systemName: "sidebar.left").frame(width: 34, height: 36)
                    }.accessibilityLabel("设置与开发者信息")
                }
                ToolbarItem(placement: .principal) {
                    Button { composerFocused = false; showModels = true } label: {
                        HStack(spacing: 8) {
                            ServiceLogo(logo: store.selectedModel?.resolvedLogo ?? .custom, size: 23)
                            Text(store.selectedModel?.name ?? "选择模型")
                                .font(.system(size: 16, weight: .semibold)).lineLimit(1)
                            Image(systemName: "chevron.down").font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
                        }
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 12).frame(height: 42)
                        .background(.thinMaterial, in: Capsule())
                        .frame(maxWidth: 245)
                    }.buttonStyle(.plain).accessibilityLabel("切换模型，当前为 \(store.selectedModel?.name ?? "未选择")")
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { messages = []; draft = ""; failure = nil } label: {
                        Image(systemName: "square.and.pencil").frame(width: 34, height: 36)
                    }.disabled(isSending).accessibilityLabel("新建对话")
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .safeAreaInset(edge: .bottom, spacing: 0) { composer }
            .sheet(isPresented: $showModels) { ModelPickerView().environmentObject(store) }
            .sheet(isPresented: $showSettings) { SettingsView().environmentObject(store) }
            .sheet(isPresented: $showCatalogKey) { OpenRouterKeyView().environmentObject(store) }
            .sheet(item: $editor) { ModelEditorView(model: $0.model).environmentObject(store) }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 35)
            ServiceLogo(logo: store.selectedModel?.resolvedLogo ?? .custom, size: 58)
                .padding(.bottom, 22)
            Text("有什么想聊的？").font(.system(size: 29, weight: .semibold)).tracking(-0.8)
            Text("写下问题，或试试下面的灵感。")
                .font(.system(size: 15)).foregroundStyle(.secondary).padding(.top, 10)
            Spacer(minLength: 35)
            VStack(spacing: 2) {
                prompt("把想法写清楚", symbol: "text.alignleft", text: "帮我把这个想法表达得更清楚：")
                prompt("帮我理一理", symbol: "lightbulb", text: "帮我梳理这件事的思路：")
                prompt("随便聊聊", symbol: "bubble.left", text: "推荐一个轻松又有趣的聊天话题。")
            }.padding(.horizontal, 32).padding(.bottom, 10)
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func prompt(_ title: String, symbol: String, text: String) -> some View {
        Button {
            draft = text
            composerFocused = true
        } label: {
            HStack(spacing: 13) {
                Image(systemName: symbol).font(.system(size: 17)).foregroundStyle(HubStyle.accent).frame(width: 23)
                Text(title).font(.system(size: 15)).foregroundStyle(.primary)
                Spacer()
                Image(systemName: "arrow.up.left").font(.system(size: 12)).foregroundStyle(.tertiary)
            }.frame(minHeight: 46).contentShape(Rectangle())
        }.buttonStyle(.plain)
    }

    private var conversation: some View {
        ScrollViewReader { reader in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 24) {
                    ForEach(messages) { message in
                        HStack(alignment: .top) {
                            if message.role == .user { Spacer(minLength: 35) }
                            Text(message.content)
                                .font(.system(size: 17)).lineSpacing(5).textSelection(.enabled)
                                .padding(message.role == .user ? 15 : 0)
                                .background(message.role == .user ? HubStyle.accent.opacity(0.10) : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                                .frame(maxWidth: .infinity, alignment: message.role == .user ? .trailing : .leading)
                            if message.role != .user { Spacer(minLength: 5) }
                        }.id(message.id)
                    }
                    if isSending {
                        HStack(spacing: 10) { ProgressView(); Text("正在回复…").font(.system(size: 14)).foregroundStyle(.secondary) }
                            .id("waiting")
                    }
                }.padding(.horizontal, 23).padding(.top, 18).padding(.bottom, 22)
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: messages.count) { _ in
                if let id = messages.last?.id { withAnimation { reader.scrollTo(id, anchor: .bottom) } }
            }
            .onChange(of: isSending) { waiting in
                if waiting { withAnimation { reader.scrollTo("waiting", anchor: .bottom) } }
            }
        }
    }

    private var composer: some View {
        VStack(spacing: 7) {
            if let failure {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.circle").foregroundStyle(.red)
                    Text(failure).font(.system(size: 13)).foregroundStyle(.secondary).textSelection(.enabled)
                    Spacer(minLength: 0)
                    Button { self.failure = nil } label: { Image(systemName: "xmark").font(.system(size: 11)) }
                        .accessibilityLabel("关闭错误提示").frame(width: 30, height: 30)
                }.padding(12).background(Color.red.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
            }
            HStack {
                Circle().fill(Color.secondary.opacity(0.6)).frame(width: 5, height: 5)
                Text(connectionLabel).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                Spacer(minLength: 5)
                Button(store.selectedModel?.isFreeCatalog == true ? "配置 Key" : "API 配置") { configureCurrentModel() }
                    .font(.system(size: 12, weight: .medium)).frame(minHeight: 35)
            }.padding(.horizontal, 7)
            HStack(alignment: .bottom, spacing: 9) {
                TextField("发消息…", text: $draft, axis: .vertical)
                    .font(.system(size: 17)).lineLimit(1...5)
                    .focused($composerFocused).padding(.vertical, 11)
                Button { send() } label: {
                    Group { if isSending { ProgressView().tint(HubStyle.background) } else { Image(systemName: "arrow.up").font(.system(size: 20, weight: .semibold)) } }
                        .frame(width: 43, height: 43).foregroundStyle(HubStyle.background)
                        .background(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSending ? Color.secondary.opacity(0.4) : HubStyle.accent, in: Circle())
                }.disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSending)
                    .accessibilityLabel("发送消息")
            }
            .padding(.leading, 17).padding(.trailing, 9).padding(.vertical, 9)
            .background(HubStyle.secondary, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.primary.opacity(0.09), lineWidth: 0.8))
        }.padding(.horizontal, 16).padding(.top, 3).padding(.bottom, 10).background(HubStyle.background)
    }

    private var connectionLabel: String {
        guard let model = store.selectedModel else { return "选择或添加一个模型" }
        if model.isFreeCatalog { return "OpenRouter · 目录标价为零" }
        return "\(model.apiProtocol.title) · 自定义连接"
    }

    private func configureCurrentModel() {
        composerFocused = false
        if let model = store.selectedModel, model.isFreeCatalog { showCatalogKey = true }
        else { editor = EditorTarget(model: store.selectedModel) }
    }

    private func send() {
        let content = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !content.isEmpty, !isSending else { return }
        guard let model = store.selectedModel else { showModels = true; return }
        let key = store.key(for: model)
        if model.isFreeCatalog && key.isEmpty { showCatalogKey = true; return }
        let userMessage = ChatMessage(role: .user, content: content)
        messages.append(userMessage)
        let requestMessages = messages
        draft = ""
        failure = nil
        isSending = true
        composerFocused = false
        Task {
            do {
                let reply = try await ChatClient.send(messages: requestMessages, model: model, key: key)
                messages.append(ChatMessage(role: .assistant, content: reply))
            } catch {
                messages.removeAll { $0.id == userMessage.id }
                if draft.isEmpty { draft = content }
                failure = error.localizedDescription
            }
            isSending = false
        }
    }
}

@MainActor
struct ModelPickerView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var filter = 0
    @State private var editor: EditorTarget?

    private var visibleModels: [ModelConfiguration] {
        store.allModels.filter { model in
            let matchesFilter = filter == 0 || (filter == 1 && !model.isFreeCatalog) || (filter == 2 && model.isFreeCatalog)
            return matchesFilter && (query.isEmpty || (model.name + " " + model.modelID).localizedCaseInsensitiveContains(query))
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("模型筛选", selection: $filter) {
                        Text("全部").tag(0); Text("我的模型").tag(1); Text("免费目录").tag(2)
                    }.pickerStyle(.segmented).listRowBackground(Color.clear).listRowInsets(EdgeInsets())
                }
                Section {
                    if visibleModels.isEmpty {
                        VStack(alignment: .leading, spacing: 9) {
                            Text(query.isEmpty ? "还没有模型" : "没有找到模型").font(.headline)
                            Text(query.isEmpty ? "添加自己的 API，或刷新免费模型目录。" : "试试模型名称或完整模型 ID。")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }.padding(.vertical, 12)
                    }
                    ForEach(visibleModels) { model in
                        HStack(spacing: 8) {
                            Button {
                                store.selectedID = model.id
                                dismiss()
                            } label: {
                                HStack(spacing: 12) {
                                    ServiceLogo(logo: model.resolvedLogo, size: 28).frame(width: 38, height: 42)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(model.name).font(.system(size: 16, weight: .medium)).foregroundStyle(.primary).lineLimit(1)
                                        Text(model.isFreeCatalog ? "OpenRouter · 目录标价为零" : model.modelID)
                                            .font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(minLength: 3)
                                    if store.selectedID == model.id { Image(systemName: "checkmark").font(.system(size: 15, weight: .semibold)).foregroundStyle(HubStyle.accent) }
                                }.contentShape(Rectangle()).frame(minHeight: 48)
                            }.buttonStyle(.plain)
                            if !model.isFreeCatalog {
                                Button { editor = EditorTarget(model: model) } label: {
                                    Image(systemName: "slider.horizontal.3").font(.system(size: 16)).frame(width: 40, height: 44)
                                }.buttonStyle(.borderless).accessibilityLabel("配置 \(model.name)")
                            }
                        }
                    }
                } footer: {
                    Text("免费目录仅收录接口目录中输入、输出标价均为零的模型。实际额度与可用性由服务商决定。")
                }
                Section {
                    Button { editor = EditorTarget(model: nil) } label: { Label("添加自定义模型", systemImage: "plus") }
                    NavigationLink { PresetPickerView().environmentObject(store) } label: {
                        Label("推荐模型预设", systemImage: "square.grid.2x2")
                    }
                    Button {
                        Task { await store.refreshFreeModels(force: true) }
                    } label: {
                        HStack { Label("刷新免费模型", systemImage: "arrow.clockwise"); Spacer(); if store.isRefreshing { ProgressView() } }
                    }.disabled(store.isRefreshing)
                    if let error = store.discoveryError { Text(error).font(.footnote).foregroundStyle(.red).textSelection(.enabled) }
                }
                OfficialWebExperienceSection()
            }
            .navigationTitle("选择模型").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索模型或 ID")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .sheet(item: $editor) { ModelEditorView(model: $0.model).environmentObject(store) }
        }
    }
}

@MainActor
private struct PresetPickerView: View {
    @EnvironmentObject private var store: ModelStore
    @State private var query = ""
    @State private var editor: EditorTarget?

    private func presets(in category: String) -> [ModelPreset] {
        PresetCatalog.all.filter { item in
            item.category == category && (query.isEmpty || (item.name + " " + item.provider + " " + item.modelID).localizedCaseInsensitiveContains(query))
        }
    }

    var body: some View {
        List {
            if PresetCatalog.all.isEmpty {
                Section { Text("预设目录暂不可用，你仍可添加自定义模型。").foregroundStyle(.secondary) }
            }
            presetSection("大型旗舰", category: "large", caption: "这些旗舰模型按量计费，需要对应服务商的个人 Key。添加前请核对服务商当前价格和账号权限。")
            presetSection("国内免费 API", category: "domestic-free", caption: "免费标价核实于 2026-11-21，仍需个人 Key，并受官方限流和账号条件约束。选择后会预填模型和地址，不会自动发起请求。")
            OfficialWebExperienceSection()
        }
        .navigationTitle("推荐模型").navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, prompt: "搜索模型或服务商")
        .sheet(item: $editor) { target in
            ModelEditorView(model: target.model, requiresAPIKey: target.requiresAPIKey).environmentObject(store)
        }
    }

    private func presetSection(_ title: String, category: String, caption: String) -> some View {
        Section {
            ForEach(presets(in: category)) { preset in
                Button {
                    editor = EditorTarget(model: preset.makeConfiguration(), requiresAPIKey: preset.requiresKey)
                } label: {
                    HStack(alignment: .top, spacing: 12) {
                        ServiceLogo(logo: preset.logo, size: 28).frame(width: 35, height: 39)
                        VStack(alignment: .leading, spacing: 5) {
                            Text(preset.name).font(.system(size: 16, weight: .medium)).foregroundStyle(.primary)
                            Text(preset.provider).font(.system(size: 12)).foregroundStyle(.secondary)
                            Text(preset.note).font(.system(size: 12)).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "plus.circle").font(.system(size: 19)).padding(.top, 8)
                    }.padding(.vertical, 6)
                }.buttonStyle(.plain)
            }
        } header: { Text(title) } footer: { Text(caption) }
    }
}

private struct OfficialWebExperienceSection: View {
    var body: some View {
        Section {
            officialLink("DeepSeek", url: "https://chat.deepseek.com/", logo: .deepseek)
            officialLink("千问", url: "https://www.qianwen.com/", logo: .qwen)
            officialLink("智谱清言", url: "https://chatglm.cn/", logo: .glm)
        } header: { Text("免 Key 官方体验") } footer: {
            Text("在官方网页使用，可能需要账号登录，额度以官方为准。与 App 内 API 聊天独立。")
        }
    }

    private func officialLink(_ name: String, url: String, logo: ModelLogo) -> some View {
        Link(destination: URL(string: url)!) {
            HStack(spacing: 12) {
                ServiceLogo(logo: logo, size: 23).frame(width: 30)
                Text(name).foregroundStyle(.primary)
                Spacer()
                Image(systemName: "arrow.up.right").font(.system(size: 12)).foregroundStyle(.secondary)
            }.frame(minHeight: 35)
        }
    }
}

@MainActor
struct ModelEditorView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    let model: ModelConfiguration?
    private let requiresAPIKey: Bool
    @State private var modelID: UUID
    @State private var name: String
    @State private var identifier: String
    @State private var baseURL: String
    @State private var apiProtocol: APIProtocol
    @State private var logo: ModelLogo
    @State private var key = ""
    @State private var initialKey = ""
    @State private var didLoadKey = false
    @State private var showKey = false
    @State private var failure: String?
    @State private var confirmDiscard = false
    @State private var confirmDelete = false

    init(model: ModelConfiguration?, requiresAPIKey: Bool = false) {
        self.model = model
        self.requiresAPIKey = requiresAPIKey
        _modelID = State(initialValue: model?.id ?? UUID())
        _name = State(initialValue: model?.name ?? "")
        _identifier = State(initialValue: model?.modelID ?? "")
        _baseURL = State(initialValue: model?.baseURL ?? "")
        _apiProtocol = State(initialValue: model?.apiProtocol ?? .openAI)
        _logo = State(initialValue: model?.logo ?? .automatic)
    }

    private var configuration: ModelConfiguration {
        ModelConfiguration(id: modelID, name: name.trimmingCharacters(in: .whitespacesAndNewlines),
                           modelID: identifier.trimmingCharacters(in: .whitespacesAndNewlines),
                           baseURL: baseURL.trimmingCharacters(in: .whitespacesAndNewlines), apiProtocol: apiProtocol, logo: logo)
    }

    private var hasChanges: Bool {
        if let model { return configuration != model || key != initialKey }
        return !name.isEmpty || !identifier.isEmpty || !baseURL.isEmpty || !key.isEmpty || apiProtocol != .openAI || logo != .automatic
    }

    private var isExistingModel: Bool {
        guard let model else { return false }
        return store.models.contains { $0.id == model.id }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        ServiceLogo(logo: configuration.resolvedLogo, size: 40)
                            .frame(width: 60, height: 60).background(HubStyle.grouped, in: RoundedRectangle(cornerRadius: 18))
                        VStack(alignment: .leading, spacing: 5) {
                            Text(name.isEmpty ? "自定义模型" : name).font(.system(size: 21, weight: .semibold)).lineLimit(1)
                            Text("配置自己的模型连接").font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 8)
                }.listRowBackground(Color.clear)
                Section {
                    TextField("显示名称", text: $name)
                    TextField("模型 ID", text: $identifier).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Picker("接口协议", selection: $apiProtocol) { ForEach(APIProtocol.allCases) { Text($0.title).tag($0) } }
                } header: { Text("基本信息") } footer: { Text("支持填写任意模型 ID；服务商接口须符合所选协议。名称不代表连接已验证。") }
                Section {
                    TextField("https://…", text: $baseURL).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                } header: { Text("接口地址") } footer: { Text("填写服务商提供的 Base URL。远程接口使用 HTTPS，本机接口可使用 HTTP 回环地址。") }
                Section {
                    HStack {
                        Group { if showKey { TextField("API Key · 按服务商要求填写", text: $key) } else { SecureField("API Key · 按服务商要求填写", text: $key) } }
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash" : "eye").frame(width: 35, height: 35) }
                            .buttonStyle(.borderless).accessibilityLabel(showKey ? "隐藏密钥" : "显示密钥")
                    }
                } header: { Text("API Key") } footer: { Text("无需鉴权的接口可留空。密钥保存在此设备的钥匙串中，不随模型配置文件保存。") }
                Section {
                    Picker("模型图标", selection: $logo) { ForEach(ModelLogo.allCases) { Text($0.title).tag($0) } }
                } footer: { Text("自动识别常见模型标识；未知模型显示通用标识，也可手动选择。首页会随模型一起更新。") }
                if let failure { Section { Text(failure).font(.footnote).foregroundStyle(.red).textSelection(.enabled) } }
                if isExistingModel {
                    Section { Button("删除模型", role: .destructive) { confirmDelete = true } }
                }
            }
            .navigationTitle(isExistingModel ? "编辑模型" : "添加模型").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { if hasChanges { confirmDiscard = true } else { dismiss() } } }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                Button(action: save) { Text("保存模型").font(.system(size: 16, weight: .semibold)).frame(maxWidth: .infinity).frame(height: 51) }
                    .buttonStyle(.borderedProminent).foregroundStyle(HubStyle.background)
                    .padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 12).background(.regularMaterial)
            }
            .interactiveDismissDisabled(hasChanges)
            .confirmationDialog("放弃未保存的更改？", isPresented: $confirmDiscard, titleVisibility: .visible) {
                Button("放弃更改", role: .destructive) { dismiss() }
                Button("保留编辑", role: .cancel) { }
            }
            .confirmationDialog("删除这个模型？", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("删除模型", role: .destructive) {
                    if let model { do { try store.delete(model); dismiss() } catch { failure = error.localizedDescription } }
                }
                Button("取消", role: .cancel) { }
            }
            .onAppear {
                if !didLoadKey {
                    key = model.map { store.key(for: $0) } ?? ""
                    initialKey = key
                    didLoadKey = true
                }
            }
        }
    }

    private func save() {
        guard !configuration.name.isEmpty else { failure = "请填写显示名称。"; return }
        guard !configuration.modelID.isEmpty else { failure = "请填写模型 ID。"; return }
        guard !configuration.baseURL.isEmpty else { failure = "请填写接口地址。"; return }
        guard !requiresAPIKey || !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { failure = "此官方预设需要服务商 API Key，请先填写。"; return }
        do { try store.save(configuration, key: key); store.selectedID = configuration.id; dismiss() }
        catch { failure = error.localizedDescription }
    }
}

@MainActor
struct SettingsView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    @State private var showModels = false
    @State private var showKey = false

    var body: some View {
        NavigationStack {
            Form {
                Section("模型") {
                    Button { showModels = true } label: { Label("模型与 API 配置", systemImage: "slider.horizontal.3") }
                    NavigationLink { PresetPickerView().environmentObject(store) } label: { Label("推荐模型预设", systemImage: "square.grid.2x2") }
                    Button { showKey = true } label: { Label("OpenRouter Key", systemImage: "key") }
                }
                Section {
                    Picker("主题", selection: $store.theme) { ForEach(AppTheme.allCases) { Text($0.title).tag($0) } }
                } header: { Text("外观") } footer: { Text("默认跟随 iPhone 的系统外观。") }
                Section {
                    Toggle("每天自动更新", isOn: $store.autoRefresh)
                    HStack(alignment: .firstTextBaseline) {
                        Text("最近更新")
                        Spacer()
                        Text(store.lastRefresh.map { $0.formatted(date: .abbreviated, time: .shortened) } ?? "尚未获取")
                            .font(.system(size: 13)).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
                    }
                    Button {
                        Task { await store.refreshFreeModels(force: true) }
                    } label: {
                        HStack { Text("立即刷新"); Spacer(); if store.isRefreshing { ProgressView() } else { Image(systemName: "arrow.clockwise") } }
                    }.disabled(store.isRefreshing)
                    if let error = store.discoveryError { Text(error).font(.footnote).foregroundStyle(.red).textSelection(.enabled) }
                } header: { Text("免费模型目录") } footer: {
                    Text("开启后每日检查 OpenRouter 目录，回到 App 时补充刷新。iOS 后台运行由系统安排，无法保证固定时刻执行。标价、额度与可用性以服务商为准。")
                }
                Section {
                    NavigationLink { AboutView() } label: { Label("关于 AIJIU", systemImage: "info.circle") }
                }
                OfficialWebExperienceSection()
            }
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .sheet(isPresented: $showModels) { ModelPickerView().environmentObject(store) }
            .sheet(isPresented: $showKey) { OpenRouterKeyView().environmentObject(store) }
        }
    }
}

@MainActor
struct OpenRouterKeyView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    @State private var key = ""
    @State private var initialKey = ""
    @State private var loaded = false
    @State private var failure: String?
    @State private var showKey = false
    @State private var confirmDiscard = false

    private var hasChanges: Bool { key != initialKey }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Group { if showKey { TextField("OpenRouter API Key", text: $key) } else { SecureField("OpenRouter API Key", text: $key) } }
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash" : "eye").frame(width: 35, height: 35) }
                            .buttonStyle(.borderless).accessibilityLabel(showKey ? "隐藏密钥" : "显示密钥")
                    }
                } header: { Text("免费目录的通用 Key") } footer: {
                    Text("目录内的免费模型仍需你自己的 OpenRouter Key。密钥保存在设备钥匙串中；免费额度和服务可用性由 OpenRouter 决定。")
                }
                if let failure { Section { Text(failure).font(.footnote).foregroundStyle(.red) } }
            }
            .navigationTitle("OpenRouter Key").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") {
                        if hasChanges { confirmDiscard = true }
                        else { dismiss() }
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        do { try store.setOpenRouterKey(key.trimmingCharacters(in: .whitespacesAndNewlines)); dismiss() }
                        catch { failure = error.localizedDescription }
                    }
                }
            }
            .interactiveDismissDisabled(hasChanges)
            .confirmationDialog("放弃未保存的密钥更改？", isPresented: $confirmDiscard, titleVisibility: .visible) {
                Button("放弃更改", role: .destructive) { dismiss() }
                Button("保留编辑", role: .cancel) { }
            }
            .onAppear {
                if !loaded {
                    key = store.openRouterKey()
                    initialKey = key
                    loaded = true
                }
            }
        }
    }
}

@MainActor
struct AboutView: View {
    @State private var copied: String?
    var body: some View {
        List {
            Section {
                VStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 27, style: .continuous)
                            .fill(LinearGradient(colors: [Color(red: 0.10, green: 0.17, blue: 0.36), Color(red: 0.25, green: 0.36, blue: 0.72)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        Circle().stroke(.white.opacity(0.12), lineWidth: 1).frame(width: 65, height: 65)
                        Text("GJ").font(.system(size: 29, weight: .semibold, design: .rounded)).foregroundStyle(.white)
                        Image(systemName: "sparkle").font(.system(size: 12, weight: .semibold)).foregroundStyle(Color(red: 0.54, green: 0.91, blue: 0.98)).offset(x: 26, y: -26)
                    }.frame(width: 96, height: 96).accessibilityLabel("GUJIU 开发者头像")
                    VStack(spacing: 5) {
                        Text("GUJIU").font(.system(size: 25, weight: .semibold)).tracking(1)
                        Text("AIJIU 开发者").font(.system(size: 13)).foregroundStyle(.secondary)
                    }
                }.frame(maxWidth: .infinity).padding(.vertical, 15)
            }.listRowBackground(Color.clear)
            Section("联系方式") {
                HStack(alignment: .center, spacing: 8) {
                    Text("邮箱").font(.system(size: 14)).foregroundStyle(.secondary).frame(width: 35, alignment: .leading)
                    Link("gujiu520@proton.me", destination: URL(string: "mailto:gujiu520@proton.me")!)
                        .font(.system(size: 14)).lineLimit(1).minimumScaleFactor(0.85)
                    Spacer(minLength: 0)
                    copyButton("gujiu520@proton.me", label: "邮箱")
                }
                contact("QQ", value: "401738182")
                contact("微信", value: "V909800")
            }
            Section {
                HStack { Text("版本"); Spacer(); Text("1.1 · iOS 16+").foregroundStyle(.secondary) }
                Text("支持自定义模型接口。免费模型目录每日检查，实际额度与服务可用性由服务商决定。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            if let copied { Section { Text("已复制\(copied)").font(.footnote).foregroundStyle(HubStyle.accent) } }
        }.navigationTitle("关于 AIJIU").navigationBarTitleDisplayMode(.inline)
    }

    private func contact(_ label: String, value: String) -> some View {
        HStack {
            Text(label).font(.system(size: 14)).foregroundStyle(.secondary).frame(width: 35, alignment: .leading)
            Text(value).font(.system(size: 15)).textSelection(.enabled)
            Spacer()
            copyButton(value, label: label)
        }
    }

    private func copyButton(_ value: String, label: String) -> some View {
        Button {
            UIPasteboard.general.string = value
            copied = label
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { if copied == label { copied = nil } }
        } label: { Image(systemName: "doc.on.doc").font(.system(size: 15)).frame(width: 38, height: 44) }
            .buttonStyle(.borderless).accessibilityLabel("复制\(label)")
    }
}

struct ServiceLogo: View {
    let logo: ModelLogo
    var size: CGFloat = 26

    var body: some View {
        Group {
            switch logo {
            case .openai: OpenAIKnot().stroke(Color.primary, style: StrokeStyle(lineWidth: max(1.4, size * 0.065), lineCap: .round, lineJoin: .round))
            case .anthropic:
                Canvas { context, canvas in
                    var path = Path()
                    let center = CGPoint(x: canvas.width / 2, y: canvas.height / 2)
                    for index in 0..<12 {
                        let angle = Double(index) * .pi / 6
                        let cosine = CGFloat(cos(angle))
                        let sine = CGFloat(sin(angle))
                        let inner: CGFloat = index.isMultiple(of: 2) ? 0.16 : 0.12
                        path.move(to: CGPoint(x: center.x + cosine * canvas.width * inner, y: center.y + sine * canvas.height * inner))
                        path.addLine(to: CGPoint(x: center.x + cosine * canvas.width * 0.46, y: center.y + sine * canvas.height * 0.46))
                    }
                    context.stroke(path, with: .color(Color(red: 0.70, green: 0.39, blue: 0.27)), style: StrokeStyle(lineWidth: max(1.7, canvas.width * 0.055), lineCap: .square))
                }
            case .google:
                GeminiSpark().fill(LinearGradient(colors: [Color(red: 0.30, green: 0.54, blue: 0.94), Color(red: 0.59, green: 0.43, blue: 0.81), Color(red: 0.90, green: 0.49, blue: 0.48)], startPoint: .topLeading, endPoint: .bottomTrailing))
            case .deepseek:
                DeepSeekWhale().fill(Color(red: 0.31, green: 0.43, blue: 0.87), style: FillStyle(eoFill: true))
            case .qwen:
                Text("Q").font(.system(size: size * 0.83, weight: .bold, design: .rounded)).foregroundStyle(Color(red: 0.40, green: 0.30, blue: 0.85))
            case .glm:
                Text("GL").font(.system(size: size * 0.53, weight: .bold, design: .rounded)).foregroundStyle(Color(red: 0.22, green: 0.42, blue: 0.83))
            case .kimi:
                Text("K").font(.system(size: size * 0.83, weight: .bold, design: .rounded)).foregroundStyle(Color.primary)
            case .baidu:
                Text("文").font(.system(size: size * 0.75, weight: .semibold)).foregroundStyle(Color(red: 0.24, green: 0.39, blue: 0.86))
            case .automatic, .custom:
                AIJIUBrandMark().scaleEffect(1.5)
            }
        }.frame(width: size, height: size).accessibilityHidden(true)
    }
}

private struct AIJIUBrandMark: View {
    var body: some View {
        Canvas { context, canvas in
            func point(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x * canvas.width, y: y * canvas.height) }
            var a = Path()
            a.move(to: point(0.25, 0.72))
            a.addLine(to: point(0.43, 0.31))
            a.addQuadCurve(to: point(0.47, 0.28), control: point(0.445, 0.28))
            a.addLine(to: point(0.50, 0.28))
            a.addQuadCurve(to: point(0.545, 0.31), control: point(0.53, 0.28))
            a.addLine(to: point(0.64, 0.53))
            a.move(to: point(0.34, 0.56))
            a.addLine(to: point(0.60, 0.56))
            var j = Path()
            j.move(to: point(0.69, 0.29))
            j.addLine(to: point(0.69, 0.61))
            j.addQuadCurve(to: point(0.57, 0.73), control: point(0.69, 0.73))
            j.addLine(to: point(0.54, 0.73))
            let stroke = StrokeStyle(lineWidth: max(1.5, canvas.width * 0.075), lineCap: .round, lineJoin: .round)
            context.stroke(a, with: .color(HubStyle.accent), style: stroke)
            context.stroke(j, with: .color(Color(red: 0.20, green: 0.74, blue: 0.86)), style: stroke)
        }
    }
}

private struct OpenAIKnot: Shape {
    func path(in rect: CGRect) -> Path {
        var unit = Path()
        for index in 0..<6 {
            var segment = Path()
            segment.move(to: CGPoint(x: 8.1, y: 12))
            segment.addLine(to: CGPoint(x: 8.1, y: 6.4))
            segment.addCurve(to: CGPoint(x: 16.23, y: 5.23), control1: CGPoint(x: 8.1, y: 1.1), control2: CGPoint(x: 14.9, y: 0.3))
            segment.move(to: CGPoint(x: 11.78, y: 6.33))
            segment.addLine(to: CGPoint(x: 8.1, y: 8.47))
            let rotation = CGAffineTransform(translationX: -12, y: -12)
                .concatenating(CGAffineTransform(rotationAngle: CGFloat(index) * .pi / 3))
                .concatenating(CGAffineTransform(translationX: 12, y: 12))
            unit.addPath(segment, transform: rotation)
        }
        return unit.applying(CGAffineTransform(scaleX: rect.width / 24, y: rect.height / 24).translatedBy(x: rect.minX, y: rect.minY))
    }
}

private struct GeminiSpark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 0.5, y: 0.02))
        path.addCurve(to: CGPoint(x: 0.98, y: 0.5), control1: CGPoint(x: 0.57, y: 0.34), control2: CGPoint(x: 0.66, y: 0.43))
        path.addCurve(to: CGPoint(x: 0.5, y: 0.98), control1: CGPoint(x: 0.66, y: 0.57), control2: CGPoint(x: 0.57, y: 0.66))
        path.addCurve(to: CGPoint(x: 0.02, y: 0.5), control1: CGPoint(x: 0.43, y: 0.66), control2: CGPoint(x: 0.34, y: 0.57))
        path.addCurve(to: CGPoint(x: 0.5, y: 0.02), control1: CGPoint(x: 0.34, y: 0.43), control2: CGPoint(x: 0.43, y: 0.34))
        return path.applying(CGAffineTransform(scaleX: rect.width, y: rect.height))
    }
}

private struct DeepSeekWhale: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 0.06, y: 0.45))
        path.addCurve(to: CGPoint(x: 0.39, y: 0.43), control1: CGPoint(x: 0.20, y: 0.59), control2: CGPoint(x: 0.29, y: 0.57))
        path.addCurve(to: CGPoint(x: 0.77, y: 0.37), control1: CGPoint(x: 0.51, y: 0.26), control2: CGPoint(x: 0.64, y: 0.28))
        path.addCurve(to: CGPoint(x: 0.96, y: 0.26), control1: CGPoint(x: 0.82, y: 0.29), control2: CGPoint(x: 0.90, y: 0.30))
        path.addCurve(to: CGPoint(x: 0.88, y: 0.55), control1: CGPoint(x: 0.93, y: 0.38), control2: CGPoint(x: 0.97, y: 0.48))
        path.addCurve(to: CGPoint(x: 0.45, y: 0.83), control1: CGPoint(x: 0.82, y: 0.78), control2: CGPoint(x: 0.65, y: 0.84))
        path.addCurve(to: CGPoint(x: 0.06, y: 0.45), control1: CGPoint(x: 0.24, y: 0.82), control2: CGPoint(x: 0.10, y: 0.67))
        path.closeSubpath()
        path.addEllipse(in: CGRect(x: 0.69, y: 0.45, width: 0.055, height: 0.055))
        return path.applying(CGAffineTransform(scaleX: rect.width, y: rect.height))
    }
}
