import Foundation
import Combine
import Security

enum APIProtocol: String, Codable, CaseIterable, Identifiable {
    case openAI, anthropic, gemini
    var id: String { rawValue }
    var title: String {
        switch self { case .openAI: return "OpenAI 兼容"; case .anthropic: return "Anthropic Messages"; case .gemini: return "Google Gemini" }
    }
}

enum ModelLogo: String, Codable, CaseIterable, Identifiable {
    case automatic, openai, anthropic, google, deepseek, qwen, glm, kimi, baidu, custom
    var id: String { rawValue }
    var title: String {
        switch self { case .automatic: return "自动识别"; case .openai: return "OpenAI"; case .anthropic: return "Anthropic"; case .google: return "Gemini"; case .deepseek: return "DeepSeek"; case .qwen: return "千问"; case .glm: return "智谱"; case .kimi: return "Kimi"; case .baidu: return "文心"; case .custom: return "AIJIU" }
    }
}

enum AppTheme: String, Codable, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var title: String { switch self { case .system: return "跟随系统"; case .light: return "浅色"; case .dark: return "深色" } }
}

struct ModelConfiguration: Identifiable, Codable, Equatable, Hashable {
    var id: UUID
    var name: String
    var modelID: String
    var baseURL: String
    var apiProtocol: APIProtocol
    var logo: ModelLogo
    var isFreeCatalog: Bool

    init(id: UUID = UUID(), name: String, modelID: String, baseURL: String, apiProtocol: APIProtocol = .openAI, logo: ModelLogo = .automatic, isFreeCatalog: Bool = false) {
        self.id = id; self.name = name; self.modelID = modelID; self.baseURL = baseURL
        self.apiProtocol = apiProtocol; self.logo = logo; self.isFreeCatalog = isFreeCatalog
    }

    var resolvedLogo: ModelLogo {
        guard logo == .automatic else { return logo }
        let text = (modelID + " " + name).lowercased()
        if text.contains("deepseek") { return .deepseek }
        if text.contains("claude") || text.contains("anthropic") { return .anthropic }
        if text.contains("gemini") { return .google }
        if text.contains("qwen") || text.contains("千问") { return .qwen }
        if text.contains("glm") || text.contains("智谱") { return .glm }
        if text.contains("kimi") || text.contains("moonshot") { return .kimi }
        if text.contains("ernie") || text.contains("文心") { return .baidu }
        if text.contains("gpt") || text.contains("openai/") || text.hasPrefix("o1") || text.hasPrefix("o3") || text.hasPrefix("o4") { return .openai }
        return .custom
    }
}

struct ModelPreset: Decodable, Identifiable {
    let id: String
    let name: String
    let modelID: String
    let baseURL: String
    let apiProtocol: APIProtocol
    let logo: ModelLogo
    let provider: String
    let category: String
    let requiresKey: Bool
    let note: String

    enum CodingKeys: String, CodingKey {
        case id, name, modelID, baseURL, logo, provider, category, requiresKey, note
        case apiProtocol = "protocol"
    }

    func makeConfiguration() -> ModelConfiguration {
        ModelConfiguration(name: name, modelID: modelID, baseURL: baseURL, apiProtocol: apiProtocol, logo: logo)
    }
}

enum PresetCatalog {
    static let all: [ModelPreset] = {
        guard let url = Bundle.main.url(forResource: "ModelPresets", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let presets = try? JSONDecoder().decode([ModelPreset].self, from: data) else { return [] }
        return presets
    }()
}

enum ChatRole: String, Codable { case user, assistant, system }

struct ChatMessage: Identifiable, Codable {
    var id: UUID
    var role: ChatRole
    var content: String
    init(id: UUID = UUID(), role: ChatRole, content: String) { self.id = id; self.role = role; self.content = content }
}

enum AIHubError: LocalizedError {
    case configuration(String), keychain(OSStatus), invalidResponse, emptyResponse, service(Int, String), freeModelUnavailable
    var errorDescription: String? {
        switch self {
        case .configuration(let message): return message
        case .keychain(let status): return "无法访问本机钥匙串（\(status)）。"
        case .invalidResponse: return "服务商返回了无法识别的数据。"
        case .emptyResponse: return "模型没有返回文本，请稍后重试。"
        case .service(let status, let message): return "请求失败（\(status)）：\(message)"
        case .freeModelUnavailable: return "该模型当前未确认可免费使用，请刷新免费模型目录后重试。"
        }
    }
}

enum CredentialStore {
    private static let service = "com.gujiu.aihub.credentials"
    static func read(_ account: String) throws -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return "" }
        guard status == errSecSuccess, let data = result as? Data, let value = String(data: data, encoding: .utf8) else { throw AIHubError.keychain(status) }
        return value
    }
    static func write(_ value: String, account: String) throws {
        if value.isEmpty { try delete(account); return }
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        let changes: [String: Any] = [kSecValueData as String: Data(value.utf8), kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        var status = SecItemUpdate(query as CFDictionary, changes as CFDictionary)
        if status == errSecItemNotFound {
            var item = query
            changes.forEach { item[$0.key] = $0.value }
            status = SecItemAdd(item as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw AIHubError.keychain(status) }
    }
    static func delete(_ account: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw AIHubError.keychain(status) }
    }
}

private struct FreeCatalogCache: Codable { var models: [ModelConfiguration]; var refreshedAt: Date }

@MainActor
final class ModelStore: ObservableObject {
    static let shared = ModelStore()
    @Published var models: [ModelConfiguration]
    @Published var freeModels: [ModelConfiguration]
    @Published var selectedID: UUID? {
        didSet { UserDefaults.standard.set(selectedID?.uuidString, forKey: "selectedModelID") }
    }
    @Published var theme: AppTheme {
        didSet { UserDefaults.standard.set(theme.rawValue, forKey: "appearance") }
    }
    @Published var autoRefresh: Bool {
        didSet {
            UserDefaults.standard.set(autoRefresh, forKey: "autoRefreshFreeModels")
            if autoRefresh { RefreshScheduler.schedule() } else { RefreshScheduler.cancel() }
        }
    }
    @Published private(set) var lastRefresh: Date?
    @Published private(set) var isRefreshing = false
    @Published var discoveryError: String?
    var allModels: [ModelConfiguration] { models + freeModels }
    var selectedModel: ModelConfiguration? { allModels.first { $0.id == selectedID } }

    private static func location(_ filename: String) throws -> URL {
        let root = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("AIHub", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        return root.appendingPathComponent(filename)
    }
    private static func load<T: Decodable>(_ type: T.Type, file: String) -> T? {
        guard let url = try? location(file), let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }
    private static func persist<T: Encodable>(_ value: T, file: String) throws {
        let url = try location(file)
        try JSONEncoder().encode(value).write(to: url, options: .atomic)
        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: url.path)
    }

    private init() {
        models = Self.load([ModelConfiguration].self, file: "models.json") ?? []
        if let cache = Self.load(FreeCatalogCache.self, file: "free-models.json") {
            freeModels = cache.models.filter { $0.isFreeCatalog && $0.baseURL == FreeModelCatalog.baseURL }
            lastRefresh = cache.refreshedAt
        } else { freeModels = []; lastRefresh = nil }
        let defaults = UserDefaults.standard
        selectedID = defaults.string(forKey: "selectedModelID").flatMap(UUID.init(uuidString:))
        theme = defaults.string(forKey: "appearance").flatMap(AppTheme.init(rawValue:)) ?? .system
        autoRefresh = defaults.object(forKey: "autoRefreshFreeModels") as? Bool ?? true
        if selectedModel == nil { selectedID = allModels.first?.id }
    }

    private func account(_ model: ModelConfiguration) -> String { model.isFreeCatalog ? "openrouter-shared" : model.id.uuidString }
    func key(for model: ModelConfiguration) -> String { (try? CredentialStore.read(account(model))) ?? "" }
    func openRouterKey() -> String { (try? CredentialStore.read("openrouter-shared")) ?? "" }
    func setOpenRouterKey(_ value: String) throws { try CredentialStore.write(value.trimmingCharacters(in: .whitespacesAndNewlines), account: "openrouter-shared") }

    func save(_ model: ModelConfiguration, key: String) throws {
        guard !model.isFreeCatalog else { throw AIHubError.configuration("免费目录由服务商同步，请使用 OpenRouter Key 设置。") }
        var cleaned = model
        cleaned.name = cleaned.name.trimmingCharacters(in: .whitespacesAndNewlines)
        cleaned.modelID = cleaned.modelID.trimmingCharacters(in: .whitespacesAndNewlines)
        cleaned.baseURL = cleaned.baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.name.isEmpty, !cleaned.modelID.isEmpty else { throw AIHubError.configuration("请填写显示名称与模型 ID。") }
        _ = try EndpointValidation.validate(cleaned.baseURL)
        let secret = key.trimmingCharacters(in: .whitespacesAndNewlines)
        let oldSecret = try CredentialStore.read(account(cleaned))
        var updated = models
        if let index = updated.firstIndex(where: { $0.id == cleaned.id }) { updated[index] = cleaned } else { updated.append(cleaned) }
        try CredentialStore.write(secret, account: account(cleaned))
        do { try Self.persist(updated, file: "models.json") }
        catch { try? CredentialStore.write(oldSecret, account: account(cleaned)); throw error }
        models = updated
        selectedID = cleaned.id
    }

    func delete(_ model: ModelConfiguration) throws {
        guard !model.isFreeCatalog else { throw AIHubError.configuration("免费目录模型由每日同步维护。") }
        let updated = models.filter { $0.id != model.id }
        let oldSecret = try CredentialStore.read(account(model))
        try CredentialStore.delete(account(model))
        do { try Self.persist(updated, file: "models.json") }
        catch { try? CredentialStore.write(oldSecret, account: account(model)); throw error }
        models = updated
        if selectedID == model.id { selectedID = allModels.first?.id }
    }

    func refreshFreeModels(force: Bool) async {
        guard !isRefreshing else { return }
        if !force, let last = lastRefresh, Date().timeIntervalSince(last) < 24 * 60 * 60 { return }
        isRefreshing = true
        discoveryError = nil
        defer { isRefreshing = false }
        do {
            let results = try await FreeModelCatalog.fetch()
            try Task.checkCancellation()
            let now = Date()
            try Self.persist(FreeCatalogCache(models: results, refreshedAt: now), file: "free-models.json")
            freeModels = results
            lastRefresh = now
            if selectedModel == nil { selectedID = allModels.first?.id }
        } catch is CancellationError {
            discoveryError = "目录更新已取消，保留上次缓存。"
        } catch {
            discoveryError = "无法更新免费模型目录，已保留上次缓存。\n" + error.localizedDescription
        }
    }

    func refreshIfNeeded() async {
        guard autoRefresh else { return }
        await refreshFreeModels(force: false)
    }
}
