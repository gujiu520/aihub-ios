# AIJIU · iOS 16+

AI Hub 更名为 AIJIU，版本1.1。App 图标改为原创靛蓝 A/J 交叠线条；保留原 bundle 与钥匙串标识，便于覆盖升级时继续读取原配置。

支持多个自定义模型，模型 Logo 联动、系统主题、Keychain 密钥、三种 API 协议、OpenRouter 免费目录每日检查。推荐模型预填名称／ID／地址，旗舰与国内免费 API 分组；免费 API 仍须个人 Key。另提供官方网页“免 Key 体验”，可能要求登录，不读取或复用网页令牌。

官方预设与价格核实日期：2026-11-21。推荐模型预设不等于服务已连通；账号权限、额度和价格以服务商为准。

在安装完整 Xcode 的 Mac 中执行 `bash build-ipa.sh`。云端构建使用相同脚本，输出 `build/AIJIU-1.1.0-arm64-unsigned.ipa`。源码和构建产物放在用户授权的私有 GitHub 仓库中。

开发者 GUJIU：gujiu520@proton.me，QQ401738182，微信V909800。

Copyright © 2026 GUJIU. All rights reserved.
