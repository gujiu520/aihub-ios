package com.gujiu.aijiu;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Small, self-drawn identifiers; the AIJIU mark is supplied by the app's vector asset. */
public final class LogoView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private String brand = "custom";
    private int foreground = Color.rgb(30, 34, 43);
    private int accent = Color.rgb(82, 86, 220);

    public LogoView(Context context) { super(context); setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO); }
    public LogoView brand(String value) { brand = value == null ? "custom" : value; invalidate(); return this; }
    public LogoView palette(int text, int tint) { foreground = text; accent = tint; invalidate(); return this; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float size = Math.min(getWidth(), getHeight());
        canvas.save(); canvas.translate((getWidth() - size) / 2f, (getHeight() - size) / 2f); canvas.scale(size / 24f, size / 24f);
        paint.reset(); paint.setAntiAlias(true); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
        if ("openai".equals(brand)) {
            paint.setColor(foreground); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.65f);
            for (int i = 0; i < 6; i++) {
                canvas.save(); canvas.rotate(i * 60, 12, 12);
                Path p = new Path(); p.moveTo(8.1f, 12); p.lineTo(8.1f, 6.4f); p.cubicTo(8.1f, 1.1f, 14.9f, .3f, 16.23f, 5.23f);
                p.moveTo(11.78f, 6.33f); p.lineTo(8.1f, 8.47f); canvas.drawPath(p, paint); canvas.restore();
            }
        } else if ("anthropic".equals(brand)) {
            paint.setColor(Color.rgb(183, 111, 78)); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.9f);
            for (int i = 0; i < 12; i++) { double a = Math.PI * i / 6; canvas.drawLine(12 + (float)Math.cos(a) * 2.4f, 12 + (float)Math.sin(a) * 2.4f, 12 + (float)Math.cos(a) * 10, 12 + (float)Math.sin(a) * 10, paint); }
        } else if ("google".equals(brand)) {
            paint.setStyle(Paint.Style.FILL); paint.setShader(new LinearGradient(2, 2, 22, 22, new int[]{0xff4c8bf5, 0xff9671dd, 0xffe98d8d}, null, Shader.TileMode.CLAMP));
            Path p = new Path(); p.moveTo(12, 1); p.cubicTo(13.4f, 7.5f, 16.5f, 10.6f, 23, 12); p.cubicTo(16.5f, 13.4f, 13.4f, 16.5f, 12, 23); p.cubicTo(10.6f, 16.5f, 7.5f, 13.4f, 1, 12); p.cubicTo(7.5f, 10.6f, 10.6f, 7.5f, 12, 1); p.close(); canvas.drawPath(p, paint);
        } else if ("deepseek".equals(brand)) {
            paint.setColor(0xff5672e3); paint.setStyle(Paint.Style.FILL);
            Path p = new Path(); p.setFillType(Path.FillType.EVEN_ODD); p.moveTo(1.5f, 10.8f); p.cubicTo(7, 16, 8, 7, 15.1f, 9); p.cubicTo(18, 9.5f, 20.8f, 6.6f, 23, 5.4f); p.cubicTo(21, 9, 24, 12, 20.5f, 14.1f); p.cubicTo(18.8f, 22.5f, 5.2f, 23, 1.5f, 10.8f); p.close(); p.addCircle(16.3f, 12, .85f, Path.Direction.CW); canvas.drawPath(p, paint);
        } else if ("qwen".equals(brand) || "glm".equals(brand) || "kimi".equals(brand) || "baidu".equals(brand)) {
            String letter = "qwen".equals(brand) ? "Q" : "glm".equals(brand) ? "Z" : "kimi".equals(brand) ? "K" : "文";
            paint.setColor("qwen".equals(brand) ? 0xff7958db : "kimi".equals(brand) ? foreground : 0xff3777db);
            paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); paint.setTextSize("baidu".equals(brand) ? 18 : 23);
            Paint.FontMetrics metrics = paint.getFontMetrics(); canvas.drawText(letter, 12, 12 - (metrics.ascent + metrics.descent) / 2, paint);
        } else {
            Drawable icon = getResources().getDrawable(R.drawable.ic_aijiu, getContext().getTheme()); icon.setBounds(0, 0, 24, 24); icon.draw(canvas);
        }
        canvas.restore();
    }
}
