# AIJIU for Android

原生 Java Android App，Android 8.0+，默认跟随系统主题。支持任意自定义模型 ID；服务端须符合所选 OpenAI 兼容／Anthropic／Gemini 协议。

API Key 使用 Android Keystore 加密后保存在本机，不包含开发者共享密钥。OpenRouter 免费目录支持 24 小时前台补刷新、手动刷新及 JobScheduler 最佳努力后台刷新。后台执行不能保证准点。

推荐预设分为旗舰大模型和国内免费 API。模型 ID 与地址可预填，免费 API 仍需个人服务商授权。另设官方网页体验入口，可免填 API Key 打开官方网站，可能需要登录；它们与本 App API 聊天独立。

开发者 GUJIU：gujiu520@proton.me，QQ 401738182，微信 V909800。

构建工具：JDK17、Gradle8.11.1、Android SDK35、AGP8.10.1。在本目录执行 `gradle :app:assembleDebug`。GitHub Actions 将输出名为 AIJIU-Android-APK 的测试 APK，使用测试签名，尚未经过真机和商店发布验证。

Copyright © 2026 GUJIU. All rights reserved.
