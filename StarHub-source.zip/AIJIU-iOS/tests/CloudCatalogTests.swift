import Foundation

// These tests compile with the production Foundation-only parser; no app/UI stubs.
@main
struct CloudCatalogTests {
    private static var checks = 0

    static func main() throws {
        let accepted = try CloudCatalog.parse(data())
        try expect(accepted.revision == 4 && accepted.presets.count == 1, "valid manifest preserves recommendations")
        try expect(accepted.presets[0].modelID == "test-model", "valid manifest preserves model ID")
        try expect(accepted.announcement == "Catalog refreshed", "valid manifest preserves plain text announcement")

        for (field, bad) in [("schemaVersion", 2 as Any), ("schemaVersion", true), ("schemaVersion", "1"), ("schemaVersion", 1.5), ("revision", 0), ("revision", -1), ("revision", true), ("revision", "4"), ("revision", 2.5), ("announcement", 5), ("latestVersion", false), ("presets", "wrong"), ("updatedAt", "yesterday"), ("updatedAt", "2026-11-21")] {
            try rejects("rejects malformed \(field): \(bad)") { var value = manifest(); value[field] = bad; return try encoded(value) }
        }
        for field in ["schemaVersion", "revision", "updatedAt", "announcement", "latestVersion", "releaseURL", "presets"] {
            try rejects("rejects missing \(field)") { var value = manifest(); value.removeValue(forKey: field); return try encoded(value) }
        }
        for (field, bad) in [("id", "" as Any), ("name", "  "), ("modelID", 6), ("provider", NSNull()), ("protocol", "unknown"), ("logo", "remote-svg"), ("category", "other"), ("requiresKey", false), ("requiresKey", 1), ("requiresKey", "true"), ("freeCatalog", true), ("freeCatalog", 0), ("note", true)] {
            try rejects("rejects malformed preset \(field)") { var item = preset(); item[field] = bad; return try data(presets: [item]) }
        }
        for field in ["id", "name", "modelID", "baseURL", "protocol", "logo", "provider", "category", "requiresKey", "freeCatalog", "note"] {
            try rejects("rejects missing preset \(field)") { var item = preset(); item.removeValue(forKey: field); return try data(presets: [item]) }
        }
        for address in ["http://api.example.com/v1", "https://user:secret@api.example.com/v1", "https://api.example.com/v1?key=secret", "https://api.example.com/v1#fragment", "https://localhost/v1", "https://localhost./v1", "https://foo.localhost/v1", "https://127.0.0.1/v1", "https://127.1/v1", "https://127.42.10.1/v1", "https://2130706433/v1", "https://[::1]/v1", "https://[0:0:0:0:0:0:0:1]/v1", "https://[::ffff:127.0.0.1]/v1", "file:///tmp/catalog", "https:///missing-host", " https://api.example.com/v1"] {
            try rejects("rejects unsafe endpoint \(address)") { var item = preset(); item["baseURL"] = address; return try data(presets: [item]) }
        }
        try rejects("rejects duplicate IDs") { try data(presets: [preset(), preset()]) }
        try rejects("rejects empty recommendations") { try data(presets: []) }
        try rejects("rejects more than 100 recommendations") { try data(presets: (0..<101).map { index in var item = preset(); item["id"] = "item-\(index)"; return item }) }
        try rejects("rejects overlong announcement") { var value = manifest(); value["announcement"] = String(repeating: "a", count: 2001); return try encoded(value) }
        try rejects("rejects overlong preset name") { var item = preset(); item["name"] = String(repeating: "a", count: 129); return try data(presets: [item]) }
        try rejects("rejects a release URL outside the fixed public releases page") { var value = manifest(); value["releaseURL"] = "https://example.com/releases"; return try encoded(value) }
        try rejects("rejects release URL query parameters") { var value = manifest(); value["releaseURL"] = "https://github.com/gujiu520/aihub-ios/releases/latest?token=secret"; return try encoded(value) }
        try rejects("rejects invalid JSON") { Data("{broken".utf8) }
        try rejects("rejects a JSON array at the root") { Data("[]".utf8) }
        try rejects("rejects an empty body") { Data() }
        try rejects("rejects body above 256 KiB before parsing") { Data(repeating: 32, count: 256 * 1024 + 1) }
        var boundary = try data()
        boundary.append(Data(repeating: 32, count: 256 * 1024 - boundary.count))
        try expect(try CloudCatalog.parse(boundary).revision == 4, "accepts a valid body exactly at the size limit")
        do { _ = try CloudCatalog.parse(data(), minimumRevision: 5); throw Failure(message: "rollback was accepted") }
        catch is CloudCatalogError { checks += 1 }
        try expect(try CloudCatalog.parse(data(), minimumRevision: 4).revision == 4, "same revision is accepted")
        try expect(try CloudCatalog.parse(data(), minimumRevision: 3).revision == 4, "higher revision is accepted")
        for invalid in ["1.2", "v1.2.3", "1.2.3-beta", "1.2.3.4", "1.-2.3", "1.2.x", "1.02.3", "1.2.3 ", "999999999999999999999.2.3"] {
            try expect(CloudVersion(invalid) == nil, "rejects malformed version \(invalid)")
            try rejects("rejects malformed manifest version \(invalid)") { var value = manifest(); value["latestVersion"] = invalid; return try encoded(value) }
        }
        try expect(CloudVersion("1.10.0")! > CloudVersion("1.9.9")!, "compares numeric minor versions")
        try expect(CloudVersion("2.0.0")! > CloudVersion("1.99.99")!, "compares major before minor")
        try expect(CloudVersion("1.2.11")! > CloudVersion("1.2.9")!, "compares numeric patch versions")
        try expect(CloudVersion("1.2.0")! == CloudVersion("1.2.0")!, "equal versions compare equal")
        print("PASS: \(checks) CloudCatalog checks")
    }

    private struct Failure: Error { let message: String }
    private static func expect(_ condition: @autoclosure () throws -> Bool, _ message: String) throws {
        guard try condition() else { throw Failure(message: message) }
        checks += 1
    }
    private static func rejects(_ message: String, body: () throws -> Data) throws {
        let bytes = try body()
        do { _ = try CloudCatalog.parse(bytes) }
        catch is CloudCatalogError { checks += 1; return }
        throw Failure(message: message)
    }
    private static func preset() -> [String: Any] {
        ["id": "test-preset", "name": "Test Model", "modelID": "test-model", "baseURL": "https://api.example.com/v1", "protocol": "openAI", "logo": "automatic", "provider": "Test Provider", "category": "large", "requiresKey": true, "freeCatalog": false, "note": "Use your personal API Key."]
    }
    private static func manifest() -> [String: Any] {
        ["schemaVersion": 1, "revision": 4, "updatedAt": "2026-11-21T08:00:00Z", "announcement": "Catalog refreshed", "latestVersion": "1.2.0", "releaseURL": "https://github.com/gujiu520/aihub-ios/releases/latest", "presets": [preset()]]
    }
    private static func encoded(_ object: [String: Any]) throws -> Data { try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys]) }
    private static func data(presets: [[String: Any]]? = nil) throws -> Data {
        var value = manifest()
        if let presets { value["presets"] = presets }
        return try encoded(value)
    }
}
