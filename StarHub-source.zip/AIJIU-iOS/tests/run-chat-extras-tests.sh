#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TEST_DIR=$(mktemp -d "${TMPDIR:-/tmp}/starhub-chat-tests.XXXXXX")
trap 'rm -rf "$TEST_DIR"' EXIT HUP INT TERM
swiftc -swift-version 5 -parse-as-library "$ROOT/AIJIU/ChatExtras.swift" "$ROOT/tests/ChatExtrasTests.swift" -o "$TEST_DIR/chat-extras-tests"
"$TEST_DIR/chat-extras-tests"
