#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TEST_DIR=$(mktemp -d "${TMPDIR:-/tmp}/aijiu-cloud-tests.XXXXXX")
trap 'rm -rf "$TEST_DIR"' EXIT HUP INT TERM
swiftc -swift-version 5 -parse-as-library "$ROOT/AIJIU/CloudCatalog.swift" "$ROOT/tests/CloudCatalogTests.swift" -o "$TEST_DIR/cloud-catalog-tests"
"$TEST_DIR/cloud-catalog-tests"
