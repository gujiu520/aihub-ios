import Foundation

@main
struct ChatExtrasTests {
    enum Failure: Error { case check(String), unexpectedSuccess }

    static func require(_ value: Bool, _ label: String) throws {
        if !value { throw Failure.check(label) }
    }

    static func rejects(_ operation: () throws -> Void) throws {
        do { try operation() }
        catch { return }
        throw Failure.unexpectedSuccess
    }

    static func main() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false)
        defer { try? FileManager.default.removeItem(at: directory) }

        let documentURL = directory.appendingPathComponent("note.txt")
        try Data("First line\n第二行".utf8).write(to: documentURL)
        let document = try ChatAttachment.load(from: documentURL)
        let encoded = try JSONEncoder().encode(document)
        let restored = try JSONDecoder().decode(ChatAttachment.self, from: encoded)
        try require(restored == document, "Attachment survives a persistence round trip")
        let text = try ChatWireContent.openAI(text: "Summarize", attachments: [document]) as? String
        try require(text?.contains("note.txt") == true, "Text request identifies the attached document")
        try require(text?.contains("第二行") == true, "UTF-8 document content is preserved")
        let latest = ChatWireContent.latestUserMessageIndex(in: [false, true, false, true, false])
        try require(latest == 3, "Only the latest user turn can read attachments")
        let selected = ChatWireContent.attachmentsAt(index: 1, latestUserIndex: latest, available: [document])
        try require(selected.isEmpty, "Older attachments are excluded from requests")

        let imageURL = directory.appendingPathComponent("pixel.png")
        let png = Data(base64Encoded: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGMQ0bABAADMAHm9FcOvAAAAAElFTkSuQmCC")!
        try png.write(to: imageURL)
        let image = try ChatAttachment.load(from: imageURL)
        let openAI = try ChatWireContent.openAI(text: "", attachments: [image]) as? [[String: Any]]
        let imageURLPart = openAI?.first?["image_url"] as? [String: String]
        try require(imageURLPart?["url"]?.hasPrefix("data:image/png;base64,") == true, "OpenAI sends an image data URL")
        let anthropic = try ChatWireContent.anthropic(text: "", attachments: [image]) as? [[String: Any]]
        let source = anthropic?.first?["source"] as? [String: String]
        try require(source?["type"] == "base64" && source?["media_type"] == "image/png", "Anthropic sends an image source")
        let gemini = try ChatWireContent.gemini(text: "", attachments: [image])
        let inline = gemini.first?["inlineData"] as? [String: String]
        try require(inline?["mimeType"] == "image/png" && inline?["data"] != nil, "Gemini sends inline image data")
        try rejects { try ChatAttachment.validateBudget(Array(repeating: image, count: ChatAttachment.maximumCount + 1)) }
        let pdfURL = directory.appendingPathComponent("document.pdf")
        try Data("%PDF-1.7\n%%EOF\n".utf8).write(to: pdfURL)
        let pdf = try ChatAttachment.load(from: pdfURL)
        let fileParts = try ChatWireContent.openAI(text: "", attachments: [pdf]) as? [[String: Any]]
        let pdfPart = fileParts?.first?["file"] as? [String: String]
        try require(pdfPart?["filename"] == "document.pdf" && pdfPart?["file_data"]?.hasPrefix("data:application/pdf;base64,") == true,
                    "OpenAI sends PDF as a Chat Completions file block")
        let documentParts = try ChatWireContent.anthropic(text: "", attachments: [pdf]) as? [[String: Any]]
        try require(documentParts?.first?["type"] as? String == "document", "Anthropic sends a document block")
        let pdfInline = try ChatWireContent.gemini(text: "", attachments: [pdf]).first?["inlineData"] as? [String: String]
        try require(pdfInline?["mimeType"] == "application/pdf", "Gemini includes the PDF as inline data")

        let invalidImage = directory.appendingPathComponent("invalid.png")
        try Data("not a PNG".utf8).write(to: invalidImage)
        try rejects { _ = try ChatAttachment.load(from: invalidImage) }
        let invalidText = directory.appendingPathComponent("invalid.txt")
        try Data([0xff, 0xff]).write(to: invalidText)
        try rejects { _ = try ChatAttachment.load(from: invalidText) }
        let large = directory.appendingPathComponent("large.txt")
        try Data(repeating: 0x41, count: 128 * 1024 + 1).write(to: large)
        try rejects { _ = try ChatAttachment.load(from: large) }

        let skillURL = directory.appendingPathComponent("SKILL.md")
        try Data("---\nname: translate\ndescription: Translate text\n---\nTranslate to Chinese.\n".utf8).write(to: skillURL)
        let skill = try ChatSkill.load(from: skillURL)
        try require(skill.name == "translate" && skill.prompt == "Translate to Chinese.", "Skill import separates the prompt and front matter")
        try Data("---\nname: incomplete\n".utf8).write(to: skillURL)
        try rejects { _ = try ChatSkill.load(from: skillURL) }
        try rejects { _ = try ChatSkill(name: "   ", prompt: "Some instructions") }

        var tools = ChatAgentToolset(attachments: [document, image])
        let listing = tools.run(name: "list_attachments", arguments: "{}")
        try require(listing.contains(document.id.uuidString) && listing.contains(image.id.uuidString), "Tool lists only the current attachments")
        let read = tools.run(name: "read_text_attachment", arguments: "{\"id\":\"\(document.id.uuidString)\"}")
        try require(read.contains("第二行"), "Tool returns UTF-8 content for the selected attachment")
        let denied = tools.run(name: "read_text_attachment", arguments: "{\"id\":\"\(UUID().uuidString)\"}")
        try require(denied.contains("error"), "Tool cannot read unattached content")
        _ = tools.run(name: "create_artifact", arguments: "{\"name\":\"../bad.txt\",\"text\":\"draft\"}")
        try require(tools.artifact == nil, "Tool rejects path components")
        let created = tools.run(name: "create_artifact", arguments: "{\"name\":\"report.md\",\"text\":\"# Draft\"}")
        try require(created.contains("name") && tools.artifact?.text == "# Draft", "Tool creates an in-memory export draft")
        _ = tools.run(name: "create_artifact", arguments: "{\"name\":\"other.md\",\"text\":\"replacement\"}")
        try require(tools.artifact?.name == "report.md", "One tool draft per request")
        print("ChatExtras tests passed")
    }
}
