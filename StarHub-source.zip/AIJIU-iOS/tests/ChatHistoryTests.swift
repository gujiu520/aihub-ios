import Foundation

// Minimal portable equivalents of the message and skill data types.
enum ChatRole: String, Codable { case user, assistant, system }
struct ChatMessage: Codable { var role: ChatRole; var content: String }
struct ChatSkill: Codable { var name: String }

@main
enum ChatHistoryTests {
    static func main() throws {
        let file = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: file) }
        let firstModel = UUID()
        let secondModel = UUID()
        var history = try ChatHistory.load(from: file)
        precondition(history.active == nil)
        history.start(modelID: firstModel)
        let firstChat = history.activeID
        history.updateActive {
            $0.messages.append(ChatMessage(role: .user, content: "First conversation"))
            $0.skill = ChatSkill(name: "Example")
        }
        try history.save(to: file)

        // An interrupted request must survive without an invented assistant reply.
        history = try ChatHistory.load(from: file)
        precondition(history.active?.modelID == firstModel && history.active?.messages.count == 1)
        precondition(history.active?.skill?.name == "Example")
        history.updateActive { $0.messages.append(ChatMessage(role: .assistant, content: "First reply")) }
        history.start(modelID: secondModel)
        history.updateActive { $0.messages.append(ChatMessage(role: .user, content: "Second conversation")) }
        try history.save(to: file)

        history = try ChatHistory.load(from: file)
        precondition(history.sessions.count == 2 && history.active?.modelID == secondModel)
        history.activeID = firstChat
        precondition(history.active?.modelID == firstModel && history.active?.messages.last?.content == "First reply")
        print("PASS: Chat history preserves sessions, model, skill, and pending turns")
    }
}
