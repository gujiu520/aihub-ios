# 星枢 StarHub · iOS 16+

AIJIU 更名为星枢 StarHub，版本1.2.0（build3）。原创星核与轨道节点图标；保留原 bundle、钥匙串和内部工程名称，便于兼容原有配置。

支持多个自定义模型、模型 Logo 联动、系统主题、Keychain 密钥、三种 API 协议及 OpenRouter 免费目录每日到期检查。免费 API 仍须个人 Key；官方网页“免 Key 体验”可能要求登录，不读取或复用网页令牌。

新增固定 GitHub HTTPS 数据目录同步：推荐模型、公告与版本信息无需重装即可更新。首次需安装本同步版一次；打开／返回 App 到期检查，设置支持手动刷新和独立开关。失败保留有效缓存，云端目录不会覆盖已保存的模型接口、密钥和当前选择。原生代码或界面更新仍需新版安装包。聊天目前为会话内容，不提供云同步或重启后留存保证。

官方预设与价格核实日期：2026-11-21。推荐模型预设不等于服务已连通；账号权限、额度和价格以服务商为准。

在安装完整 Xcode 的 Mac 中先执行 `bash tests/run-cloud-tests.sh`，再执行 `bash build-ipa.sh`。输出 `build/StarHub-1.2.0-arm64-unsigned.ipa`。内部 Xcode scheme 仍为 AIJIU。用户已要求公开源码和安装包；云端构建与 Releases 使用 gujiu520/aihub-ios 仓库。未经真机安装和实际服务商推理测试。

开发者 GUJIU：gujiu520@proton.me，QQ401738182，微信V909800。

Copyright © 2026 GUJIU. All rights reserved.
