import Foundation
import CoreFoundation
import ImageIO
import UniformTypeIdentifiers
#if os(iOS)
import SwiftUI
#endif

private enum ChatFile {
    static func read(_ url: URL, limit: Int) throws -> Data {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard values.isRegularFile == true else { throw ChatExtrasError.invalidFile }
        if let size = values.fileSize, size > limit { throw ChatExtrasError.tooLarge }
        let file = try FileHandle(forReadingFrom: url)
        defer { try? file.close() }
        var data = Data()
        while let block = try file.read(upToCount: min(64 * 1024, limit + 1 - data.count)), !block.isEmpty {
            data.append(block)
            guard data.count <= limit else { throw ChatExtrasError.tooLarge }
        }
        guard !data.isEmpty else { throw ChatExtrasError.invalidFile }
        return data
    }

    static func utf8(_ data: Data) throws -> String {
        guard let text = String(data: data, encoding: .utf8), !text.contains("\0") else {
            throw ChatExtrasError.invalidText
        }
        return text.hasPrefix("\u{FEFF}") ? String(text.dropFirst()) : text
    }
}

private enum ChatExtrasError: LocalizedError {
    case unsupportedType, invalidFile, invalidText, tooLarge, attachmentBudget
    case invalidSkillFile, invalidSkill, skillLimit

    var errorDescription: String? {
        switch self {
        case .unsupportedType: return "请选择 JPEG、PNG、PDF、TXT、MD、CSV 或 JSON 文件。"
        case .invalidFile: return "无法读取此文件，或图片内容与扩展名不符。"
        case .invalidText: return "请选择使用 UTF-8 编码的文档。"
        case .tooLarge: return "文件超过大小上限。"
        case .attachmentBudget: return "每条消息最多附加 3 个文件，合计不超过 4 MB。"
        case .invalidSkillFile: return "请选择有效的 SKILL.md 文件。"
        case .invalidSkill: return "请填写技能名称和提示词。名称最多 80 个字符，提示词最多 64 KB。"
        case .skillLimit: return "本机最多保存 24 个技能。"
        }
    }
}

struct ChatAttachment: Identifiable, Codable, Equatable {
    static let maximumCount = 3
    static let maximumCombinedBytes = 4 * 1024 * 1024
    static let allowedContentTypes: [UTType] = [
        .jpeg, .png, .pdf, .plainText, UTType(filenameExtension: "md") ?? .text, .commaSeparatedText, .json
    ]
    private static let binaryLimit = 3 * 1024 * 1024
    private static let textLimit = 128 * 1024

    let id: UUID
    let name: String
    let mimeType: String
    fileprivate let data: Data
    var byteCount: Int { data.count }
    var isImage: Bool { mimeType == "image/jpeg" || mimeType == "image/png" }
    var isPDF: Bool { mimeType == "application/pdf" }
    var isText: Bool { !isImage && !isPDF }

    static func load(from url: URL) throws -> ChatAttachment {
        let mimeType: String
        let imageType: UTType?
        switch url.pathExtension.lowercased() {
        case "jpg", "jpeg": mimeType = "image/jpeg"; imageType = .jpeg
        case "png": mimeType = "image/png"; imageType = .png
        case "pdf": mimeType = "application/pdf"; imageType = nil
        case "txt": mimeType = "text/plain"; imageType = nil
        case "md": mimeType = "text/markdown"; imageType = nil
        case "csv": mimeType = "text/csv"; imageType = nil
        case "json": mimeType = "application/json"; imageType = nil
        default: throw ChatExtrasError.unsupportedType
        }
        let data = try ChatFile.read(url, limit: imageType != nil || mimeType == "application/pdf" ? binaryLimit : textLimit)
        if let imageType {
            guard let source = CGImageSourceCreateWithData(data as CFData, nil),
                  CGImageSourceGetCount(source) == 1,
                  let declaredType = CGImageSourceGetType(source), declaredType as String == imageType.identifier,
                  let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [String: Any],
                  let width = properties[kCGImagePropertyPixelWidth as String] as? Int,
                  let height = properties[kCGImagePropertyPixelHeight as String] as? Int,
                  (1...4096).contains(width), (1...4096).contains(height),
                  CGImageSourceCreateImageAtIndex(source, 0, nil) != nil else {
                throw ChatExtrasError.invalidFile
            }
        } else if mimeType == "application/pdf" {
            guard data.count >= 14, data.starts(with: Data("%PDF-".utf8)) else { throw ChatExtrasError.invalidFile }
        } else {
            let text = try ChatFile.utf8(data)
            guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ChatExtrasError.invalidFile }
        }
        let safeName = url.lastPathComponent.unicodeScalars.map { scalar in
            CharacterSet.controlCharacters.contains(scalar) ? "_" : String(scalar)
        }.joined()
        return ChatAttachment(id: UUID(), name: String(safeName.prefix(120)), mimeType: mimeType, data: data)
    }

    static func validateBudget(_ attachments: [ChatAttachment]) throws {
        guard attachments.count <= maximumCount,
              attachments.reduce(0, { $0 + $1.byteCount }) <= maximumCombinedBytes else {
            throw ChatExtrasError.attachmentBudget
        }
        for attachment in attachments {
            let limit = attachment.isText ? textLimit : binaryLimit
            guard (1...limit).contains(attachment.byteCount) else { throw ChatExtrasError.tooLarge }
        }
    }
}

enum ChatWireContent {
    static func latestUserMessageIndex(in userMessages: [Bool]) -> Int? {
        userMessages.lastIndex(of: true)
    }

    static func attachmentsAt(index: Int, latestUserIndex: Int?, available: [ChatAttachment]) -> [ChatAttachment] {
        index == latestUserIndex ? available : []
    }

    private static func parts(text: String, attachments: [ChatAttachment], agentMode: Bool = false) throws -> (String, [ChatAttachment]) {
        try ChatAttachment.validateBudget(attachments)
        var textParts = text.isEmpty ? [] : [text]
        for attachment in attachments where attachment.isText {
            let document = agentMode ? "可用 read_text_attachment 读取。" : try ChatFile.utf8(attachment.data)
            textParts.append("【附件 · \(attachment.name)】\n\(document)\n【附件结束】")
        }
        return (textParts.joined(separator: "\n\n"), attachments.filter { !$0.isText })
    }

    static func openAI(text: String, attachments: [ChatAttachment], agentMode: Bool = false) throws -> Any {
        let (message, images) = try parts(text: text, attachments: attachments, agentMode: agentMode)
        guard !images.isEmpty else { return message }
        var blocks: [[String: Any]] = message.isEmpty ? [] : [["type": "text", "text": message]]
        for attachment in images {
            let dataURL = "data:\(attachment.mimeType);base64,\(attachment.data.base64EncodedString())"
            if attachment.isPDF {
                blocks.append(["type": "file", "file": ["filename": attachment.name, "file_data": dataURL]])
            } else {
                blocks.append(["type": "image_url", "image_url": ["url": dataURL]])
            }
        }
        return blocks
    }

    static func anthropic(text: String, attachments: [ChatAttachment]) throws -> Any {
        let (message, images) = try parts(text: text, attachments: attachments)
        guard !images.isEmpty else { return message }
        var blocks: [[String: Any]] = message.isEmpty ? [] : [["type": "text", "text": message]]
        for attachment in images {
            blocks.append(["type": attachment.isPDF ? "document" : "image", "source": [
                "type": "base64", "media_type": attachment.mimeType, "data": attachment.data.base64EncodedString()
            ]])
        }
        return blocks
    }

    static func gemini(text: String, attachments: [ChatAttachment]) throws -> [[String: Any]] {
        let (message, images) = try parts(text: text, attachments: attachments)
        var blocks: [[String: Any]] = message.isEmpty && !images.isEmpty ? [] : [["text": message]]
        for image in images {
            blocks.append(["inlineData": ["mimeType": image.mimeType, "data": image.data.base64EncodedString()]])
        }
        return blocks
    }
}

struct ChatSkill: Identifiable, Codable, Equatable {
    static let maximumPromptBytes = 64 * 1024
    let id: UUID
    let name: String
    let prompt: String

    init(id: UUID = UUID(), name: String, prompt: String) throws {
        let title = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let instructions = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard (1...80).contains(title.count), title.rangeOfCharacter(from: .controlCharacters) == nil,
              (1...Self.maximumPromptBytes).contains(instructions.utf8.count), !instructions.contains("\0") else {
            throw ChatExtrasError.invalidSkill
        }
        self.id = id
        self.name = title
        self.prompt = instructions
    }

    static func load(from url: URL) throws -> ChatSkill {
        guard url.lastPathComponent.lowercased() == "skill.md" else { throw ChatExtrasError.invalidSkillFile }
        let text = try ChatFile.utf8(ChatFile.read(url, limit: maximumPromptBytes))
            .replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        let lines = text.components(separatedBy: "\n")
        var title = "导入的技能"
        var body = text
        if lines.first == "---" {
            guard let end = lines.dropFirst().firstIndex(of: "---") else { throw ChatExtrasError.invalidSkillFile }
            if let nameLine = lines[1..<end].first(where: { $0.hasPrefix("name:") }) {
                let value = nameLine.dropFirst("name:".count).trimmingCharacters(in: .whitespaces)
                if let quote = value.first, value.count >= 2, (quote == "\"" || quote == "'"), value.last == quote {
                    title = String(value.dropFirst().dropLast())
                } else if !value.isEmpty {
                    title = value
                }
            }
            body = lines.dropFirst(end + 1).joined(separator: "\n")
        }
        return try ChatSkill(name: title, prompt: body)
    }
}

struct ChatArtifact: Codable, Equatable {
    let name: String
    let text: String
}

struct ChatReply {
    let text: String
    let artifact: ChatArtifact?
}

struct ChatAgentToolset {
    static let maximumRounds = 3
    static let maximumCallsPerRound = 3
    static let maximumArtifactBytes = 64 * 1024
    let attachments: [ChatAttachment]
    private(set) var artifact: ChatArtifact?

    init(attachments: [ChatAttachment]) {
        self.attachments = attachments
    }

    private static func function(_ name: String, description: String, fields: [String: String] = [:]) -> [String: Any] {
        [
            "type": "function",
            "function": [
                "name": name, "description": description,
                "parameters": [
                    "type": "object",
                    "properties": fields.mapValues { ["type": "string", "description": $0] },
                    "required": fields.keys.sorted(),
                    "additionalProperties": false
                ] as [String: Any]
            ] as [String: Any]
        ]
    }

    static var schemas: [[String: Any]] {
        [
            function("list_attachments", description: "List files explicitly attached to the latest user message."),
            function("read_text_attachment", description: "Read a text document attached to the latest user message.",
                     fields: ["id": "Attachment ID returned by list_attachments."]),
            function("create_artifact", description: "Prepare a single text attachment for the user to review and export.",
                     fields: ["name": "A filename ending in .txt, .md, .csv, or .json.", "text": "UTF-8 content."])
        ]
    }

    private static func encode(_ result: [String: Any]) -> String {
        guard let data = try? JSONSerialization.data(withJSONObject: result, options: [.sortedKeys]),
              let json = String(data: data, encoding: .utf8) else { return #"{"error":"Tool result is unavailable."}"# }
        return json
    }

    mutating func run(name: String, arguments: String) -> String {
        guard arguments.utf8.count <= 512 * 1024,
              let input = (try? JSONSerialization.jsonObject(with: Data(arguments.utf8))) as? [String: Any] else {
            return Self.encode(["error": "Provide valid JSON arguments within the tool size limit."])
        }
        switch name {
        case "list_attachments" where input.isEmpty:
            let listing: [[String: Any]] = attachments.map {
                ["id": $0.id.uuidString, "name": $0.name, "mimeType": $0.mimeType, "size": $0.byteCount]
            }
            return Self.encode(["files": listing])
        case "read_text_attachment" where input.count == 1:
            guard let value = input["id"] as? String, let id = UUID(uuidString: value),
                  let attachment = attachments.first(where: { $0.id == id }), attachment.isText,
                  let text = try? ChatFile.utf8(attachment.data) else {
                return Self.encode(["error": "The ID must refer to a text document attached to the latest message."])
            }
            return Self.encode(["name": attachment.name, "text": text])
        case "create_artifact" where input.count == 2:
            guard artifact == nil else { return Self.encode(["error": "One export draft is available per request."]) }
            guard let filename = input["name"] as? String, let text = input["text"] as? String,
                  (1...120).contains(filename.utf8.count),
                  filename == filename.trimmingCharacters(in: .whitespacesAndNewlines),
                  filename.rangeOfCharacter(from: .controlCharacters) == nil,
                  filename.rangeOfCharacter(from: CharacterSet(charactersIn: "/\\:*?\"<>|")) == nil,
                  !filename.hasPrefix("."), !filename.hasSuffix("."),
                  ["txt", "md", "csv", "json"].contains((filename as NSString).pathExtension.lowercased()),
                  (1...Self.maximumArtifactBytes).contains(text.utf8.count), !text.contains("\0") else {
                return Self.encode(["error": "Provide a plain filename and up to 64 KB of UTF-8 text."])
            }
            artifact = ChatArtifact(name: filename, text: text)
            return Self.encode(["name": filename, "status": "Draft created. The user can review and export it."])
        default:
            return Self.encode(["error": "Unknown tool or invalid arguments."])
        }
    }
}

#if os(iOS)
private enum ChatSkillLibrary {
    private static let maximumSkills = 24
    private static let maximumFileBytes = 4 * 1024 * 1024

    private static func location() throws -> URL {
        let root = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        var directory = root.appendingPathComponent("StarHubSkills", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try directory.setResourceValues(values)
        return directory.appendingPathComponent("library.json")
    }

    static func read() throws -> [ChatSkill] {
        let file = try location()
        guard FileManager.default.fileExists(atPath: file.path) else { return [] }
        let stored = try JSONDecoder().decode([ChatSkill].self, from: ChatFile.read(file, limit: maximumFileBytes))
        guard stored.count <= maximumSkills, Set(stored.map(\.id)).count == stored.count else { throw ChatExtrasError.invalidFile }
        return try stored.map { try ChatSkill(id: $0.id, name: $0.name, prompt: $0.prompt) }
    }

    static func write(_ skills: [ChatSkill]) throws {
        guard skills.count <= maximumSkills else { throw ChatExtrasError.skillLimit }
        let data = try JSONEncoder().encode(skills)
        guard data.count <= maximumFileBytes else { throw ChatExtrasError.tooLarge }
        try data.write(to: location(), options: [.atomic, .completeFileProtection])
    }
}

struct ChatSkillSheet: View {
    @Binding var selected: ChatSkill?
    @Environment(\.dismiss) private var dismiss
    @State private var skills: [ChatSkill] = []
    @State private var ready = false
    @State private var importing = false
    @State private var editing = false
    @State private var editorID: UUID?
    @State private var name = ""
    @State private var prompt = ""
    @State private var error: String?

    init(selected: Binding<ChatSkill?>) {
        self._selected = selected
    }

    var body: some View {
        NavigationStack {
            Group {
                if editing { editor } else { library }
            }
            .navigationTitle(editing ? "编辑技能" : "聊天技能")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(editing ? "返回" : "完成") {
                        if editing { editing = false } else { dismiss() }
                    }
                }
            }
        }
        .task { reload() }
        .fileImporter(isPresented: $importing, allowedContentTypes: [UTType(filenameExtension: "md") ?? .text, .plainText]) { result in
            do {
                let skill = try ChatSkill.load(from: result.get())
                beginEditing(id: nil, name: skill.name, prompt: skill.prompt)
            } catch {
                self.error = error.localizedDescription
            }
        }
        .alert("技能操作失败", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("好") { error = nil }
        } message: {
            Text(error ?? "")
        }
    }

    private var library: some View {
        List {
            Section {
                Button("不使用技能") { selected = nil; dismiss() }
                ForEach(skills) { skill in
                    Button {
                        selected = skill
                        dismiss()
                    } label: {
                        HStack {
                            Text(skill.name).foregroundStyle(.primary)
                            Spacer()
                            if selected?.id == skill.id { Image(systemName: "checkmark") }
                        }
                    }
                    .swipeActions(allowsFullSwipe: false) {
                        Button("删除", role: .destructive) { remove(skill) }
                        Button("编辑") { beginEditing(id: skill.id, name: skill.name, prompt: skill.prompt) }
                            .tint(.blue)
                    }
                    .contextMenu {
                        Button("编辑") { beginEditing(id: skill.id, name: skill.name, prompt: skill.prompt) }
                        Button("删除", role: .destructive) { remove(skill) }
                    }
                }
            } footer: {
                Text("技能保存在此设备。启用后，提示词会随聊天发给当前模型。")
            }
            Section {
                Button("新建技能") { beginEditing(id: nil, name: "", prompt: "") }
                Button("导入 SKILL.md") { importing = true }
            }
            .disabled(!ready)
            if !ready {
                Button("重新读取技能库") { reload() }
            }
        }
    }

    private var editor: some View {
        Form {
            TextField("名称", text: $name)
            Section("提示词") {
                TextEditor(text: $prompt).frame(minHeight: 160)
                    .accessibilityLabel("提示词")
            }
            Button("保存技能") { save() }
                .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                          || prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
    }

    private func reload() {
        ready = false
        do {
            skills = try ChatSkillLibrary.read()
            ready = true
        } catch {
            self.error = error.localizedDescription
        }
    }

    private func beginEditing(id: UUID?, name: String, prompt: String) {
        editorID = id
        self.name = name
        self.prompt = prompt
        editing = true
    }

    private func save() {
        do {
            let skill = try ChatSkill(id: editorID ?? UUID(), name: name, prompt: prompt)
            var updated = skills.filter { $0.id != skill.id }
            updated.append(skill)
            updated.sort { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
            try ChatSkillLibrary.write(updated)
            skills = updated
            if selected?.id == skill.id { selected = skill }
            editing = false
        } catch {
            self.error = error.localizedDescription
        }
    }

    private func remove(_ skill: ChatSkill) {
        do {
            let updated = skills.filter { $0.id != skill.id }
            try ChatSkillLibrary.write(updated)
            skills = updated
            if selected?.id == skill.id { selected = nil }
        } catch {
            self.error = error.localizedDescription
        }
    }
}
#endif
