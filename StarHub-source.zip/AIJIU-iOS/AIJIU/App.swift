import SwiftUI

@main
@MainActor
struct AIJIUApp: App {
    @StateObject private var store = ModelStore.shared
    @Environment(\.scenePhase) private var scenePhase

    init() {
        RefreshScheduler.register()
    }

    var body: some Scene {
        WindowGroup {
            ChatRootView()
                .environmentObject(store)
                .preferredColorScheme(colorScheme)
                .tint(Color.accentColor)
                .task { await store.syncCloudCatalog(force: false) }
                .task { await store.refreshIfNeeded() }
                .onChange(of: scenePhase) { phase in
                    if phase == .active {
                        Task { await store.syncCloudCatalog(force: false) }
                        Task { await store.refreshIfNeeded() }
                    }
                    if phase == .background && store.autoRefresh { RefreshScheduler.schedule() }
                }
                .onChange(of: store.autoRefresh) { enabled in
                    if enabled { RefreshScheduler.schedule() }
                    else { RefreshScheduler.cancel() }
                }
                .onChange(of: store.autoCloudSync) { enabled in
                    if enabled { Task { await store.syncCloudCatalog(force: false) } }
                }
        }
    }

    private var colorScheme: ColorScheme? {
        switch store.theme {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}
