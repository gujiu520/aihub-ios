import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum HubStyle {
    static let background = Color(uiColor: .systemBackground)
    static let grouped = Color(uiColor: .systemGroupedBackground)
    static let secondary = Color(uiColor: .secondarySystemGroupedBackground)
    static let accent = Color.accentColor
}

private struct EditorTarget: Identifiable {
    let id = UUID()
    var model: ModelConfiguration?
    var requiresAPIKey = false
}

private struct ArtifactDocument: FileDocument {
    static let readableContentTypes: [UTType] = [.plainText]
    var text: String

    init(text: String) { self.text = text }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents, let value = String(data: data, encoding: .utf8)
        else { throw CocoaError(.fileReadCorruptFile) }
        text = value
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(text.utf8))
    }
}

@MainActor
struct ChatRootView: View {
    @EnvironmentObject private var store: ModelStore
    @State private var history = ChatHistory()
    @State private var historyFile: URL?
    @State private var historyLoaded = false
    @State private var showHistory = false
    @State private var settingsAfterHistory = false
    @State private var deleteSession: ChatSession?
    @State private var showAttachments = false
    @State private var showSkills = false
    @State private var showArtifactExport = false
    @State private var artifactToExport: ChatArtifact?
    @State private var attachments: [ChatAttachment] = []
    @State private var selectedSkill: ChatSkill?
    @State private var draft = ""
    @State private var isSending = false
    @State private var failure: String?
    @State private var showModels = false
    @State private var showSettings = false
    @State private var showCatalogKey = false
    @State private var editor: EditorTarget?
    @FocusState private var composerFocused: Bool
    private var messages: [ChatMessage] { history.active?.messages ?? [] }

    var body: some View {
        NavigationStack {
            Group {
                if messages.isEmpty { emptyState }
                else { conversation }
            }
            .background(HubStyle.background)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { showHistory = true } label: {
                        Image(systemName: "sidebar.left").frame(width: 34, height: 36)
                    }.disabled(isSending).accessibilityLabel("聊天记录")
                }
                ToolbarItem(placement: .principal) {
                    Menu {
                        if !quickModels.isEmpty {
                            Section("选择模型") {
                                ForEach(quickModels) { model in
                                    Button {
                                        store.selectedID = model.id
                                    } label: {
                                        if store.selectedID == model.id {
                                            Label(model.name, systemImage: "checkmark")
                                        } else {
                                            Text(model.name)
                                        }
                                    }
                                }
                            }
                        }
                        Button {
                            composerFocused = false
                            showModels = true
                        } label: {
                            Label(quickModels.isEmpty ? "查找或添加模型" : "浏览全部模型", systemImage: "square.grid.2x2")
                        }
                    } label: {
                        HStack(spacing: 8) {
                            ServiceLogo(logo: store.selectedModel?.resolvedLogo ?? .custom, size: 23)
                            Text(store.selectedModel?.name ?? "选择模型")
                                .font(.system(size: 16, weight: .semibold)).lineLimit(1)
                            Image(systemName: "chevron.down").font(.system(size: 10, weight: .semibold)).foregroundStyle(.secondary)
                        }
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 12).frame(height: 42)
                        .background(.thinMaterial, in: Capsule())
                        .frame(maxWidth: 245)
                    }.menuOrder(.fixed).disabled(isSending)
                        .accessibilityLabel("选择模型，当前为 \(store.selectedModel?.name ?? "未选择")")
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { startChat() } label: {
                        Image(systemName: "square.and.pencil").frame(width: 34, height: 36)
                    }.disabled(isSending).accessibilityLabel("新建对话")
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .safeAreaInset(edge: .bottom, spacing: 0) { composer }
            .sheet(isPresented: $showModels) { ModelPickerView().environmentObject(store) }
            .sheet(isPresented: $showSettings) { SettingsView().environmentObject(store) }
            .sheet(isPresented: $showCatalogKey) { OpenRouterKeyView().environmentObject(store) }
            .sheet(item: $editor) { ModelEditorView(model: $0.model).environmentObject(store) }
            .sheet(isPresented: $showHistory, onDismiss: {
                if settingsAfterHistory {
                    settingsAfterHistory = false
                    showSettings = true
                }
            }) { historySheet }
            .sheet(isPresented: $showSkills) {
                ChatSkillSheet(selected: Binding(get: { selectedSkill }, set: { skill in
                    if saveHistory({
                        if $0.active == nil { $0.start(modelID: store.selectedID) }
                        $0.updateActive { $0.skill = skill }
                    }) { selectedSkill = skill }
                }))
            }
            .fileImporter(isPresented: $showAttachments, allowedContentTypes: ChatAttachment.allowedContentTypes,
                          allowsMultipleSelection: true, onCompletion: importAttachments)
            .fileExporter(isPresented: $showArtifactExport,
                          document: artifactToExport.map { ArtifactDocument(text: $0.text) },
                          contentType: .plainText, defaultFilename: artifactToExport?.name ?? "StarHub") { result in
                if case .failure(let error) = result { failure = error.localizedDescription }
                artifactToExport = nil
            }
            .task { loadHistory() }
            .onChange(of: store.selectedID) { modelID in
                guard historyLoaded, history.active != nil, history.active?.modelID != modelID else { return }
                saveHistory { $0.updateActive { $0.modelID = modelID } }
            }
        }
    }

    private var historySheet: some View {
        NavigationStack {
            List {
                Section {
                    Button { startChat(); showHistory = false } label: { Label("新建聊天", systemImage: "square.and.pencil") }
                    Button {
                        settingsAfterHistory = true
                        showHistory = false
                    } label: { Label("设置", systemImage: "gearshape") }
                }
                if history.sessions.contains(where: { !$0.messages.isEmpty }) {
                    Section("聊天记录") {
                        ForEach(history.sessions.filter { !$0.messages.isEmpty }.sorted { $0.updatedAt > $1.updatedAt }) { session in
                            Button { openChat(session) } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(session.title).foregroundStyle(.primary).lineLimit(1)
                                        Text(session.updatedAt, style: .date).font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if session.id == history.activeID { Image(systemName: "checkmark") }
                                }
                            }.swipeActions {
                                Button(role: .destructive) { deleteSession = session } label: { Label("删除", systemImage: "trash") }
                            }
                        }
                    }
                }
            }
            .navigationTitle("聊天记录")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { showHistory = false } } }
            .alert("删除这条聊天记录？", isPresented: Binding(
                get: { deleteSession != nil },
                set: { if !$0 { deleteSession = nil } }
            ), presenting: deleteSession) { session in
                Button("删除", role: .destructive) { removeChat(session) }
                Button("取消", role: .cancel) {}
            }
        }
    }

    private func loadHistory() {
        guard !historyLoaded else { return }
        do {
            let file = try ChatHistory.localFile()
            let saved = try ChatHistory.load(from: file)
            historyFile = file
            history = saved
            selectedSkill = saved.active?.skill
            if let modelID = saved.active?.modelID { store.selectedID = modelID }
            historyLoaded = true
        } catch {
            failure = "暂时无法读取聊天记录。请重新打开应用后再试。"
        }
    }

    @discardableResult
    private func saveHistory(_ change: (inout ChatHistory) -> Void) -> Bool {
        guard let historyFile else {
            failure = "聊天记录暂时不可用。"
            return false
        }
        var next = history
        change(&next)
        do {
            try next.save(to: historyFile)
            history = next
            return true
        } catch {
            failure = "无法保存聊天记录。\(error.localizedDescription)"
            return false
        }
    }

    private func startChat() {
        guard saveHistory({
            $0.start(modelID: store.selectedID)
            $0.updateActive { $0.skill = nil }
        }) else { return }
        selectedSkill = nil
        draft = ""
        attachments = []
        failure = nil
    }

    private func openChat(_ session: ChatSession) {
        if history.activeID == session.id { showHistory = false; return }
        guard saveHistory({ $0.activeID = session.id }) else { return }
        selectedSkill = session.skill
        if let modelID = session.modelID { store.selectedID = modelID }
        draft = ""
        attachments = []
        failure = nil
        showHistory = false
    }

    private func removeChat(_ session: ChatSession) {
        let removesActive = history.activeID == session.id
        guard saveHistory({
            $0.sessions.removeAll { $0.id == session.id }
            if removesActive { $0.activeID = nil }
        }) else { showHistory = false; return }
        if removesActive {
            selectedSkill = nil
            draft = ""
            attachments = []
            failure = nil
        }
    }

    private func importAttachments(_ result: Result<[URL], Error>) {
        do {
            let urls = try result.get()
            guard attachments.count + urls.count <= ChatAttachment.maximumCount else {
                failure = "每次最多选择 \(ChatAttachment.maximumCount) 个附件。"
                return
            }
            let picked = try urls.map(ChatAttachment.load(from:))
            let combined = attachments + picked
            guard combined.reduce(0, { $0 + $1.byteCount }) <= ChatAttachment.maximumCombinedBytes else {
                failure = "附件总大小超过本次发送上限。"
                return
            }
            attachments = combined
        } catch {
            failure = error.localizedDescription
        }
    }

    private var quickModels: [ModelConfiguration] {
        guard let current = store.selectedModel, current.isFreeCatalog else { return store.models }
        return [current] + store.models
    }

    private var emptyState: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 35)
            ServiceLogo(logo: store.selectedModel?.resolvedLogo ?? .custom, size: 58)
                .padding(.bottom, 22)
            Text("有什么想聊的？").font(.system(size: 29, weight: .semibold)).tracking(-0.8)
            Text("写下问题，或试试下面的灵感。")
                .font(.system(size: 15)).foregroundStyle(.secondary).padding(.top, 10)
            Spacer(minLength: 35)
            VStack(spacing: 2) {
                prompt("把想法写清楚", symbol: "text.alignleft", text: "帮我把这个想法表达得更清楚：")
                prompt("帮我理一理", symbol: "lightbulb", text: "帮我梳理这件事的思路：")
                prompt("随便聊聊", symbol: "bubble.left", text: "推荐一个轻松又有趣的聊天话题。")
            }.padding(.horizontal, 32).padding(.bottom, 10)
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func prompt(_ title: String, symbol: String, text: String) -> some View {
        Button {
            draft = text
            composerFocused = true
        } label: {
            HStack(spacing: 13) {
                Image(systemName: symbol).font(.system(size: 17)).foregroundStyle(HubStyle.accent).frame(width: 23)
                Text(title).font(.system(size: 15)).foregroundStyle(.primary)
                Spacer()
                Image(systemName: "arrow.up.left").font(.system(size: 12)).foregroundStyle(.tertiary)
            }.frame(minHeight: 46).contentShape(Rectangle())
        }.buttonStyle(.plain)
    }

    private var conversation: some View {
        ScrollViewReader { reader in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 24) {
                    ForEach(messages) { message in
                        HStack(alignment: .top) {
                            if message.role == .user { Spacer(minLength: 35) }
                            VStack(alignment: .leading, spacing: 8) {
                                ForEach(message.attachments ?? []) { attachment in
                                    Label(attachment.name, systemImage: "paperclip")
                                        .font(.footnote).lineLimit(2)
                                }
                                if !message.content.isEmpty {
                                    Text(message.content).font(.system(size: 17)).lineSpacing(5).textSelection(.enabled)
                                }
                                if let artifact = message.artifact {
                                    Button {
                                        artifactToExport = artifact
                                        showArtifactExport = true
                                    } label: {
                                        Label("保存 \(artifact.name)", systemImage: "square.and.arrow.down")
                                    }.font(.footnote)
                                }
                            }
                                .padding(message.role == .user ? 15 : 0)
                                .background(message.role == .user ? HubStyle.accent.opacity(0.10) : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                                .frame(maxWidth: .infinity, alignment: message.role == .user ? .trailing : .leading)
                            if message.role != .user { Spacer(minLength: 5) }
                        }.id(message.id)
                    }
                    if isSending {
                        HStack(spacing: 10) { ProgressView(); Text("正在回复…").font(.system(size: 14)).foregroundStyle(.secondary) }
                            .id("waiting")
                    } else if messages.last?.role == .user {
                        Button { send(retry: true) } label: { Label("重试最后一条消息", systemImage: "arrow.clockwise") }
                            .font(.footnote)
                    }
                }.padding(.horizontal, 23).padding(.top, 18).padding(.bottom, 22)
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: messages.count) { _ in
                if let id = messages.last?.id { withAnimation { reader.scrollTo(id, anchor: .bottom) } }
            }
            .onChange(of: isSending) { waiting in
                if waiting { withAnimation { reader.scrollTo("waiting", anchor: .bottom) } }
            }
        }
    }

    private var composer: some View {
        VStack(spacing: 7) {
            if let failure {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.circle").foregroundStyle(.red)
                    Text(failure).font(.system(size: 13)).foregroundStyle(.secondary).textSelection(.enabled)
                    Spacer(minLength: 0)
                    Button { self.failure = nil } label: { Image(systemName: "xmark").font(.system(size: 11)) }
                        .accessibilityLabel("关闭错误提示").frame(width: 30, height: 30)
                }.padding(12).background(Color.red.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
            }
            HStack {
                Circle().fill(Color.secondary.opacity(0.6)).frame(width: 5, height: 5)
                Text(connectionLabel).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                Spacer(minLength: 5)
                Button { showSkills = true } label: {
                    Label(selectedSkill?.name ?? "技能", systemImage: "sparkles").lineLimit(1)
                }.font(.system(size: 12, weight: .medium)).frame(minHeight: 35).disabled(isSending)
                Button(store.selectedModel?.isFreeCatalog == true ? "配置 Key" : "API 配置") { configureCurrentModel() }
                    .font(.system(size: 12, weight: .medium)).frame(minHeight: 35)
            }.padding(.horizontal, 7)
            if !attachments.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 7) {
                        ForEach(attachments) { attachment in
                            Button {
                                attachments.removeAll { $0.id == attachment.id }
                            } label: {
                                Label(attachment.name, systemImage: "xmark.circle")
                                    .font(.caption).lineLimit(1).padding(8)
                                    .background(HubStyle.secondary, in: Capsule())
                            }.accessibilityLabel("移除 \(attachment.name)")
                        }
                    }
                }
            }
            HStack(alignment: .bottom, spacing: 9) {
                Button { composerFocused = false; showAttachments = true } label: {
                    Image(systemName: "paperclip").font(.system(size: 19)).frame(width: 38, height: 43)
                }.disabled(isSending).accessibilityLabel("添加图片或文件")
                TextField("发消息…", text: $draft, axis: .vertical)
                    .font(.system(size: 17)).lineLimit(1...5)
                    .focused($composerFocused).padding(.vertical, 11)
                Button { send() } label: {
                    Group { if isSending { ProgressView().tint(HubStyle.background) } else { Image(systemName: "arrow.up").font(.system(size: 20, weight: .semibold)) } }
                        .frame(width: 43, height: 43).foregroundStyle(HubStyle.background)
                        .background(canSend ? HubStyle.accent : Color.secondary.opacity(0.4), in: Circle())
                }.disabled(!canSend)
                    .accessibilityLabel("发送消息")
            }
            .padding(.leading, 8).padding(.trailing, 9).padding(.vertical, 9)
            .background(HubStyle.secondary, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.primary.opacity(0.09), lineWidth: 0.8))
        }.padding(.horizontal, 16).padding(.top, 3).padding(.bottom, 10).background(HubStyle.background)
    }

    private var canSend: Bool {
        !isSending && (!draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !attachments.isEmpty)
    }

    private var connectionLabel: String {
        guard let model = store.selectedModel else {
            return store.selectedID == nil ? "选择或添加一个模型" : "上次选用的模型暂时不可用"
        }
        if model.isFreeCatalog { return "OpenRouter · 目录标价为零" }
        return "\(model.apiProtocol.title) · 自定义连接"
    }

    private func configureCurrentModel() {
        composerFocused = false
        if let model = store.selectedModel, model.isFreeCatalog { showCatalogKey = true }
        else { editor = EditorTarget(model: store.selectedModel) }
    }

    private func send(retry: Bool = false) {
        guard !isSending, retry || canSend else { return }
        guard let model = store.selectedModel else { showModels = true; return }
        let key = store.key(for: model)
        if model.isFreeCatalog && key.isEmpty { showCatalogKey = true; return }
        if retry {
            guard messages.last?.role == .user else { return }
        } else {
            let content = draft.trimmingCharacters(in: .whitespacesAndNewlines)
            let userMessage = ChatMessage(role: .user, content: content, attachments: attachments)
            guard saveHistory({
                if $0.active == nil { $0.start(modelID: model.id) }
                $0.updateActive {
                    $0.modelID = model.id
                    $0.messages.append(userMessage)
                    $0.updatedAt = Date()
                }
            }) else { return }
            draft = ""
            attachments = []
        }
        let skill = selectedSkill
        let requestMessages = messages
        failure = nil
        isSending = true
        composerFocused = false
        Task {
            do {
                let reply = try await ChatClient.sendWithTools(messages: requestMessages, model: model, key: key, skill: skill)
                saveHistory {
                    $0.updateActive {
                        $0.messages.append(ChatMessage(role: .assistant, content: reply.text, artifact: reply.artifact))
                        $0.updatedAt = Date()
                    }
                }
            } catch {
                failure = error.localizedDescription
            }
            isSending = false
        }
    }
}

@MainActor
struct ModelPickerView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var filter = 0
    @State private var editor: EditorTarget?

    private var visibleModels: [ModelConfiguration] {
        store.allModels.filter { model in
            let matchesFilter = filter == 0 || (filter == 1 && !model.isFreeCatalog) || (filter == 2 && model.isFreeCatalog)
            return matchesFilter && (query.isEmpty || (model.name + " " + model.modelID).localizedCaseInsensitiveContains(query))
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("模型筛选", selection: $filter) {
                        Text("全部").tag(0); Text("我的模型").tag(1); Text("免费目录").tag(2)
                    }.pickerStyle(.segmented).listRowBackground(Color.clear).listRowInsets(EdgeInsets())
                }
                Section {
                    if visibleModels.isEmpty {
                        VStack(alignment: .leading, spacing: 9) {
                            Text(query.isEmpty ? "还没有模型" : "没有找到模型").font(.headline)
                            Text(query.isEmpty ? "添加自己的 API，或刷新免费模型目录。" : "试试模型名称或完整模型 ID。")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }.padding(.vertical, 12)
                    }
                    ForEach(visibleModels) { model in
                        HStack(spacing: 8) {
                            Button {
                                store.selectedID = model.id
                                dismiss()
                            } label: {
                                HStack(spacing: 12) {
                                    ServiceLogo(logo: model.resolvedLogo, size: 28).frame(width: 38, height: 42)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(model.name).font(.system(size: 16, weight: .medium)).foregroundStyle(.primary).lineLimit(1)
                                        Text(model.isFreeCatalog ? "OpenRouter · 目录标价为零" : model.modelID)
                                            .font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(minLength: 3)
                                    if store.selectedID == model.id { Image(systemName: "checkmark").font(.system(size: 15, weight: .semibold)).foregroundStyle(HubStyle.accent) }
                                }.contentShape(Rectangle()).frame(minHeight: 48)
                            }.buttonStyle(.plain)
                            if !model.isFreeCatalog {
                                Button { editor = EditorTarget(model: model) } label: {
                                    Image(systemName: "slider.horizontal.3").font(.system(size: 16)).frame(width: 40, height: 44)
                                }.buttonStyle(.borderless).accessibilityLabel("配置 \(model.name)")
                            }
                        }
                    }
                } footer: {
                    Text("免费目录仅收录接口目录中输入、输出标价均为零的模型。实际额度与可用性由服务商决定。")
                }
                Section {
                    Button { editor = EditorTarget(model: nil) } label: { Label("添加自定义模型", systemImage: "plus") }
                    NavigationLink { PresetPickerView().environmentObject(store) } label: {
                        Label("供应商与模型", systemImage: "square.grid.2x2")
                    }
                    Button {
                        Task { await store.refreshFreeModels(force: true) }
                    } label: {
                        HStack { Label("刷新免费模型", systemImage: "arrow.clockwise"); Spacer(); if store.isRefreshing { ProgressView() } }
                    }.disabled(store.isRefreshing)
                    if let error = store.discoveryError { Text(error).font(.footnote).foregroundStyle(.red).textSelection(.enabled) }
                }
                OfficialWebExperienceSection()
            }
            .navigationTitle("选择模型").navigationBarTitleDisplayMode(.inline)
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索模型或 ID")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .sheet(item: $editor) { ModelEditorView(model: $0.model).environmentObject(store) }
        }
    }
}

@MainActor
private struct PresetPickerView: View {
    @EnvironmentObject private var store: ModelStore
    @State private var query = ""
    @State private var editor: EditorTarget?

    private static let categories: [(id: String, title: String)] = [
        ("official", "模型厂商"), ("cloud", "云服务商"), ("third-party", "第三方平台"),
        ("account", "账号入口"), ("unified", "统一供应商"), ("local", "本地服务")
    ]

    private var searchText: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }

    private func matches(_ supplier: SupplierDirectory.Entry) -> Bool {
        let search = searchText
        if search.isEmpty { return true }
        if ([supplier.name, supplier.website] + supplier.aliases).contains(where: { $0.localizedStandardContains(search) }) {
            return true
        }
        return supplier.models.contains { matchesModel($0, search) }
    }

    private func matchesModel(_ model: ModelPreset, _ search: String) -> Bool {
        [model.name, model.modelID, model.baseURL].contains(where: { $0.localizedStandardContains(search) })
    }

    var body: some View {
        let suppliers = SupplierDirectory.grouped(presets: store.recommendedPresets)
        let results = suppliers.filter(matches)
        List {
            Section {
                if results.isEmpty {
                    Text(searchText.isEmpty ? "供应商目录暂不可用。" : "没有找到匹配的供应商或模型。")
                        .foregroundStyle(.secondary)
                } else {
                    Text(searchText.isEmpty ? "共 \(suppliers.count) 家供应商" : "找到 \(results.count) 家供应商")
                        .foregroundStyle(.secondary)
                }
            } footer: {
                Text("点开供应商选择模型。仅提供官网入口的供应商需要手动确认接入方式。")
            }
            ForEach(Self.categories.indices, id: \.self) { index in
                let category = Self.categories[index]
                let rows = results.filter { $0.category == category.id }
                if !rows.isEmpty {
                    Section(category.title) { supplierRows(rows) }
                }
            }
            let other = results.filter { supplier in !Self.categories.contains { $0.id == supplier.category } }
            if !other.isEmpty { Section("其他供应商") { supplierRows(other) } }
            if SupplierDirectory.all.isEmpty { OfficialWebExperienceSection(query: searchText) }
            Section {
                Button {
                    editor = EditorTarget(model: nil)
                } label: { Label("添加自定义模型", systemImage: "plus") }
            }
        }
        .navigationTitle("供应商与模型").navigationBarTitleDisplayMode(.inline)
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索供应商、模型或网址")
        .sheet(item: $editor) { target in
            ModelEditorView(model: target.model, requiresAPIKey: target.requiresAPIKey).environmentObject(store)
        }
    }

    private func supplierRows(_ rows: [SupplierDirectory.Entry]) -> some View {
        ForEach(rows) { supplier in
            NavigationLink {
                SupplierModelsView(supplier: supplier, initialSearch: searchText)
            } label: {
                HStack(spacing: 12) {
                    ServiceLogo(logo: supplier.models.first?.logo ?? .custom, size: 26).frame(width: 32)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(supplier.name).foregroundStyle(.primary)
                        Text(subtitle(for: supplier)).font(.caption).foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 2)
            }
        }
    }

    private func subtitle(for supplier: SupplierDirectory.Entry) -> String {
        if !supplier.models.isEmpty { return "\(supplier.models.count) 款模型" }
        if supplier.category == "account" { return supplier.externalURL == nil ? "账号服务" : "官网账号入口" }
        if supplier.externalURL != nil { return "官网入口 · 暂无模型预设" }
        return "手动配置"
    }

    @MainActor
    private struct SupplierModelsView: View {
        @EnvironmentObject private var store: ModelStore
        @State private var editor: EditorTarget?
        let supplier: SupplierDirectory.Entry
        let initialSearch: String

        private func matches(_ preset: ModelPreset) -> Bool {
            !initialSearch.isEmpty && [preset.name, preset.modelID, preset.baseURL].contains {
                $0.localizedStandardContains(initialSearch)
            }
        }

        private var models: [ModelPreset] {
            let found = supplier.models.filter(matches)
            return found + supplier.models.filter { !matches($0) }
        }

        var body: some View {
            List {
                if models.isEmpty {
                    Section {
                        Text(supplier.category == "account" ? "请在官方网页登录并使用此服务。" : "目前没有可直接添加的模型预设。请先查阅供应商文档，再手动配置兼容的接口。")
                            .foregroundStyle(.secondary)
                    }
                } else {
                    Section {
                        ForEach(models) { model in
                            Button {
                                editor = EditorTarget(model: model.makeConfiguration(), requiresAPIKey: model.requiresKey)
                            } label: {
                                HStack(alignment: .top, spacing: 12) {
                                    ServiceLogo(logo: model.logo, size: 27).frame(width: 34, height: 38)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(model.name).font(.headline).foregroundStyle(.primary)
                                        if model.name != model.modelID {
                                            Text(model.modelID).font(.caption).foregroundStyle(.secondary)
                                        }
                                        if let host = URL(string: model.baseURL)?.host {
                                            Text(host).font(.caption).foregroundStyle(.secondary)
                                        }
                                        if !model.note.isEmpty {
                                            Text(model.note).font(.caption).foregroundStyle(.secondary)
                                                .fixedSize(horizontal: false, vertical: true)
                                        }
                                    }
                                    Spacer(minLength: 0)
                                    Image(systemName: "plus.circle").font(.system(size: 18)).padding(.top, 4)
                                }
                                .padding(.vertical, 4)
                            }
                            .buttonStyle(.plain)
                        }
                    } header: { Text("选择模型") } footer: { Text("需要供应商的个人 API Key；账号权限、额度和价格以供应商为准。") }
                }
                Section {
                    if let url = supplier.externalURL {
                        Link(destination: url) {
                            Label("打开供应商官网", systemImage: "arrow.up.right")
                        }
                    }
                    if supplier.category != "account" {
                        Button {
                            editor = EditorTarget(model: nil)
                        } label: { Label("添加自定义模型", systemImage: "plus") }
                    }
                }
            }
            .navigationTitle(supplier.name)
            .navigationBarTitleDisplayMode(.inline)
            .sheet(item: $editor) { target in
                ModelEditorView(model: target.model, requiresAPIKey: target.requiresAPIKey).environmentObject(store)
            }
        }
    }
}

private struct OfficialWebExperienceSection: View {
    var query = ""

    private func matches(_ name: String) -> Bool {
        query.isEmpty || name.localizedCaseInsensitiveContains(query)
    }

    var body: some View {
        if ["DeepSeek", "千问", "智谱清言", "GitHub Copilot", "OpenAI Official · Codex", "xAI (Grok) OAuth"].contains(where: matches) {
            Section {
                if matches("DeepSeek") { officialLink("DeepSeek", url: "https://chat.deepseek.com/", logo: .deepseek) }
                if matches("千问") { officialLink("千问", url: "https://www.qianwen.com/", logo: .qwen) }
                if matches("智谱清言") { officialLink("智谱清言", url: "https://chatglm.cn/", logo: .glm) }
                if matches("GitHub Copilot") { officialLink("GitHub Copilot", url: "https://github.com/copilot", logo: .automatic) }
                if matches("OpenAI Official · Codex") { officialLink("OpenAI Official · Codex", url: "https://chatgpt.com/codex", logo: .openai) }
                if matches("xAI (Grok) OAuth") { officialLink("xAI (Grok)", url: "https://grok.com/", logo: .automatic) }
            } header: { Text("官方账号与网页") } footer: {
                Text("在浏览器打开官网，登录与使用由各服务商管理。")
            }
        }
        if matches("Astron Coding Plan · 讯飞星辰") {
            Section {
                officialLink("Astron Coding Plan", url: "https://www.xfyun.cn/doc/spark/CodingPlan.html", logo: .automatic)
            } header: { Text("套餐文档") } footer: {
                Text("查看讯飞 Coding Plan 的订阅和支持的编程工具。")
            }
        }
    }

    private func officialLink(_ name: String, url: String, logo: ModelLogo) -> some View {
        Link(destination: URL(string: url)!) {
            HStack(spacing: 12) {
                ServiceLogo(logo: logo, size: 23).frame(width: 30)
                Text(name).foregroundStyle(.primary)
                Spacer()
                Image(systemName: "arrow.up.right").font(.system(size: 12)).foregroundStyle(.secondary)
            }.frame(minHeight: 35)
        }
    }
}

@MainActor
struct ModelEditorView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    let model: ModelConfiguration?
    private let requiresAPIKey: Bool
    @State private var modelID: UUID
    @State private var name: String
    @State private var identifier: String
    @State private var baseURL: String
    @State private var apiProtocol: APIProtocol
    @State private var logo: ModelLogo
    @State private var key = ""
    @State private var initialKey = ""
    @State private var didLoadKey = false
    @State private var showKey = false
    @State private var failure: String?
    @State private var confirmDiscard = false
    @State private var confirmDelete = false

    init(model: ModelConfiguration?, requiresAPIKey: Bool = false) {
        self.model = model
        self.requiresAPIKey = requiresAPIKey
        _modelID = State(initialValue: model?.id ?? UUID())
        _name = State(initialValue: model?.name ?? "")
        _identifier = State(initialValue: model?.modelID ?? "")
        _baseURL = State(initialValue: model?.baseURL ?? "")
        _apiProtocol = State(initialValue: model?.apiProtocol ?? .openAI)
        _logo = State(initialValue: model?.logo ?? .automatic)
    }

    private var configuration: ModelConfiguration {
        ModelConfiguration(id: modelID, name: name.trimmingCharacters(in: .whitespacesAndNewlines),
                           modelID: identifier.trimmingCharacters(in: .whitespacesAndNewlines),
                           baseURL: baseURL.trimmingCharacters(in: .whitespacesAndNewlines), apiProtocol: apiProtocol, logo: logo)
    }

    private var hasChanges: Bool {
        if let model { return configuration != model || key != initialKey }
        return !name.isEmpty || !identifier.isEmpty || !baseURL.isEmpty || !key.isEmpty || apiProtocol != .openAI || logo != .automatic
    }

    private var isExistingModel: Bool {
        guard let model else { return false }
        return store.models.contains { $0.id == model.id }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        ServiceLogo(logo: configuration.resolvedLogo, size: 40)
                            .frame(width: 60, height: 60).background(HubStyle.grouped, in: RoundedRectangle(cornerRadius: 18))
                        VStack(alignment: .leading, spacing: 5) {
                            Text(name.isEmpty ? "自定义模型" : name).font(.system(size: 21, weight: .semibold)).lineLimit(1)
                            Text("配置自己的模型连接").font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 8)
                }.listRowBackground(Color.clear)
                Section {
                    TextField("显示名称", text: $name)
                    TextField("模型 ID", text: $identifier).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Picker("接口协议", selection: $apiProtocol) { ForEach(APIProtocol.allCases) { Text($0.title).tag($0) } }
                } header: { Text("基本信息") } footer: { Text("支持填写任意模型 ID；服务商接口须符合所选协议。名称不代表连接已验证。") }
                Section {
                    TextField("https://…", text: $baseURL).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                } header: { Text("接口地址") } footer: { Text("填写服务商提供的 Base URL。远程接口使用 HTTPS，本机接口可使用 HTTP 回环地址。") }
                Section {
                    HStack {
                        Group { if showKey { TextField("API Key · 按服务商要求填写", text: $key) } else { SecureField("API Key · 按服务商要求填写", text: $key) } }
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash" : "eye").frame(width: 35, height: 35) }
                            .buttonStyle(.borderless).accessibilityLabel(showKey ? "隐藏密钥" : "显示密钥")
                    }
                } header: { Text("API Key") } footer: { Text("无需鉴权的接口可留空。密钥保存在此设备的钥匙串中，不随模型配置文件保存。") }
                Section {
                    Picker("模型图标", selection: $logo) { ForEach(ModelLogo.allCases) { Text($0.title).tag($0) } }
                } footer: { Text("自动识别常见模型标识；未知模型显示通用标识，也可手动选择。首页会随模型一起更新。") }
                if let failure { Section { Text(failure).font(.footnote).foregroundStyle(.red).textSelection(.enabled) } }
                if isExistingModel {
                    Section { Button("删除模型", role: .destructive) { confirmDelete = true } }
                }
            }
            .navigationTitle(isExistingModel ? "编辑模型" : "添加模型").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { if hasChanges { confirmDiscard = true } else { dismiss() } } }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                Button(action: save) { Text("保存模型").font(.system(size: 16, weight: .semibold)).frame(maxWidth: .infinity).frame(height: 51) }
                    .buttonStyle(.borderedProminent).foregroundStyle(HubStyle.background)
                    .padding(.horizontal, 20).padding(.top, 12).padding(.bottom, 12).background(.regularMaterial)
            }
            .interactiveDismissDisabled(hasChanges)
            .confirmationDialog("放弃未保存的更改？", isPresented: $confirmDiscard, titleVisibility: .visible) {
                Button("放弃更改", role: .destructive) { dismiss() }
                Button("保留编辑", role: .cancel) { }
            }
            .confirmationDialog("删除这个模型？", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("删除模型", role: .destructive) {
                    if let model { do { try store.delete(model); dismiss() } catch { failure = error.localizedDescription } }
                }
                Button("取消", role: .cancel) { }
            }
            .onAppear {
                if !didLoadKey {
                    key = model.map { store.key(for: $0) } ?? ""
                    initialKey = key
                    didLoadKey = true
                }
            }
        }
    }

    private func save() {
        guard !configuration.name.isEmpty else { failure = "请填写显示名称。"; return }
        guard !configuration.modelID.isEmpty else { failure = "请填写模型 ID。"; return }
        guard !configuration.baseURL.isEmpty else { failure = "请填写接口地址。"; return }
        guard !requiresAPIKey || !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { failure = "此官方预设需要服务商 API Key，请先填写。"; return }
        do { try store.save(configuration, key: key); store.selectedID = configuration.id; dismiss() }
        catch { failure = error.localizedDescription }
    }
}

@MainActor
struct SettingsView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    @State private var showModels = false
    @State private var showKey = false

    var body: some View {
        NavigationStack {
            Form {
                Section("模型") {
                    Button { showModels = true } label: { Label("模型与 API 配置", systemImage: "slider.horizontal.3") }
                    NavigationLink { PresetPickerView().environmentObject(store) } label: { Label("供应商与模型", systemImage: "square.grid.2x2") }
                    Button { showKey = true } label: { Label("OpenRouter Key", systemImage: "key") }
                }
                Section {
                    Picker("主题", selection: $store.theme) { ForEach(AppTheme.allCases) { Text($0.title).tag($0) } }
                } header: { Text("外观") } footer: { Text("默认跟随 iPhone 的系统外观。") }
                Section {
                    Toggle("每天自动更新", isOn: $store.autoRefresh)
                    HStack(alignment: .firstTextBaseline) {
                        Text("最近更新")
                        Spacer()
                        Text(store.lastRefresh.map { $0.formatted(date: .abbreviated, time: .shortened) } ?? "尚未获取")
                            .font(.system(size: 13)).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
                    }
                    Button {
                        Task { await store.refreshFreeModels(force: true) }
                    } label: {
                        HStack { Text("立即刷新"); Spacer(); if store.isRefreshing { ProgressView() } else { Image(systemName: "arrow.clockwise") } }
                    }.disabled(store.isRefreshing)
                    if let error = store.discoveryError { Text(error).font(.footnote).foregroundStyle(.red).textSelection(.enabled) }
                } header: { Text("免费模型目录") } footer: {
                    Text("开启后每日检查 OpenRouter 目录，回到 App 时补充刷新。iOS 后台运行由系统安排，无法保证固定时刻执行。标价、额度与可用性以服务商为准。")
                }
                Section {
                    Toggle("自动同步推荐与公告", isOn: $store.autoCloudSync)
                    Text(store.cloudSyncStatus).font(.subheadline).foregroundStyle(.secondary)
                    HStack(alignment: .firstTextBaseline) {
                        Text("最近同步成功")
                        Spacer()
                        Text(store.lastCloudSync.map { $0.formatted(date: .abbreviated, time: .shortened) } ?? "尚未同步")
                            .font(.system(size: 13)).foregroundStyle(.secondary).multilineTextAlignment(.trailing)
                    }
                    Button {
                        Task { await store.syncCloudCatalog(force: true) }
                    } label: {
                        HStack { Text("立即同步推荐与公告"); Spacer(); if store.isSyncingCloud { ProgressView() } else { Image(systemName: "arrow.clockwise") } }
                    }.disabled(store.isSyncingCloud)
                    if let error = store.cloudSyncError { Text(verbatim: error).font(.footnote).foregroundStyle(.red).textSelection(.enabled) }
                    if let manifest = store.cloudManifest {
                        if !manifest.announcement.isEmpty {
                            VStack(alignment: .leading, spacing: 7) {
                                Text("公告").font(.subheadline.weight(.medium))
                                Text(verbatim: manifest.announcement).font(.subheadline).textSelection(.enabled)
                            }.padding(.vertical, 4)
                        }
                        HStack {
                            Text("云端最新版本")
                            Spacer()
                            Text(verbatim: manifest.latestVersion).foregroundStyle(.secondary)
                        }
                    }
                    Link(destination: CloudCatalog.releaseURL) {
                        HStack {
                            Text(store.hasNewRelease ? "发现新版本 · 前往下载安装" : "查看最新安装包")
                            Spacer()
                            Image(systemName: "arrow.up.right").font(.system(size: 12))
                        }
                    }
                } header: { Text("云端推荐与公告") } footer: {
                    Text("默认开启，在打开或回到 App 时检查；同步成功后一小时内不重复自动检查。仅获取公开目录，不上传模型配置、Key 或对话。推荐需要你手动添加保存，原生应用新版本需手动安装。")
                }
                Section {
                    NavigationLink { AboutView() } label: { Label("关于 星枢 StarHub", systemImage: "info.circle") }
                }
                OfficialWebExperienceSection()
            }
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .sheet(isPresented: $showModels) { ModelPickerView().environmentObject(store) }
            .sheet(isPresented: $showKey) { OpenRouterKeyView().environmentObject(store) }
        }
    }
}

@MainActor
struct OpenRouterKeyView: View {
    @EnvironmentObject private var store: ModelStore
    @Environment(\.dismiss) private var dismiss
    @State private var key = ""
    @State private var initialKey = ""
    @State private var loaded = false
    @State private var failure: String?
    @State private var showKey = false
    @State private var confirmDiscard = false

    private var hasChanges: Bool { key != initialKey }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Group { if showKey { TextField("OpenRouter API Key", text: $key) } else { SecureField("OpenRouter API Key", text: $key) } }
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash" : "eye").frame(width: 35, height: 35) }
                            .buttonStyle(.borderless).accessibilityLabel(showKey ? "隐藏密钥" : "显示密钥")
                    }
                } header: { Text("免费目录的通用 Key") } footer: {
                    Text("目录内的免费模型仍需你自己的 OpenRouter Key。密钥保存在设备钥匙串中；免费额度和服务可用性由 OpenRouter 决定。")
                }
                if let failure { Section { Text(failure).font(.footnote).foregroundStyle(.red) } }
            }
            .navigationTitle("OpenRouter Key").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") {
                        if hasChanges { confirmDiscard = true }
                        else { dismiss() }
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        do { try store.setOpenRouterKey(key.trimmingCharacters(in: .whitespacesAndNewlines)); dismiss() }
                        catch { failure = error.localizedDescription }
                    }
                }
            }
            .interactiveDismissDisabled(hasChanges)
            .confirmationDialog("放弃未保存的密钥更改？", isPresented: $confirmDiscard, titleVisibility: .visible) {
                Button("放弃更改", role: .destructive) { dismiss() }
                Button("保留编辑", role: .cancel) { }
            }
            .onAppear {
                if !loaded {
                    key = store.openRouterKey()
                    initialKey = key
                    loaded = true
                }
            }
        }
    }
}

@MainActor
struct AboutView: View {
    @State private var copied: String?
    var body: some View {
        List {
            Section {
                VStack(spacing: 14) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 27, style: .continuous)
                            .fill(LinearGradient(colors: [Color(red: 0.10, green: 0.17, blue: 0.36), Color(red: 0.25, green: 0.36, blue: 0.72)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        Circle().stroke(.white.opacity(0.12), lineWidth: 1).frame(width: 65, height: 65)
                        Text("GJ").font(.system(size: 29, weight: .semibold, design: .rounded)).foregroundStyle(.white)
                        Image(systemName: "sparkle").font(.system(size: 12, weight: .semibold)).foregroundStyle(Color(red: 0.54, green: 0.91, blue: 0.98)).offset(x: 26, y: -26)
                    }.frame(width: 96, height: 96).accessibilityLabel("GUJIU 开发者头像")
                    VStack(spacing: 5) {
                        Text("GUJIU").font(.system(size: 25, weight: .semibold)).tracking(1)
                        Text("星枢 StarHub 开发者").font(.system(size: 13)).foregroundStyle(.secondary)
                    }
                }.frame(maxWidth: .infinity).padding(.vertical, 15)
            }.listRowBackground(Color.clear)
            Section("联系方式") {
                HStack(alignment: .center, spacing: 8) {
                    Text("邮箱").font(.system(size: 14)).foregroundStyle(.secondary).frame(width: 35, alignment: .leading)
                    Link("gujiu520@proton.me", destination: URL(string: "mailto:gujiu520@proton.me")!)
                        .font(.system(size: 14)).lineLimit(1).minimumScaleFactor(0.85)
                    Spacer(minLength: 0)
                    copyButton("gujiu520@proton.me", label: "邮箱")
                }
                contact("QQ", value: "401738182")
                contact("微信", value: "V909800")
            }
            Section {
                HStack {
                    Text("版本")
                    Spacer()
                    Text("\(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.2.2") · iOS 16+")
                        .foregroundStyle(.secondary)
                }
                Text("支持自定义模型接口。免费模型目录每日检查，实际额度与服务可用性由服务商决定。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            if let copied { Section { Text("已复制\(copied)").font(.footnote).foregroundStyle(HubStyle.accent) } }
        }.navigationTitle("关于 星枢 StarHub").navigationBarTitleDisplayMode(.inline)
    }

    private func contact(_ label: String, value: String) -> some View {
        HStack {
            Text(label).font(.system(size: 14)).foregroundStyle(.secondary).frame(width: 35, alignment: .leading)
            Text(value).font(.system(size: 15)).textSelection(.enabled)
            Spacer()
            copyButton(value, label: label)
        }
    }

    private func copyButton(_ value: String, label: String) -> some View {
        Button {
            UIPasteboard.general.string = value
            copied = label
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { if copied == label { copied = nil } }
        } label: { Image(systemName: "doc.on.doc").font(.system(size: 15)).frame(width: 38, height: 44) }
            .buttonStyle(.borderless).accessibilityLabel("复制\(label)")
    }
}

struct ServiceLogo: View {
    let logo: ModelLogo
    var size: CGFloat = 26

    var body: some View {
        Group {
            switch logo {
            case .openai: OpenAIKnot().stroke(Color.primary, style: StrokeStyle(lineWidth: max(1.4, size * 0.065), lineCap: .round, lineJoin: .round))
            case .anthropic:
                Canvas { context, canvas in
                    var path = Path()
                    let center = CGPoint(x: canvas.width / 2, y: canvas.height / 2)
                    for index in 0..<12 {
                        let angle = Double(index) * .pi / 6
                        let cosine = CGFloat(cos(angle))
                        let sine = CGFloat(sin(angle))
                        let inner: CGFloat = index.isMultiple(of: 2) ? 0.16 : 0.12
                        path.move(to: CGPoint(x: center.x + cosine * canvas.width * inner, y: center.y + sine * canvas.height * inner))
                        path.addLine(to: CGPoint(x: center.x + cosine * canvas.width * 0.46, y: center.y + sine * canvas.height * 0.46))
                    }
                    context.stroke(path, with: .color(Color(red: 0.70, green: 0.39, blue: 0.27)), style: StrokeStyle(lineWidth: max(1.7, canvas.width * 0.055), lineCap: .square))
                }
            case .google:
                GeminiSpark().fill(LinearGradient(colors: [Color(red: 0.30, green: 0.54, blue: 0.94), Color(red: 0.59, green: 0.43, blue: 0.81), Color(red: 0.90, green: 0.49, blue: 0.48)], startPoint: .topLeading, endPoint: .bottomTrailing))
            case .deepseek:
                DeepSeekWhale().fill(Color(red: 0.31, green: 0.43, blue: 0.87), style: FillStyle(eoFill: true))
            case .qwen:
                Text("Q").font(.system(size: size * 0.83, weight: .bold, design: .rounded)).foregroundStyle(Color(red: 0.40, green: 0.30, blue: 0.85))
            case .glm:
                Text("GL").font(.system(size: size * 0.53, weight: .bold, design: .rounded)).foregroundStyle(Color(red: 0.22, green: 0.42, blue: 0.83))
            case .kimi:
                Text("K").font(.system(size: size * 0.83, weight: .bold, design: .rounded)).foregroundStyle(Color.primary)
            case .baidu:
                Text("文").font(.system(size: size * 0.75, weight: .semibold)).foregroundStyle(Color(red: 0.24, green: 0.39, blue: 0.86))
            case .automatic, .custom:
                StarHubBrandMark()
            }
        }.frame(width: size, height: size).accessibilityHidden(true)
    }
}

private struct StarHubBrandMark: View {
    var body: some View {
        Canvas { context, canvas in
            func point(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: x / 1024 * canvas.width, y: y / 1024 * canvas.height) }
            // Geometry and transparent colors match StarHub-symbol.svg.
            let orbitColor = Color(red: 68.0 / 255, green: 172.0 / 255, blue: 209.0 / 255)
            let starColor = Color(red: 100.0 / 255, green: 124.0 / 255, blue: 1)
            var orbit = Path()
            orbit.move(to: point(733.139, 258.084))
            orbit.addCurve(to: point(816.737, 589.999), control1: point(860.384, 320.12), control2: point(895.385, 459.087))
            orbit.addCurve(to: point(409.764, 796.35), control1: point(738.089, 720.911), control2: point(567.696, 807.306))
            orbit.addCurve(to: point(167.372, 544.949), control1: point(251.831, 785.393), control2: point(150.346, 680.135))
            orbit.addCurve(to: point(479.769, 240.506), control1: point(184.399, 409.762), control2: point(315.194, 282.297))
            context.stroke(orbit, with: .color(orbitColor), style: StrokeStyle(lineWidth: canvas.width * 37 / 1024, lineCap: .round))
            for node in [(733.139, 258.084, 29.0), (479.769, 240.506, 25.0), (281.687, 761.223, 25.0)] {
                let center = point(CGFloat(node.0), CGFloat(node.1))
                let radius = CGFloat(node.2) / 1024 * canvas.width
                context.fill(Path(ellipseIn: CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2)), with: .color(orbitColor))
            }
            var star = Path()
            for index in 0..<10 {
                let angle = Double(index) * .pi / 5 - .pi / 2
                let radius: CGFloat = index.isMultiple(of: 2) ? 220 : 112
                let vertex = point(512 + CGFloat(cos(angle)) * radius, 512 + CGFloat(sin(angle)) * radius)
                if index == 0 { star.move(to: vertex) } else { star.addLine(to: vertex) }
            }
            star.closeSubpath()
            context.fill(star, with: .color(starColor))
        }
    }
}

private struct OpenAIKnot: Shape {
    func path(in rect: CGRect) -> Path {
        var unit = Path()
        for index in 0..<6 {
            var segment = Path()
            segment.move(to: CGPoint(x: 8.1, y: 12))
            segment.addLine(to: CGPoint(x: 8.1, y: 6.4))
            segment.addCurve(to: CGPoint(x: 16.23, y: 5.23), control1: CGPoint(x: 8.1, y: 1.1), control2: CGPoint(x: 14.9, y: 0.3))
            segment.move(to: CGPoint(x: 11.78, y: 6.33))
            segment.addLine(to: CGPoint(x: 8.1, y: 8.47))
            let rotation = CGAffineTransform(translationX: -12, y: -12)
                .concatenating(CGAffineTransform(rotationAngle: CGFloat(index) * .pi / 3))
                .concatenating(CGAffineTransform(translationX: 12, y: 12))
            unit.addPath(segment, transform: rotation)
        }
        return unit.applying(CGAffineTransform(scaleX: rect.width / 24, y: rect.height / 24).translatedBy(x: rect.minX, y: rect.minY))
    }
}

private struct GeminiSpark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 0.5, y: 0.02))
        path.addCurve(to: CGPoint(x: 0.98, y: 0.5), control1: CGPoint(x: 0.57, y: 0.34), control2: CGPoint(x: 0.66, y: 0.43))
        path.addCurve(to: CGPoint(x: 0.5, y: 0.98), control1: CGPoint(x: 0.66, y: 0.57), control2: CGPoint(x: 0.57, y: 0.66))
        path.addCurve(to: CGPoint(x: 0.02, y: 0.5), control1: CGPoint(x: 0.43, y: 0.66), control2: CGPoint(x: 0.34, y: 0.57))
        path.addCurve(to: CGPoint(x: 0.5, y: 0.02), control1: CGPoint(x: 0.34, y: 0.43), control2: CGPoint(x: 0.43, y: 0.34))
        return path.applying(CGAffineTransform(scaleX: rect.width, y: rect.height))
    }
}

private struct DeepSeekWhale: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 0.06, y: 0.45))
        path.addCurve(to: CGPoint(x: 0.39, y: 0.43), control1: CGPoint(x: 0.20, y: 0.59), control2: CGPoint(x: 0.29, y: 0.57))
        path.addCurve(to: CGPoint(x: 0.77, y: 0.37), control1: CGPoint(x: 0.51, y: 0.26), control2: CGPoint(x: 0.64, y: 0.28))
        path.addCurve(to: CGPoint(x: 0.96, y: 0.26), control1: CGPoint(x: 0.82, y: 0.29), control2: CGPoint(x: 0.90, y: 0.30))
        path.addCurve(to: CGPoint(x: 0.88, y: 0.55), control1: CGPoint(x: 0.93, y: 0.38), control2: CGPoint(x: 0.97, y: 0.48))
        path.addCurve(to: CGPoint(x: 0.45, y: 0.83), control1: CGPoint(x: 0.82, y: 0.78), control2: CGPoint(x: 0.65, y: 0.84))
        path.addCurve(to: CGPoint(x: 0.06, y: 0.45), control1: CGPoint(x: 0.24, y: 0.82), control2: CGPoint(x: 0.10, y: 0.67))
        path.closeSubpath()
        path.addEllipse(in: CGRect(x: 0.69, y: 0.45, width: 0.055, height: 0.055))
        return path.applying(CGAffineTransform(scaleX: rect.width, y: rect.height))
    }
}
