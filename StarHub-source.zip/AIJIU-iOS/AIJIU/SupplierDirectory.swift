import Foundation

enum SupplierDirectory {
    struct Entry: Decodable, Identifiable {
        let name: String
        let website: String
        let category: String
        let aliases: [String]
        var models: [ModelPreset]

        var id: String { SupplierDirectory.key(name) }

        var externalURL: URL? {
            guard let parts = URLComponents(string: website), parts.scheme == "https",
                  let host = parts.host, host.contains("."), !host.contains(":"), !host.allSatisfy({ $0.isNumber || $0 == "." }),
                  host != "localhost", !host.hasSuffix(".localhost"), !host.hasSuffix(".local"),
                  parts.user == nil, parts.password == nil, parts.query == nil, parts.fragment == nil,
                  parts.port == nil || parts.port == 443 else { return nil }
            return parts.url
        }
    }

    static let all: [Entry] = {
        guard let url = Bundle.main.url(forResource: "supplier-directory", withExtension: "json"),
              let data = try? Data(contentsOf: url), data.count < 512 * 1024,
              let entries = try? JSONDecoder().decode([Entry].self, from: data) else { return [] }
        var seen = Set<String>()
        return entries.filter { !$0.id.isEmpty && seen.insert($0.id).inserted }
    }()

    private static func key(_ text: String) -> String {
        let folded = text.folding(options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive], locale: Locale(identifier: "en_US_POSIX"))
        return String(folded.filter { $0.isLetter || $0.isNumber })
    }

    static func grouped(presets: [ModelPreset]) -> [Entry] {
        grouped(entries: all, presets: presets)
    }

    static func grouped(entries: [Entry], presets: [ModelPreset]) -> [Entry] {
        var result = entries
        var indexByAlias = [String: Int]()
        for (index, entry) in result.enumerated() {
            for alias in [entry.name] + entry.aliases {
                let normalized = key(alias)
                if !normalized.isEmpty, indexByAlias[normalized] == nil { indexByAlias[normalized] = index }
            }
        }
        for preset in presets {
            let normalized = key(preset.provider)
            guard !normalized.isEmpty else { continue }
            if let index = indexByAlias[normalized] {
                if let existing = result[index].models.firstIndex(where: { $0.id == preset.id }) {
                    result[index].models[existing] = preset
                } else if !result[index].models.contains(where: {
                    $0.modelID == preset.modelID && $0.baseURL == preset.baseURL && $0.apiProtocol == preset.apiProtocol
                }) {
                    result[index].models.append(preset)
                }
            } else {
                indexByAlias[normalized] = result.count
                result.append(Entry(name: preset.provider, website: "", category: "official", aliases: [], models: [preset]))
            }
        }
        return result
    }
}
