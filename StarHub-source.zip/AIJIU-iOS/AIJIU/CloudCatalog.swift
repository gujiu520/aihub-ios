import Foundation

// This file deliberately depends only on Foundation so CI can run the real parser
// without loading SwiftUI, Keychain, the network client, or application state.
struct CloudPreset: Codable, Equatable {
    let id: String
    let name: String
    let modelID: String
    let baseURL: String
    let apiProtocol: String
    let logo: String
    let provider: String
    let category: String
    let requiresKey: Bool
    let freeCatalog: Bool
    let note: String

    enum CodingKeys: String, CodingKey {
        case id, name, modelID, baseURL, logo, provider, category, requiresKey, freeCatalog, note
        case apiProtocol = "protocol"
    }
}

struct CloudCatalogManifest: Codable, Equatable {
    let schemaVersion: Int
    let revision: Int
    let updatedAt: String
    let announcement: String
    let latestVersion: String
    let releaseURL: String
    let presets: [CloudPreset]
}

struct CloudVersion: Comparable {
    private let components: [Int]

    init?(_ text: String) {
        guard text.range(of: #"^(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})$"#, options: .regularExpression) != nil else { return nil }
        let values = text.split(separator: ".").compactMap { Int($0) }
        guard values.count == 3 else { return nil }
        components = values
    }

    static func < (lhs: Self, rhs: Self) -> Bool {
        lhs.components.lexicographicallyPrecedes(rhs.components)
    }
}

enum CloudCatalogError: LocalizedError {
    case oversized, malformed, unsupportedSchema, rollback, invalidResponse

    var errorDescription: String? {
        switch self {
        case .oversized: return "云端目录超过 256 KiB 限制。"
        case .malformed: return "云端目录格式或内容未通过校验。"
        case .unsupportedSchema: return "此版本暂不支持新的云端目录格式。"
        case .rollback: return "云端目录版本较旧，已拒绝回退。"
        case .invalidResponse: return "云端目录服务器未返回有效响应。"
        }
    }
}

enum CloudCatalog {
    static let maximumBytes = 256 * 1024
    static let manifestURL = URL(string: "https://raw.githubusercontent.com/gujiu520/aihub-ios/main/catalog.json")!
    static let releaseURL = URL(string: "https://github.com/gujiu520/aihub-ios/releases/latest")!

    static func parse(_ data: Data, minimumRevision: Int = 0) throws -> CloudCatalogManifest {
        guard data.count <= maximumBytes else { throw CloudCatalogError.oversized }
        let manifest: CloudCatalogManifest
        do { manifest = try JSONDecoder().decode(CloudCatalogManifest.self, from: data) }
        catch { throw CloudCatalogError.malformed }
        guard manifest.schemaVersion == 1 else { throw CloudCatalogError.unsupportedSchema }
        guard manifest.revision > 0,
              text(manifest.updatedAt, maximum: 64), validTimestamp(manifest.updatedAt),
              text(manifest.announcement, maximum: 2000, allowEmpty: true, multiline: true),
              CloudVersion(manifest.latestVersion) != nil,
              manifest.releaseURL == releaseURL.absoluteString,
              (1...100).contains(manifest.presets.count) else { throw CloudCatalogError.malformed }
        var seen = Set<String>()
        for item in manifest.presets {
            guard text(item.id, maximum: 128), item.id == item.id.trimmingCharacters(in: .whitespacesAndNewlines),
                  seen.insert(item.id).inserted,
                  text(item.name, maximum: 128), text(item.modelID, maximum: 256),
                  text(item.baseURL, maximum: 2048), safeEndpoint(item.baseURL),
                  ["openAI", "anthropic", "gemini"].contains(item.apiProtocol),
                  ["automatic", "openai", "anthropic", "google", "deepseek", "qwen", "glm", "kimi", "baidu", "custom"].contains(item.logo),
                  text(item.provider, maximum: 128), ["large", "domestic-free"].contains(item.category),
                  item.requiresKey, !item.freeCatalog,
                  text(item.note, maximum: 2000, allowEmpty: true, multiline: true) else { throw CloudCatalogError.malformed }
        }
        guard manifest.revision >= minimumRevision else { throw CloudCatalogError.rollback }
        return manifest
    }

    private static func text(_ value: String, maximum: Int, allowEmpty: Bool = false, multiline: Bool = false) -> Bool {
        guard value.count <= maximum,
              allowEmpty || !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        let permitted = multiline ? CharacterSet(charactersIn: "\n\r\t") : CharacterSet()
        return !value.unicodeScalars.contains { CharacterSet.controlCharacters.contains($0) && !permitted.contains($0) }
    }

    private static func validTimestamp(_ value: String) -> Bool {
        guard value.range(of: #"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,9})?(Z|[+-][0-9]{2}:[0-9]{2})$"#, options: .regularExpression) != nil else { return false }
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = value.contains(".") ? [.withInternetDateTime, .withFractionalSeconds] : [.withInternetDateTime]
        return formatter.date(from: value) != nil
    }

    private static func safeEndpoint(_ value: String) -> Bool {
        guard value == value.trimmingCharacters(in: .whitespacesAndNewlines),
              let parts = URLComponents(string: value), parts.scheme?.lowercased() == "https",
              parts.user == nil, parts.password == nil, parts.query == nil, parts.fragment == nil,
              let rawHost = parts.host, !rawHost.isEmpty, let url = parts.url, url.host != nil else { return false }
        let host = rawHost.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
        guard host != "localhost", !host.hasSuffix(".localhost") else { return false }
        // Recommendations use public DNS names or canonical IPv4. Reject IPv6,
        // numeric aliases, octal/hex IPv4 and malformed hosts conservatively;
        // saved/custom endpoints retain their existing validation separately.
        guard host.range(of: #"^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$"#, options: .regularExpression) != nil else { return false }
        let labels = host.split(separator: ".", omittingEmptySubsequences: false)
        guard labels.allSatisfy({ !$0.isEmpty && $0.count <= 63 && !$0.hasPrefix("-") && !$0.hasSuffix("-") }) else { return false }
        let numeric = labels.allSatisfy { label in
            label.allSatisfy(\.isNumber) || (label.hasPrefix("0x") && label.dropFirst(2).allSatisfy(\.isHexDigit))
        }
        if numeric {
            guard labels.count == 4,
                  labels.allSatisfy({ label in
                      label.allSatisfy(\.isNumber) && (label.count == 1 || !label.hasPrefix("0")) && UInt8(label) != nil
                  }), let first = labels.first, first != "127", first != "0" else { return false }
        }
        return true
    }
}
