import Foundation

struct ChatSession: Identifiable, Codable {
    var id = UUID()
    var modelID: UUID?
    var skill: ChatSkill?
    var updatedAt = Date()
    var messages: [ChatMessage] = []

    var title: String {
        guard let first = messages.first(where: { $0.role == .user }) else { return "新聊天" }
        let summary = first.content.split(whereSeparator: \.isWhitespace).joined(separator: " ")
        return summary.isEmpty ? "附件对话" : String(summary.prefix(60))
    }
}

struct ChatHistory: Codable {
    var activeID: UUID?
    var sessions: [ChatSession] = []

    var active: ChatSession? { sessions.first { $0.id == activeID } }

    mutating func start(modelID: UUID?) {
        if let active, active.messages.isEmpty { return }
        let session = ChatSession(modelID: modelID)
        activeID = session.id
        sessions.insert(session, at: 0)
    }

    mutating func updateActive(_ change: (inout ChatSession) -> Void) {
        guard let index = sessions.firstIndex(where: { $0.id == activeID }) else { return }
        change(&sessions[index])
    }

    private static let maximumBytes = 64 * 1024 * 1024

    static func load(from file: URL) throws -> ChatHistory {
        guard FileManager.default.fileExists(atPath: file.path) else { return ChatHistory() }
        guard let size = try file.resourceValues(forKeys: [.fileSizeKey]).fileSize, size <= maximumBytes else {
            throw CocoaError(.fileReadTooLarge)
        }
        return try JSONDecoder().decode(Self.self, from: Data(contentsOf: file))
    }

    func save(to file: URL) throws {
        let data = try JSONEncoder().encode(self)
        guard data.count <= Self.maximumBytes else {
            throw CocoaError(.fileWriteOutOfSpace)
        }
        #if os(iOS)
        try data.write(to: file, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        #else
        try data.write(to: file, options: .atomic)
        #endif
    }

    static func localFile() throws -> URL {
        var folder = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                                 appropriateFor: nil, create: true)
        folder.appendPathComponent("StarHubHistory", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try folder.setResourceValues(values)
        return folder.appendingPathComponent("conversations.json")
    }
}
