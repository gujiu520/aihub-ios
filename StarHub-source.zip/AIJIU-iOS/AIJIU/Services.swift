import Foundation
import CoreFoundation
import CryptoKit
import BackgroundTasks

enum EndpointValidation {
    static func isLoopback(_ url: URL) -> Bool {
        let host = (url.host ?? "").lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "[]"))
        return ["localhost", "127.0.0.1", "::1"].contains(host)
    }
    static func validate(_ text: String) throws -> URL {
        guard let parts = URLComponents(string: text), let scheme = parts.scheme?.lowercased(), let host = parts.host, !host.isEmpty,
              parts.user == nil, parts.password == nil, parts.query == nil, parts.fragment == nil, let url = parts.url,
              scheme == "https" || (scheme == "http" && isLoopback(url)) else {
            throw AIHubError.configuration("接口地址需要使用 HTTPS；仅本机 localhost / 127.0.0.1 / ::1 可用 HTTP。地址不能包含密钥、查询参数或片段。")
        }
        return url
    }
    static func endpoint(base: String, api: APIProtocol, modelID: String) throws -> URL {
        let url = try validate(base)
        guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { throw AIHubError.configuration("接口地址无效。") }
        var path = components.percentEncodedPath.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        switch api {
        case .openAI:
            if path.isEmpty { path = "v1" }
            if !path.hasSuffix("chat/completions") { path += "/chat/completions" }
        case .anthropic:
            if path.isEmpty { path = "v1" }
            if !path.hasSuffix("messages") { path += "/messages" }
        case .gemini:
            if path.isEmpty { path = "v1beta" }
            if !path.hasSuffix(":generateContent") {
                let model = modelID.hasPrefix("models/") ? String(modelID.dropFirst(7)) : modelID
                let allowed = CharacterSet.urlPathAllowed.subtracting(CharacterSet(charactersIn: "/?#%"))
                guard let encoded = model.addingPercentEncoding(withAllowedCharacters: allowed) else { throw AIHubError.configuration("模型 ID 无法用于请求地址。") }
                path += "/models/" + encoded + ":generateContent"
            }
        }
        components.percentEncodedPath = "/" + path
        guard let result = components.url else { throw AIHubError.configuration("无法生成请求地址。") }
        return result
    }
}

private final class RejectRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

private enum Network {
    static let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 60
        config.timeoutIntervalForResource = 90
        config.httpCookieStorage = nil
        config.urlCache = nil
        return URLSession(configuration: config, delegate: RejectRedirects(), delegateQueue: nil)
    }()
    static func json(_ request: URLRequest, secret: String = "") async throws -> [String: Any] {
        let (data, response) = try await session.data(for: request)
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw AIHubError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            let error = object?["error"] as? [String: Any]
            var message = error?["message"] as? String ?? "服务商没有返回可用结果。"
            if !secret.isEmpty { message = message.replacingOccurrences(of: secret, with: "[密钥已隐藏]") }
            message = message.replacingOccurrences(of: #"sk-[A-Za-z0-9_\-]+"#, with: "[密钥已隐藏]", options: .regularExpression)
            throw AIHubError.service(http.statusCode, String(message.prefix(220)))
        }
        guard let result = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw AIHubError.invalidResponse }
        return result
    }
}

private final class CloudCatalogSessionDelegate: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
            completionHandler(.performDefaultHandling, nil)
        } else {
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
}

enum CloudCatalogClient {
    // Dedicated public-data session: never shares chat headers, credentials,
    // cookies, URL caches, or any request payload with model-provider traffic.
    private static let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 30
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        config.urlCredentialStorage = nil
        config.urlCache = nil
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: config, delegate: CloudCatalogSessionDelegate(), delegateQueue: nil)
    }()

    static func fetch() async throws -> Data {
        var request = URLRequest(url: CloudCatalog.manifestURL, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        request.httpMethod = "GET"
        request.httpShouldHandleCookies = false
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (bytes, response) = try await session.bytes(for: request)
        defer { bytes.task.cancel() }
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              http.url == CloudCatalog.manifestURL else { throw CloudCatalogError.invalidResponse }
        if http.expectedContentLength > Int64(CloudCatalog.maximumBytes) { throw CloudCatalogError.oversized }
        var data = Data()
        for try await byte in bytes {
            try Task.checkCancellation()
            guard data.count < CloudCatalog.maximumBytes else { throw CloudCatalogError.oversized }
            data.append(byte)
        }
        return data
    }
}

enum FreeModelCatalog {
    static let baseURL = "https://openrouter.ai/api/v1"
    private static func zero(_ value: Any?) -> Bool {
        if let number = value as? NSNumber { return CFGetTypeID(number) != CFBooleanGetTypeID() && number.doubleValue.isFinite && number.doubleValue == 0 }
        if let string = value as? String, !string.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, let number = Double(string) { return number.isFinite && number == 0 }
        return false
    }
    private static func stableID(_ text: String) -> UUID {
        let bytes = Array(SHA256.hash(data: Data(text.utf8)).prefix(16))
        return UUID(uuid: (bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7], bytes[8], bytes[9], bytes[10], bytes[11], bytes[12], bytes[13], bytes[14], bytes[15]))
    }
    static func parse(_ object: [String: Any]) throws -> [ModelConfiguration] {
        guard let data = object["data"] as? [[String: Any]] else { throw AIHubError.invalidResponse }
        var seen = Set<String>()
        return data.compactMap { item -> ModelConfiguration? in
            guard let id = item["id"] as? String, id.hasSuffix(":free") || id == "openrouter/free", !seen.contains(id),
                  let name = item["name"] as? String, !name.isEmpty,
                  let prices = item["pricing"] as? [String: Any], zero(prices["prompt"]), zero(prices["completion"]),
                  prices.values.allSatisfy({ zero($0) }),
                  let architecture = item["architecture"] as? [String: Any],
                  let inputs = architecture["input_modalities"] as? [String], inputs.contains("text"),
                  let outputs = architecture["output_modalities"] as? [String], outputs.contains("text"),
                  let endpoints = item["endpoints"] as? [String], endpoints.contains("/api/v1/chat/completions") else { return nil }
            seen.insert(id)
            return ModelConfiguration(id: stableID("openrouter:" + id), name: name, modelID: id, baseURL: baseURL, apiProtocol: .openAI, logo: .automatic, isFreeCatalog: true)
        }.sorted { lhs, rhs in
            if lhs.modelID == "openrouter/free" { return true }
            if rhs.modelID == "openrouter/free" { return false }
            return lhs.name.localizedCaseInsensitiveCompare(rhs.name) == .orderedAscending
        }
    }
    static func fetch() async throws -> [ModelConfiguration] {
        var request = URLRequest(url: URL(string: baseURL + "/models")!)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let result = try parse(try await Network.json(request))
        guard !result.isEmpty else { throw AIHubError.configuration("服务商本次没有返回已确认免费的文本聊天模型。") }
        return result
    }
}

enum ChatClient {
    static func send(messages: [ChatMessage], model: ModelConfiguration, key: String) async throws -> String {
        let base = try EndpointValidation.validate(model.baseURL)
        guard !messages.isEmpty else { throw AIHubError.configuration("请先输入消息。") }
        if model.isFreeCatalog {
            guard !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw AIHubError.configuration("免费模型需要你自己的 OpenRouter API Key。") }
            guard model.baseURL == FreeModelCatalog.baseURL, model.apiProtocol == .openAI else { throw AIHubError.freeModelUnavailable }
            let currentFreeModels = try await FreeModelCatalog.fetch()
            guard currentFreeModels.contains(where: { $0.modelID == model.modelID }) else { throw AIHubError.freeModelUnavailable }
        }
        var request = URLRequest(url: try EndpointValidation.endpoint(base: model.baseURL, api: model.apiProtocol, modelID: model.modelID))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        var payload: [String: Any]
        switch model.apiProtocol {
        case .openAI:
            if !key.isEmpty { request.setValue("Bearer " + key, forHTTPHeaderField: "Authorization") }
            payload = ["model": model.modelID, "messages": messages.map { ["role": $0.role.rawValue, "content": $0.content] }, "stream": false]
            let host = (base.host ?? "").lowercased()
            if model.modelID == "qwen3.8-max", host == "aliyuncs.com" || host.hasSuffix(".aliyuncs.com") {
                payload["enable_thinking"] = false
                payload["preserve_thinking"] = false
            }
            if model.modelID.hasPrefix("deepseek-v4"), host == "api.deepseek.com" {
                payload["thinking"] = ["type": "disabled"]
            }
            if model.modelID == "glm-5.3", host == "open.bigmodel.cn" {
                payload["thinking"] = ["type": "enabled"]
                payload["reasoning_effort"] = "low"
            }
            if model.isFreeCatalog { payload["provider"] = ["max_price": ["prompt": 0, "completion": 0]] }
        case .anthropic:
            if !key.isEmpty { request.setValue(key, forHTTPHeaderField: "x-api-key") }
            request.setValue("2026-10-21", forHTTPHeaderField: "anthropic-version")
            payload = ["model": model.modelID, "max_tokens": 2048, "messages": messages.filter { $0.role != .system }.map { ["role": $0.role.rawValue, "content": $0.content] }]
            let system = messages.filter { $0.role == .system }.map(\.content).joined(separator: "\n")
            if !system.isEmpty { payload["system"] = system }
        case .gemini:
            if !key.isEmpty { request.setValue(key, forHTTPHeaderField: "x-goog-api-key") }
            let contents: [[String: Any]] = messages.filter { $0.role != .system }.map { ["role": $0.role == .assistant ? "model" : "user", "parts": [["text": $0.content]]] }
            payload = ["contents": contents, "generationConfig": ["maxOutputTokens": 2048]]
            let system = messages.filter { $0.role == .system }.map(\.content).joined(separator: "\n")
            if !system.isEmpty { payload["systemInstruction"] = ["parts": [["text": system]]] }
        }
        request.httpBody = try JSONSerialization.data(withJSONObject: payload)
        let result = try await Network.json(request, secret: key)
        let text: String
        switch model.apiProtocol {
        case .openAI:
            let choices = result["choices"] as? [[String: Any]]
            let message = choices?.first?["message"] as? [String: Any]
            if let content = message?["content"] as? String { text = content }
            else { text = (message?["content"] as? [[String: Any]] ?? []).compactMap { $0["text"] as? String }.joined(separator: "\n") }
        case .anthropic:
            text = (result["content"] as? [[String: Any]] ?? []).filter { $0["type"] as? String == "text" }.compactMap { $0["text"] as? String }.joined(separator: "\n")
        case .gemini:
            let candidates = result["candidates"] as? [[String: Any]]
            let content = candidates?.first?["content"] as? [String: Any]
            text = (content?["parts"] as? [[String: Any]] ?? []).filter { ($0["thought"] as? Bool) != true }.compactMap { $0["text"] as? String }.joined(separator: "\n")
        }
        let answer = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !answer.isEmpty else { throw AIHubError.emptyResponse }
        return answer
    }
}

enum RefreshScheduler {
    static let identifier = "com.gujiu.aihub.models.refresh"
    static func register() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: identifier, using: nil) { task in
            guard let refresh = task as? BGAppRefreshTask else { task.setTaskCompleted(success: false); return }
            let work = Task { @MainActor in
                let store = ModelStore.shared
                if store.autoRefresh { schedule(); await store.refreshFreeModels(force: false) }
                refresh.setTaskCompleted(success: !Task.isCancelled && store.discoveryError == nil)
            }
            refresh.expirationHandler = { work.cancel() }
        }
    }
    static func schedule() {
        if UserDefaults.standard.object(forKey: "autoRefreshFreeModels") as? Bool == false { cancel(); return }
        let request = BGAppRefreshTaskRequest(identifier: identifier)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 24 * 60 * 60)
        try? BGTaskScheduler.shared.submit(request)
    }
    static func cancel() { BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: identifier) }
}
