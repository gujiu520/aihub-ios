# 星枢 StarHub for Android

原生 Java Android App，Android 8.0+，版本1.2.1（code4），默认跟随系统主题。支持任意自定义模型 ID；服务端须符合所选 OpenAI 兼容／Anthropic／Gemini 协议。包名、本机配置及 Keystore 标识延续 AIJIU 版本，显示名与图标改为星枢 StarHub。

API Key 使用 Android Keystore 加密后保存在本机，不包含开发者共享密钥。OpenRouter 免费目录支持 24 小时前台补刷新、手动刷新及 JobScheduler 最佳努力后台刷新。后台执行不能保证准点。

云端同步独立开关默认开启，打开／返回 App 到期检查公开推荐模型、公告和版本信息，也支持设置中手动同步。先完整校验再缓存，失败保留上次有效目录。不会改写已保存的自定义接口、密钥或当前选择；不执行远程代码。首次需安装本同步版一次；原生功能更新仍需覆盖安装新版。聊天记录保存在设备上，支持重新打开和新建会话。

推荐预设分为旗舰大模型和国内免费 API。模型 ID 与地址可预填，免费 API 仍需个人服务商授权。另设官方网页体验入口，可免填 API Key 打开官方网站，可能需要登录；它们与本 App API 聊天独立。

开发者 GUJIU：gujiu520@proton.me，QQ 401738182，微信 V909800。

构建工具：JDK17、Gradle8.11.1、Android SDK35、AGP8.10.1。开发测试执行 `gradle :app:testDebugUnitTest :app:assembleDebug`。发布构建在安全环境提供 `STARHUB_KEYSTORE_FILE`、`STARHUB_KEYSTORE_PASSWORD`，PKCS12 alias 为 starhub，再执行 `gradle :app:testDebugUnitTest :app:assembleRelease`。请勿把签名私钥或密码写入源码。

GitHub Actions 输出 StarHub-Android-APK，并将固定签名 APK 发布到 Releases。从1.2.0起固定签名，旧 AIJIU1.1临时签名测试包不能保证直接覆盖；未经真机安装、实际服务商推理或商店发布验证。用户已要求公开源码和安装包，签名密钥不公开。

Copyright © 2026 GUJIU. All rights reserved.
