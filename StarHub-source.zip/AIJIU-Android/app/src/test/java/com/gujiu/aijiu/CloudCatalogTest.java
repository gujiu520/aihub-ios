package com.gujiu.aijiu;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import static org.junit.Assert.*;

/** These are JVM tests of the production parser with the real org.json dependency. */
public class CloudCatalogTest {
    private JSONObject preset() throws Exception {
        return new JSONObject().put("id", "deepseek-example").put("name", "DeepSeek")
                .put("modelID", "deepseek-example").put("baseURL", "https://api.deepseek.com/v1")
                .put("protocol", "openAI").put("logo", "deepseek").put("provider", "DeepSeek")
                .put("note", "Use your own API key.").put("category", "large")
                .put("requiresKey", true).put("freeCatalog", false);
    }
    private JSONObject manifest() throws Exception {
        return new JSONObject().put("schemaVersion", 1).put("revision", 7)
                .put("updatedAt", "2026-11-21T12:00:00Z").put("announcement", "New recommendations")
                .put("latestVersion", "1.2.0").put("releaseURL", "https://github.com/gujiu520/aihub-ios/releases/latest")
                .put("presets", new JSONArray().put(preset()));
    }
    private CloudCatalog.Manifest parse(JSONObject json, long minimumRevision) throws Exception {
        return CloudCatalog.parse(json.toString().getBytes(StandardCharsets.UTF_8), minimumRevision);
    }
    private void rejected(JSONObject json) throws Exception { rejected(json.toString().getBytes(StandardCharsets.UTF_8), 0); }
    private void rejected(byte[] json, long minimumRevision) throws Exception {
        try { CloudCatalog.parse(json, minimumRevision); fail("Invalid catalog was accepted"); }
        catch (IllegalArgumentException expected) { }
    }

    @Test public void validCatalogProducesRecommendationsAndAnnouncement() throws Exception {
        CloudCatalog.Manifest value = parse(manifest(), 0);
        assertEquals(7L, value.revision);
        assertEquals("New recommendations", value.announcement);
        assertEquals("1.2.0", value.latestVersion);
        assertEquals(1, value.presets.size());
        assertEquals("https://api.deepseek.com/v1", value.presets.get(0).baseURL);
        assertTrue(value.presets.get(0).requiresKey);
        assertFalse(value.presets.get(0).freeCatalog);
    }
    @Test public void malformedJsonAndTrailingDocumentsAreRejected() throws Exception {
        rejected("{broken".getBytes(StandardCharsets.UTF_8), 0);
        rejected((manifest() + " {}").getBytes(StandardCharsets.UTF_8), 0);
        rejected("[]".getBytes(StandardCharsets.UTF_8), 0);
        rejected("{schemaVersion:1}".getBytes(StandardCharsets.UTF_8),0);
        rejected(manifest().toString().replace("\"schemaVersion\":1", "\"schemaVersion\":1,\"schemaVersion\":1").getBytes(StandardCharsets.UTF_8),0);
        rejected(manifest().toString().replace("\"revision\":7", "\"revision\":07").getBytes(StandardCharsets.UTF_8),0);
        rejected(manifest().toString().replace("\"schemaVersion\":1", "\"schemaVersion\":1,").getBytes(StandardCharsets.UTF_8),0);
    }
    @Test public void emptyAndOversizeBodiesAreRejected() throws Exception {
        rejected(new byte[0], 0);
        rejected(" \n\t ".getBytes(StandardCharsets.UTF_8), 0);
        byte[] bytes = new byte[256 * 1024 + 1]; Arrays.fill(bytes, (byte)' ');
        rejected(bytes, 0);
    }
    @Test public void invalidUtf8IsRejected() throws Exception {
        rejected(new byte[]{(byte)0xc3, (byte)0x28}, 0);
    }
    @Test public void unsupportedSchemaAndNumericStringsAreRejected() throws Exception {
        rejected(manifest().put("schemaVersion", 2));
        rejected(manifest().put("schemaVersion", "1"));
        rejected(manifest().put("schemaVersion", 1.5));
        rejected(manifest().put("revision", "7"));
        rejected(manifest().put("revision", 0));
        rejected(manifest().put("revision", -1));
        rejected(manifest().put("revision", 1.25));
    }
    @Test public void requiredTypesAndFieldsAreNotCoerced() throws Exception {
        JSONObject missing = manifest(); missing.remove("announcement"); rejected(missing);
        rejected(manifest().put("announcement", 42));
        rejected(manifest().put("updatedAt", JSONObject.NULL));
        rejected(manifest().put("presets", new JSONObject()));
        rejected(manifest().put("presets", new JSONArray().put("text")));
        rejected(manifest().put("presets", new JSONArray().put(preset().put("name", 12))));
        rejected(manifest().put("presets", new JSONArray().put(preset().put("requiresKey", "true"))));
    }
    @Test public void duplicateAndBlankIdsRejectEntireCatalog() throws Exception {
        rejected(manifest().put("presets", new JSONArray().put(preset()).put(preset())));
        rejected(manifest().put("presets", new JSONArray().put(preset().put("id", "  "))));
    }
    @Test public void presetCountsAndTextBoundsAreEnforced() throws Exception {
        rejected(manifest().put("presets", new JSONArray()));
        JSONArray many = new JSONArray();
        for (int i=0; i<101; i++) many.put(preset().put("id", "id-" + i));
        rejected(manifest().put("presets", many));
        rejected(manifest().put("announcement", repeat('a', 2001)));
        rejected(manifest().put("presets", new JSONArray().put(preset().put("note", repeat('a', 2001)))));
        rejected(manifest().put("presets", new JSONArray().put(preset().put("name", ""))));
    }
    @Test public void unsupportedEnumsRejectEntireCatalog() throws Exception {
        for (String[] pair : new String[][]{{"protocol","javascript"},{"logo","remote-image"},{"category","custom"}})
            rejected(manifest().put("presets", new JSONArray().put(preset().put(pair[0],pair[1]))));
    }
    @Test public void allSupportedProtocolsAndLogosAreAccepted() throws Exception {
        String[] protocols = {"openAI","anthropic","gemini"};
        String[] logos = {"automatic","openai","anthropic","google","deepseek","qwen","glm","kimi","baidu","custom"};
        for (String protocol : protocols) for (String logo : logos)
            assertEquals(protocol, parse(manifest().put("presets", new JSONArray().put(preset().put("protocol",protocol).put("logo",logo).put("category","domestic-free"))),0).presets.get(0).protocol);
    }
    @Test public void unsafeUrlsRejectEntireCatalog() throws Exception {
        String[] bad = {"http://api.example.com/v1","https://user:secret@api.example.com/v1","https://api.example.com/v1?key=secret","https://api.example.com/v1#secret","file:///tmp/file","https://localhost/v1","https://localhost./v1","https://127.0.0.1/v1","https://127.2.3.4/v1","https://[::1]/v1","https://[0:0:0:0::1]/v1","https://[::ffff:7f00:1]/v1","https://0.0.0.0/v1","https://api.example.com/with space","https://api.example.com:99999/v1","https:///v1"};
        for(String url:bad) rejected(manifest().put("presets",new JSONArray().put(preset().put("baseURL",url))));
    }
    @Test public void catalogCannotClaimNoKeyOrInjectFreeModels() throws Exception {
        rejected(manifest().put("presets",new JSONArray().put(preset().put("requiresKey",false))));
        rejected(manifest().put("presets",new JSONArray().put(preset().put("freeCatalog",true))));
    }
    @Test public void releaseLinkIsFixedAndVersionsAreNumeric() throws Exception {
        rejected(manifest().put("releaseURL","https://example.com/download"));
        for(String version:new String[]{"1.2","v1.2.0","1.2.0-beta","1.02.0","1.2.0.0","1.-2.0"}) rejected(manifest().put("latestVersion",version));
        assertTrue(CloudCatalog.compareVersions("1.10.0","1.2.9") > 0);
        assertTrue(CloudCatalog.compareVersions("2.0.0","1.999.999") > 0);
        assertEquals(0,CloudCatalog.compareVersions("1.2.0","1.2.0"));
        assertTrue(CloudCatalog.compareVersions("1.2.0","1.2.1") < 0);
    }
    @Test public void updateTimestampMustBeIso8601() throws Exception {
        rejected(manifest().put("updatedAt","yesterday"));
        rejected(manifest().put("updatedAt","2026-02-30T00:00:00Z"));
        assertEquals(7,parse(manifest().put("updatedAt","2026-11-21T12:00:00+08:00"),0).revision);
    }
    @Test public void rollbackRejectedWhileEqualAndNewRevisionsAccepted() throws Exception {
        rejected(manifest().toString().getBytes(StandardCharsets.UTF_8),8);
        assertEquals(7,parse(manifest(),7).revision);
        assertEquals(8,parse(manifest().put("revision",8),7).revision);
    }
    @Test public void oneInvalidPresetRejectsAllRecommendations() throws Exception {
        rejected(manifest().put("presets",new JSONArray().put(preset()).put(preset().put("id","second").put("protocol","unknown"))));
    }
    @Test public void boundedReaderRejectsBeforeAcceptingAnOversizeBody() throws Exception {
        assertEquals(3,CloudCatalog.readBounded(new ByteArrayInputStream(new byte[]{1,2,3})).length);
        try { CloudCatalog.readBounded(new ByteArrayInputStream(new byte[256*1024+1])); fail("Oversize stream accepted"); }
        catch (IllegalArgumentException expected) { }
    }
    @Test public void foregroundSyncHasIndependentOneHourSuccessThrottle() {
        assertTrue(CloudCatalog.shouldRefresh(true,0,10000));
        assertFalse(CloudCatalog.shouldRefresh(false,0,10000));
        assertFalse(CloudCatalog.shouldRefresh(true,10000,10001));
        assertTrue(CloudCatalog.shouldRefresh(true,10000,3610000));
        assertTrue(CloudCatalog.shouldRefresh(true,10000,9000));
    }
    private static String repeat(char c,int count) { char[] data=new char[count]; Arrays.fill(data,c); return new String(data); }
}
