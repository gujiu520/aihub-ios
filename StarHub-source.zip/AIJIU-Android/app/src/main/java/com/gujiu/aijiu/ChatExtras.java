package com.gujiu.aijiu;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Private storage for explicitly selected chat files and reusable Markdown instructions. */
public final class ChatExtras {
    public static final int MAX_ATTACHMENTS = 3;
    public static final int MAX_ATTACHMENT_TOTAL = 4 * 1024 * 1024;
    private static final int MAX_BINARY = 3 * 1024 * 1024;
    private static final int MAX_TEXT = 128 * 1024;
    private static final int MAX_SKILL = 32 * 1024;
    private static final int MAX_SKILLS = 50;
    static final String JPEG = "image/jpeg", PNG = "image/png", PDF = "application/pdf";

    private final File root;
    private final ContentResolver resolver;

    public ChatExtras(Context context) {
        root = new File(context.getNoBackupFilesDir(), "chat-extras");
        resolver = context.getContentResolver();
    }

    ChatExtras(File root) {
        this.root = root;
        resolver = null;
    }

    public static final class Attachment {
        public final String id;
        public final String name;
        public final String mimeType;
        public final int size;

        private Attachment(String id, String name, String mimeType, int size) {
            this.id = id;
            this.name = name;
            this.mimeType = mimeType;
            this.size = size;
        }

        public JSONObject toJson() throws JSONException {
            return new JSONObject().put("id", id).put("name", name).put("mimeType", mimeType).put("size", size);
        }

        public static Attachment fromJson(JSONObject object) throws JSONException {
            String id = object.getString("id"), name = object.getString("name"), mime = object.getString("mimeType");
            int size = object.getInt("size");
            if (!validId(id) || !name.equals(cleanName(name)) || !mime.equals(mimeForName(name))
                    || size <= 0 || size > maxSize(mime)) {
                throw new JSONException("聊天附件记录无效。");
            }
            return new Attachment(id, name, mime, size);
        }
    }

    public static final class Skill {
        public final String id;
        public final String name;
        public final String instructions;

        private Skill(String id, String name, String instructions) {
            this.id = id;
            this.name = name;
            this.instructions = instructions;
        }
    }

    public Attachment importAttachment(Uri uri) throws IOException {
        String name = documentName(uri);
        try (InputStream input = resolver.openInputStream(uri)) {
            return importAttachment(name, resolver.getType(uri), input);
        } catch (SecurityException e) {
            throw new IOException("无法查看所选文件，请重新选择。", e);
        }
    }

    Attachment importAttachment(String displayName, String declaredMime, InputStream input) throws IOException {
        String name = cleanName(displayName);
        String mime = mimeForName(name);
        if (mime.isEmpty()) throw new IOException("请选择 JPEG、PNG、PDF、TXT、MD、CSV 或 JSON 文件。");
        if (!compatibleMime(mime, declaredMime)) throw new IOException("文件类型与扩展名不一致。");
        byte[] bytes = readLimited(input, maxSize(mime));
        validateContent(mime, bytes);
        String id = UUID.randomUUID().toString();
        store("attachments", id, bytes);
        return new Attachment(id, name, mime, bytes.length);
    }

    byte[] loadAttachment(Attachment attachment) throws IOException {
        File file = privateFile("attachments", attachment.id);
        if (!file.isFile() || file.length() != attachment.size) {
            throw new IOException("本地附件不可用，请重新选择 " + attachment.name + "。");
        }
        try (InputStream input = new FileInputStream(file)) {
            byte[] bytes = readLimited(input, maxSize(attachment.mimeType));
            if (bytes.length != attachment.size) throw new IOException("本地附件已更改，请重新选择。");
            validateContent(attachment.mimeType, bytes);
            return bytes;
        }
    }

    public void deleteAttachment(Attachment attachment) throws IOException {
        if (attachment != null) Files.deleteIfExists(privateFile("attachments", attachment.id).toPath());
    }

    public Skill importSkill(Uri uri) throws IOException {
        String name = documentName(uri);
        try (InputStream input = resolver.openInputStream(uri)) {
            return importSkill(name, input);
        } catch (SecurityException e) {
            throw new IOException("无法读取技能文件，请重新选择。", e);
        }
    }

    synchronized Skill importSkill(String displayName, InputStream input) throws IOException {
        String name = cleanName(displayName);
        if (!name.toLowerCase(Locale.ROOT).endsWith(".md")) {
            throw new IOException("请选择 Markdown 技能文件，例如 SKILL.md。");
        }
        if (loadSkills().size() >= MAX_SKILLS) throw new IOException("已保存 50 项技能，请删除不再使用的技能。");
        Skill skill = parseSkill(UUID.randomUUID().toString(), name, decodeText(readLimited(input, MAX_SKILL)));
        try {
            JSONObject data = new JSONObject().put("name", skill.name).put("instructions", skill.instructions);
            store("skills", skill.id, data.toString().getBytes(StandardCharsets.UTF_8));
        } catch (JSONException e) {
            throw new IOException("无法保存该技能。", e);
        }
        return skill;
    }

    public synchronized List<Skill> loadSkills() throws IOException {
        ArrayList<Skill> result = new ArrayList<>();
        File directory = new File(root, "skills");
        if (!directory.exists()) return result;
        File[] files = directory.listFiles(file -> file.isFile() && validId(file.getName()));
        if (files == null) throw new IOException("无法读取本机的技能。");
        for (File file : files) {
            try (InputStream input = new FileInputStream(file)) {
                JSONObject data = new JSONObject(decodeText(readLimited(input, MAX_SKILL * 6 + 1024)));
                String name = data.getString("name"), instructions = data.getString("instructions");
                if (!name.isEmpty() && !instructions.trim().isEmpty()
                        && instructions.getBytes(StandardCharsets.UTF_8).length <= MAX_SKILL) {
                    result.add(new Skill(file.getName(), name, instructions));
                }
            } catch (JSONException | IOException unusable) {
                // A damaged entry cannot prevent the remaining skills from opening.
            }
        }
        result.sort(Comparator.comparing(skill -> skill.name, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    static List<Skill> readBuiltInSkills(InputStream input) throws IOException {
        ArrayList<Skill> result = new ArrayList<>();
        HashSet<String> ids = new HashSet<>();
        try {
            JSONArray items = new JSONArray(decodeText(readLimited(input, 512 * 1024)));
            for (int i = 0; i < Math.min(items.length(), MAX_SKILLS); i++) {
                JSONObject row = items.optJSONObject(i);
                if (row == null) continue;
                String id = row.optString("id"), name = row.optString("name").trim(), prompt = row.optString("prompt").trim();
                if (validId(id) && !name.isEmpty() && name.length() <= 80 && !prompt.isEmpty()
                        && prompt.getBytes(StandardCharsets.UTF_8).length <= MAX_SKILL && ids.add(id)) {
                    result.add(new Skill(id, name, prompt));
                }
            }
        } catch (JSONException bad) { throw new IOException("无法读取内置技能。", bad); }
        return result;
    }

    public synchronized void deleteSkill(Skill skill) throws IOException {
        if (skill != null) Files.deleteIfExists(privateFile("skills", skill.id).toPath());
    }

    private static Skill parseSkill(String id, String fileName, String text) throws IOException {
        String[] lines = text.split("\\r?\\n", -1);
        String name = "";
        int bodyStart = 0;
        if (lines.length > 2 && "---".equals(lines[0].trim())) {
            for (int i = 1; i < lines.length; i++) {
                String line = lines[i];
                if ("---".equals(line.trim())) {
                    bodyStart = i + 1;
                    break;
                }
                if (line.startsWith("name:")) {
                    name = line.substring(5).trim();
                    if (name.length() > 1 && ((name.startsWith("\"") && name.endsWith("\""))
                            || (name.startsWith("'") && name.endsWith("'")))) {
                        name = name.substring(1, name.length() - 1);
                    }
                }
            }
            if (bodyStart == 0) throw new IOException("技能文件的元数据缺少结束线。");
        }
        StringBuilder body = new StringBuilder();
        for (int i = bodyStart; i < lines.length; i++) {
            if (name.isEmpty() && lines[i].startsWith("# ")) name = lines[i].substring(2).trim();
            if (i > bodyStart) body.append('\n');
            body.append(lines[i]);
        }
        String instructions = body.toString().trim();
        if (instructions.isEmpty()) throw new IOException("技能文件没有可供模型使用的说明。");
        name = cleanName(name.isEmpty() ? fileName.substring(0, fileName.length() - 3) : name);
        return new Skill(id, name.isEmpty() ? "未命名技能" : name, instructions);
    }

    private String documentName(Uri uri) throws IOException {
        if (uri == null || !ContentResolver.SCHEME_CONTENT.equals(uri.getScheme()) || uri.getAuthority() == null) {
            throw new IOException("请通过系统文件选择器选取文件。");
        }
        try (Cursor rows = resolver.query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (rows != null && rows.moveToFirst() && rows.getColumnCount() > 0) return rows.getString(0);
            throw new IOException("无法取得所选文件的名称。");
        } catch (RuntimeException e) {
            throw new IOException("无法查看所选文件，请重新选择。", e);
        }
    }

    private static String cleanName(String name) {
        if (name == null) return "";
        String safe = name.replaceAll("[\\p{Cc}\\p{Cf}/\\\\]", "_").trim();
        if (safe.length() <= 120) return safe;
        int dot = safe.lastIndexOf('.');
        String suffix = dot > 0 && safe.length() - dot <= 10 ? safe.substring(dot) : "";
        int end = 120 - suffix.length();
        if (Character.isHighSurrogate(safe.charAt(end - 1))) end--;
        return safe.substring(0, end) + suffix;
    }

    private static String mimeForName(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return JPEG;
        if (lower.endsWith(".png")) return PNG;
        if (lower.endsWith(".pdf")) return PDF;
        if (lower.endsWith(".txt")) return "text/plain";
        if (lower.endsWith(".md")) return "text/markdown";
        if (lower.endsWith(".csv")) return "text/csv";
        if (lower.endsWith(".json")) return "application/json";
        return "";
    }

    static boolean isText(String mime) {
        return mime.startsWith("text/") || mime.equals("application/json");
    }

    private static int maxSize(String mime) {
        return isText(mime) ? MAX_TEXT : MAX_BINARY;
    }

    private static boolean compatibleMime(String expected, String declared) {
        if (declared == null) return true;
        String mime = declared.split(";", 2)[0].trim().toLowerCase(Locale.ROOT);
        return mime.isEmpty() || mime.equals(expected) || mime.equals("application/octet-stream")
                || mime.equals("*/*") || mime.equals("application/x-unknown")
                || (expected.equals(JPEG) && mime.equals("image/jpg"))
                || (expected.equals(PDF) && mime.equals("application/x-pdf"))
                || (isText(expected) && (mime.startsWith("text/") || mime.equals("application/json")
                        || (expected.equals("text/csv") && mime.equals("application/vnd.ms-excel"))));
    }

    private static void validateContent(String mime, byte[] bytes) throws IOException {
        if (isText(mime)) {
            if (decodeText(bytes).trim().isEmpty()) throw new IOException("所选文本文件没有内容。");
            return;
        }
        boolean valid;
        switch (mime) {
            case PNG:
                valid = bytes.length >= 33 && begins(bytes, 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
                        0, 0, 0, 13, 'I', 'H', 'D', 'R');
                break;
            case JPEG:
                valid = bytes.length >= 12 && begins(bytes, 0xFF, 0xD8, 0xFF)
                        && (bytes[bytes.length - 2] & 255) == 0xFF && (bytes[bytes.length - 1] & 255) == 0xD9;
                break;
            case PDF:
                valid = bytes.length >= 14 && begins(bytes, '%', 'P', 'D', 'F', '-');
                break;
            default: valid = false;
        }
        if (!valid) throw new IOException("附件内容与所选文件类型不符。");
    }

    private static boolean begins(byte[] bytes, int... prefix) {
        if (bytes.length < prefix.length) return false;
        for (int i = 0; i < prefix.length; i++) if ((bytes[i] & 255) != prefix[i]) return false;
        return true;
    }

    static String decodeText(byte[] bytes) throws IOException {
        try {
            String value = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            if (value.startsWith("\uFEFF")) value = value.substring(1);
            for (int i = 0; i < value.length(); i++) {
                char code = value.charAt(i);
                if (Character.isISOControl(code) && code != '\r' && code != '\n' && code != '\t') {
                    throw new IOException("文本文件包含不可读取的数据。");
                }
            }
            return value;
        } catch (CharacterCodingException e) {
            throw new IOException("文本文件必须为 UTF-8 编码。", e);
        }
    }

    private static byte[] readLimited(InputStream input, int max) throws IOException {
        if (input == null) throw new IOException("无法打开所选文件。");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        for (int count; (count = input.read(buffer)) != -1;) {
            if (Thread.currentThread().isInterrupted()) throw new IOException("已取消读取文件。");
            if (count > max - bytes.size()) throw new IOException("文件过大，最大允许 " + (max / 1024) + " KB。");
            bytes.write(buffer, 0, count);
        }
        return bytes.toByteArray();
    }

    private static boolean validId(String value) {
        return value != null && value.matches("[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}");
    }

    private File privateFile(String folderName, String id) throws IOException {
        if (!validId(id)) throw new IOException("本机文件引用无效。");
        return new File(new File(root, folderName), id);
    }

    private void store(String folderName, String id, byte[] bytes) throws IOException {
        File file = privateFile(folderName, id);
        File directory = file.getParentFile();
        if (!directory.isDirectory() && !directory.mkdirs() && !directory.isDirectory()) {
            throw new IOException("无法打开 App 的私有存储。");
        }
        File temp = File.createTempFile("import-", ".tmp", directory);
        try {
            Files.write(temp.toPath(), bytes);
            Files.move(temp.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE);
        } finally {
            Files.deleteIfExists(temp.toPath());
        }
    }
}
