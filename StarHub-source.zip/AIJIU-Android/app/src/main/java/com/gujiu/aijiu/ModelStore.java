package com.gujiu.aijiu;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Local model metadata and device-bound encrypted credentials. No shared API key is bundled. */
public final class ModelStore {
    public static final long DAY = 24L * 60L * 60L * 1000L;
    private static final String KEY_ALIAS = "com.gujiu.aijiu.credentials.v1";
    private static volatile ModelStore instance;

    public static ModelStore get(Context context) {
        if (instance == null) synchronized (ModelStore.class) {
            if (instance == null) instance = new ModelStore(context.getApplicationContext());
        }
        return instance;
    }

    public static final class Model {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public String modelID = "";
        public String baseURL = "";
        public String protocol = "openAI";
        public String logo = "automatic";
        public String provider = "自定义";
        public String note = "";
        public String category = "custom";
        public boolean requiresKey = false;
        public boolean freeCatalog = false;

        public Model() { }
        public Model(Model other) {
            id = other.id; name = other.name; modelID = other.modelID; baseURL = other.baseURL;
            protocol = other.protocol; logo = other.logo; provider = other.provider;
            note = other.note; category = other.category; requiresKey = other.requiresKey;
            freeCatalog = other.freeCatalog;
        }

        public String resolvedLogo() {
            if (logo != null && !logo.isEmpty() && !"automatic".equals(logo)) return logo;
            String text = (modelID + " " + name + " " + provider).toLowerCase(Locale.ROOT);
            if (text.contains("deepseek")) return "deepseek";
            if (text.contains("claude") || text.contains("anthropic")) return "anthropic";
            if (text.contains("gemini")) return "google";
            if (text.contains("qwen") || text.contains("通义")) return "qwen";
            if (text.contains("glm") || text.contains("智谱")) return "glm";
            if (text.contains("kimi") || text.contains("moonshot")) return "kimi";
            if (text.contains("ernie") || text.contains("文心") || text.contains("baidu")) return "baidu";
            if (text.contains("gpt") || text.contains("openai/") || text.startsWith("o1") || text.startsWith("o3") || text.startsWith("o4")) return "openai";
            return "custom";
        }

        JSONObject json() throws Exception {
            return new JSONObject().put("id", id).put("name", name).put("modelID", modelID)
                    .put("baseURL", baseURL).put("protocol", protocol).put("logo", logo)
                    .put("provider", provider).put("note", note).put("category", category)
                    .put("requiresKey", requiresKey).put("freeCatalog", freeCatalog);
        }

        static Model from(JSONObject value) {
            Model model = new Model();
            model.id = value.optString("id", model.id);
            model.name = value.optString("name", "");
            model.modelID = value.optString("modelID", "");
            model.baseURL = value.optString("baseURL", "");
            model.protocol = value.optString("protocol", "openAI");
            model.logo = value.optString("logo", "automatic");
            model.provider = value.optString("provider", "自定义");
            model.note = value.optString("note", "");
            model.category = value.optString("category", "custom");
            model.requiresKey = value.optBoolean("requiresKey", false);
            model.freeCatalog = value.optBoolean("freeCatalog", false);
            return model;
        }
    }

    private final Context context;
    private final SharedPreferences preferences;
    private final SharedPreferences encrypted;
    private final List<Model> custom = new ArrayList<>();
    private final List<Model> free = new ArrayList<>();
    private final AtomicFile cloudCache;
    private CloudCatalog.Manifest cloudCatalog;
    private long cloudLastSuccess;
    private String cloudError;
    private boolean cloudRefreshing;
    private String discoveryError;
    private boolean refreshing;

    private ModelStore(Context context) {
        this.context = context;
        preferences = context.getSharedPreferences("AIJIU.settings", Context.MODE_PRIVATE);
        encrypted = context.getSharedPreferences("AIJIU.encrypted-credentials", Context.MODE_PRIVATE);
        cloudCache = new AtomicFile(new File(context.getFilesDir(), "cloud-catalog-v1.cache"));
        loadArray(preferences.getString("models", "[]"), custom, false);
        loadArray(preferences.getString("freeModels", "[]"), free, true);
        loadCloudCache();
    }

    private void loadArray(String encoded, List<Model> target, boolean catalogOnly) {
        try {
            JSONArray array = new JSONArray(encoded);
            for (int i = 0; i < array.length(); i++) {
                JSONObject row = array.optJSONObject(i);
                if (row == null) continue;
                Model model = Model.from(row);
                if (model.name.isEmpty() || model.modelID.isEmpty()) continue;
                if (catalogOnly && (!model.freeCatalog || !ChatService.FREE_BASE.equals(model.baseURL))) continue;
                if (!catalogOnly && model.freeCatalog) continue;
                target.add(model);
            }
        } catch (Exception ignored) { /* A corrupt cache never prevents the app opening. */ }
    }

    private static List<Model> snapshot(List<Model> values) {
        ArrayList<Model> result = new ArrayList<>();
        for (Model model : values) result.add(new Model(model));
        return result;
    }

    public synchronized List<Model> getAllModels() {
        List<Model> result = snapshot(custom);
        result.addAll(snapshot(free));
        return result;
    }
    public synchronized List<Model> getCustomModels() { return snapshot(custom); }
    public synchronized List<Model> getFreeModels() { return snapshot(free); }

    public synchronized List<Model> getPresets() {
        ArrayList<Model> result = new ArrayList<>();
        if (cloudCatalog != null && cloudCatalog.revision >= 2) {
            for (CloudCatalog.Preset preset : cloudCatalog.presets) {
                Model model = new Model();
                model.id=preset.id; model.name=preset.name; model.modelID=preset.modelID;
                model.baseURL=preset.baseURL; model.protocol=preset.protocol; model.logo=preset.logo;
                model.provider=preset.provider; model.note=preset.note; model.category=preset.category;
                model.requiresKey=true; model.freeCatalog=false; result.add(model);
            }
            return result;
        }
        try (InputStream input = context.getAssets().open("model-presets.json")) {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] block = new byte[4096];
            for (int read; (read = input.read(block)) != -1;) {
                if (output.size() + read > 1024 * 1024) throw new IllegalArgumentException("预设目录过大。");
                output.write(block, 0, read);
            }
            loadArray(new String(output.toByteArray(), StandardCharsets.UTF_8), result, false);
        } catch (Exception ignored) { }
        return result;
    }

    private void loadCloudCache() {
        try (InputStream input = cloudCache.openRead()) {
            ByteArrayOutputStream output = new ByteArrayOutputStream(); byte[] block=new byte[4096];
            for(int count;(count=input.read(block))!=-1;) {
                if(output.size()+count>CloudCatalog.MAX_BYTES+64) throw new IllegalArgumentException("目录缓存过大。");
                output.write(block,0,count);
            }
            byte[] bytes=output.toByteArray(); int split=-1;
            for(int i=0;i<Math.min(bytes.length,32);i++) if(bytes[i]=='\n') { split=i; break; }
            if(split<1) throw new IllegalArgumentException("目录缓存格式无效。");
            long checkedAt=Long.parseLong(new String(bytes,0,split,StandardCharsets.US_ASCII));
            if(checkedAt<=0) throw new IllegalArgumentException("目录缓存时间无效。");
            byte[] manifest=java.util.Arrays.copyOfRange(bytes,split+1,bytes.length);
            CloudCatalog.Manifest validated=CloudCatalog.parse(manifest,0);
            cloudCatalog=validated; cloudLastSuccess=checkedAt;
        } catch (java.io.FileNotFoundException ignored) { /* Bundled recommendations work on first launch. */ }
        catch (Exception ignored) { cloudError="本地云端目录缓存无效，已使用内置推荐。"; }
    }

    public synchronized boolean isCloudAutoSync() { return preferences.getBoolean("cloudAutoSync",true); }
    public synchronized void setCloudAutoSync(boolean enabled) { preferences.edit().putBoolean("cloudAutoSync",enabled).apply(); }
    public synchronized long getCloudLastSuccess() { return cloudLastSuccess; }
    public synchronized long getCloudRevision() { return cloudCatalog==null ? 0 : cloudCatalog.revision; }
    public synchronized String getCloudAnnouncement() { return cloudCatalog==null ? "" : cloudCatalog.announcement; }
    public synchronized String getCloudLatestVersion() { return cloudCatalog==null ? "" : cloudCatalog.latestVersion; }
    public synchronized String getCloudError() { return cloudError; }
    public synchronized boolean isCloudRefreshing() { return cloudRefreshing; }

    /** Worker-only, whole-document validation then AtomicFile replacement. Never touches saved models or keys. */
    public boolean refreshCloudCatalog(boolean force) throws Exception {
        long minimumRevision;
        synchronized(this) {
            if(cloudRefreshing || !force && !CloudCatalog.shouldRefresh(isCloudAutoSync(),cloudLastSuccess,System.currentTimeMillis())) return false;
            cloudRefreshing=true; cloudError=null; minimumRevision=getCloudRevision();
        }
        try {
            CloudCatalog.Manifest validated=CloudCatalog.parse(CloudCatalog.fetch(),minimumRevision);
            long checkedAt=System.currentTimeMillis();
            byte[] cached=(Long.toString(checkedAt)+"\n"+validated.encoded).getBytes(StandardCharsets.UTF_8);
            synchronized(this) {
                FileOutputStream output=null;
                try {
                    output=cloudCache.startWrite(); output.write(cached); output.flush();
                    cloudCache.finishWrite(output); output=null;
                } catch(Exception failure) { if(output!=null) cloudCache.failWrite(output); throw failure; }
                cloudCatalog=validated; cloudLastSuccess=checkedAt;
            }
            return true;
        } catch(Exception failure) {
            synchronized(this) { cloudError="云端同步失败，已保留上次有效目录或内置推荐。"; }
            throw failure;
        } finally { synchronized(this) { cloudRefreshing=false; } }
    }

    public synchronized Model getSelected() {
        String selected = preferences.getString("selected", "");
        if (!selected.isEmpty()) return findModel(selected);
        List<Model> values = getAllModels();
        return values.isEmpty() ? null : values.get(0);
    }

    public synchronized String getSelectedId() {
        String selected = preferences.getString("selected", "");
        if (!selected.isEmpty()) return selected;
        Model fallback = getSelected();
        return fallback == null ? "" : fallback.id;
    }

    public synchronized Model findModel(String id) {
        for (Model model : custom) if (model.id.equals(id)) return new Model(model);
        for (Model model : free) if (model.id.equals(id)) return new Model(model);
        return null;
    }

    public synchronized void select(String id) {
        if (findModel(id) != null) {
            preferences.edit().putString("selected", id).apply();
            return;
        }
    }

    private static JSONArray encode(List<Model> models) throws Exception {
        JSONArray result = new JSONArray();
        for (Model model : models) result.put(model.json());
        return result;
    }

    public synchronized void save(Model model, String key) throws Exception {
        if (model.freeCatalog) throw new IllegalArgumentException("免费目录模型请使用 OpenRouter Key 设置。");
        Model cleaned = new Model(model);
        cleaned.name = cleaned.name.trim(); cleaned.modelID = cleaned.modelID.trim(); cleaned.baseURL = cleaned.baseURL.trim();
        if (cleaned.id == null || cleaned.id.trim().isEmpty()) cleaned.id = UUID.randomUUID().toString();
        if (cleaned.name.isEmpty() || cleaned.modelID.isEmpty()) throw new IllegalArgumentException("请填写名称与模型 ID。");
        ChatService.Endpoints.validate(cleaned.baseURL);
        if (!"openAI".equals(cleaned.protocol) && !"anthropic".equals(cleaned.protocol) && !"gemini".equals(cleaned.protocol)) throw new IllegalArgumentException("请选择支持的接口协议。");
        String secret = key == null ? "" : key.trim();
        if (cleaned.requiresKey && secret.isEmpty()) throw new IllegalArgumentException("此服务需要你自己的 API Key，预设不包含共享密钥。");
        String old = readSecret(cleaned.id);
        List<Model> updated = snapshot(custom);
        updated.removeIf(value -> value.id.equals(cleaned.id));
        updated.add(cleaned);
        writeSecret(cleaned.id, secret);
        if (!preferences.edit().putString("models", encode(updated).toString()).putString("selected", cleaned.id).commit()) {
            writeSecret(cleaned.id, old);
            throw new IllegalStateException("模型配置未能写入设备。");
        }
        custom.clear(); custom.addAll(updated);
    }

    public synchronized void delete(Model model) throws Exception {
        if (model.freeCatalog) throw new IllegalArgumentException("免费目录模型由同步维护。");
        List<Model> updated = snapshot(custom);
        updated.removeIf(value -> value.id.equals(model.id));
        String old = readSecret(model.id);
        writeSecret(model.id, "");
        if (!preferences.edit().putString("models", encode(updated).toString()).commit()) {
            writeSecret(model.id, old);
            throw new IllegalStateException("模型配置未能删除。");
        }
        custom.clear(); custom.addAll(updated);
        if (model.id.equals(preferences.getString("selected", ""))) {
            List<Model> available = getAllModels();
            preferences.edit().putString("selected", available.isEmpty() ? "" : available.get(0).id).apply();
        }
    }

    public synchronized String getKey(Model model) {
        try { return readSecret(model.freeCatalog ? "openrouter-shared" : model.id); }
        catch (Exception failure) { return ""; }
    }
    public synchronized String getOpenRouterKey() {
        try { return readSecret("openrouter-shared"); }
        catch (Exception failure) { return ""; }
    }
    public synchronized void setOpenRouterKey(String key) throws Exception { writeSecret("openrouter-shared", key == null ? "" : key.trim()); }
    public synchronized String getTheme() { return preferences.getString("theme", "system"); }
    public synchronized void setTheme(String value) { preferences.edit().putString("theme", "dark".equals(value) || "light".equals(value) ? value : "system").apply(); }
    public synchronized boolean isAutoRefresh() { return preferences.getBoolean("autoRefresh", true); }
    public synchronized void setAutoRefresh(boolean value) {
        preferences.edit().putBoolean("autoRefresh", value).apply();
        if (value) RefreshJobService.schedule(context); else RefreshJobService.cancel(context);
    }
    public synchronized long getLastRefresh() { return preferences.getLong("lastRefresh", 0); }
    public synchronized String getDiscoveryError() { return discoveryError; }

    /** Blocking network call. UI and JobService must invoke this on their worker executor. */
    public void refreshFreeModels(boolean force) throws Exception {
        synchronized (this) {
            if (refreshing) return;
            if (!force && (!isAutoRefresh() || (getLastRefresh() > 0 && System.currentTimeMillis() - getLastRefresh() < DAY))) return;
            refreshing = true; discoveryError = null;
        }
        try {
            List<Model> values = ChatService.fetchFreeModels();
            long now = System.currentTimeMillis();
            synchronized (this) {
                if (!preferences.edit().putString("freeModels", encode(values).toString()).putLong("lastRefresh", now).commit()) throw new IllegalStateException("无法保存免费目录缓存。");
                free.clear(); free.addAll(values);
            }
        } catch (Exception failure) {
            synchronized (this) { discoveryError = "无法更新免费目录，已保留上次缓存。\n" + safeMessage(failure); }
            throw failure;
        } finally { synchronized (this) { refreshing = false; } }
    }

    private static String safeMessage(Exception error) {
        String value = error.getMessage();
        return value == null || value.isEmpty() ? "请稍后重试。" : value;
    }

    private SecretKey encryptionKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(KEY_ALIAS)) {
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true).build());
            generator.generateKey();
        }
        return ((KeyStore.SecretKeyEntry) store.getEntry(KEY_ALIAS, null)).getSecretKey();
    }

    private String readSecret(String account) throws Exception {
        String value = encrypted.getString(account, "");
        if (value.isEmpty()) return "";
        String[] parts = value.split(":", 3);
        if (parts.length != 3 || !"v1".equals(parts[0])) throw new IllegalStateException("本地密钥格式无效，请重新填写。");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, encryptionKey(), new GCMParameterSpec(128, Base64.decode(parts[1], Base64.NO_WRAP)));
        cipher.updateAAD(account.getBytes(StandardCharsets.UTF_8));
        return new String(cipher.doFinal(Base64.decode(parts[2], Base64.NO_WRAP)), StandardCharsets.UTF_8);
    }

    private void writeSecret(String account, String secret) throws Exception {
        if (secret.isEmpty()) {
            if (!encrypted.edit().remove(account).commit()) throw new IllegalStateException("无法删除本地密钥。");
            return;
        }
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, encryptionKey());
        cipher.updateAAD(account.getBytes(StandardCharsets.UTF_8));
        String value = "v1:" + Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(cipher.doFinal(secret.getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP);
        if (!encrypted.edit().putString(account, value).commit()) throw new IllegalStateException("无法加密保存本地密钥。");
    }
}
