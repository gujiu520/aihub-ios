package com.gujiu.aijiu;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Best-effort daily directory refresh; Android decides the exact execution time. */
public final class RefreshJobService extends JobService {
    private static final int JOB_ID = 0x41494A;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Future<?> running;
    private volatile long generation;

    public static void schedule(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null) return;
        if (!ModelStore.get(context).isAutoRefresh()) { scheduler.cancel(JOB_ID); return; }
        JobInfo existing = scheduler.getPendingJob(JOB_ID);
        if (existing != null) return;
        JobInfo request = new JobInfo.Builder(JOB_ID, new ComponentName(context, RefreshJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(ModelStore.DAY, 2L * 60L * 60L * 1000L)
                .setPersisted(true).build();
        scheduler.schedule(request);
    }

    public static void cancel(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler != null) scheduler.cancel(JOB_ID);
    }

    @Override public boolean onStartJob(JobParameters parameters) {
        ModelStore store = ModelStore.get(this);
        if (!store.isAutoRefresh()) return false;
        final long current = ++generation;
        running = executor.submit(() -> {
            boolean retry = false;
            try { store.refreshFreeModels(false); }
            catch (Exception failure) { retry = !Thread.currentThread().isInterrupted(); }
            final boolean reschedule = retry;
            main.post(() -> { if (generation == current) jobFinished(parameters, reschedule); });
        });
        return true;
    }

    @Override public boolean onStopJob(JobParameters parameters) {
        generation++;
        if (running != null) running.cancel(true);
        return ModelStore.get(this).isAutoRefresh();
    }

    @Override public void onDestroy() {
        generation++;
        if (running != null) running.cancel(true);
        executor.shutdownNow();
        super.onDestroy();
    }
}
