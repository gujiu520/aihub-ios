package com.gujiu.aijiu;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Bundled directory URLs are for browser visits; only explicit model presets populate API settings. */
final class SupplierDirectory {
    static final String ASSET = "supplier-directory.json";
    private static final int MAX_BYTES = 512 * 1024;

    static final class Entry {
        final String name, website, category;
        final List<String> aliases;
        final List<ModelStore.Model> models;

        Entry(String name, String website, String category, List<String> aliases, List<ModelStore.Model> models) {
            this.name = name; this.website = website; this.category = category;
            this.aliases = Collections.unmodifiableList(new ArrayList<>(aliases));
            this.models = Collections.unmodifiableList(new ArrayList<>(models));
        }

        boolean matches(String query) {
            String compact = key(query);
            if (compact.isEmpty()) return true;
            if (key(name).contains(compact) || key(website).contains(compact)) return true;
            for (String alias : aliases) if (key(alias).contains(compact)) return true;
            for (ModelStore.Model model : models) {
                if (key(model.name).contains(compact) || key(model.modelID).contains(compact)
                        || key(model.provider).contains(compact) || key(model.baseURL).contains(compact)) return true;
            }
            return false;
        }
    }

    private SupplierDirectory() {}

    static List<Entry> read(InputStream input) throws IOException, JSONException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] block = new byte[8192];
        for (int read; (read = input.read(block)) != -1;) {
            if (output.size() + read > MAX_BYTES) throw new IOException("供应商目录过大。");
            output.write(block, 0, read);
        }
        return read(new String(output.toByteArray(), StandardCharsets.UTF_8));
    }

    static List<Entry> read(String raw) throws JSONException {
        JSONArray rows = new JSONArray(raw);
        ArrayList<Entry> entries = new ArrayList<>();
        Set<String> names = new HashSet<>();
        for (int index = 0; index < rows.length(); index++) {
            JSONObject row = rows.optJSONObject(index);
            if (row == null) continue;
            String name = row.optString("name").trim();
            if (name.length() > 120 || key(name).isEmpty() || !names.add(key(name))) continue;
            ArrayList<String> aliases = new ArrayList<>();
            JSONArray alternatives = row.optJSONArray("aliases");
            if (alternatives != null) {
                for (int i = 0; i < alternatives.length(); i++) {
                    String value = alternatives.optString(i).trim();
                    if (!key(value).isEmpty() && value.length() <= 120) aliases.add(value);
                }
            }
            ArrayList<ModelStore.Model> models = new ArrayList<>();
            JSONArray presets = row.optJSONArray("models");
            if (presets != null) for (int i = 0; i < presets.length(); i++) {
                JSONObject rawModel = presets.optJSONObject(i);
                if (rawModel == null || rawModel.optString("id").isEmpty()
                        || !Boolean.TRUE.equals(rawModel.opt("requiresKey"))
                        || !Boolean.FALSE.equals(rawModel.opt("freeCatalog"))) continue;
                ModelStore.Model model = ModelStore.Model.from(rawModel);
                if (validModel(model)) upsert(models, model);
            }
            entries.add(new Entry(name, safePublicLink(row.optString("website")), row.optString("category"), aliases, models));
        }
        return entries;
    }

    static List<Entry> grouped(List<Entry> bundled, List<ModelStore.Model> live) {
        ArrayList<Entry> entries = new ArrayList<>(bundled);
        LinkedHashMap<String, Integer> index = new LinkedHashMap<>();
        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            index.putIfAbsent(key(entry.name), i);
            for (String alias : entry.aliases) index.putIfAbsent(key(alias), i);
        }
        ArrayList<ArrayList<ModelStore.Model>> modelGroups = new ArrayList<>();
        for (Entry entry : entries) modelGroups.add(new ArrayList<>(entry.models));
        for (ModelStore.Model model : live) {
            String provider = key(model.provider);
            if (provider.isEmpty() || !validModel(model)) continue;
            Integer i = index.get(provider);
            if (i == null) {
                i = entries.size();
                index.put(provider, i);
                entries.add(new Entry(model.provider, "", "official", Collections.emptyList(), Collections.emptyList()));
                modelGroups.add(new ArrayList<>());
            }
            upsert(modelGroups.get(i), model);
        }
        ArrayList<Entry> result = new ArrayList<>(entries.size());
        for (int i = 0; i < entries.size(); i++) {
            Entry entry = entries.get(i);
            result.add(new Entry(entry.name, entry.website, entry.category, entry.aliases, modelGroups.get(i)));
        }
        return result;
    }

    private static void upsert(List<ModelStore.Model> models, ModelStore.Model value) {
        for (int i = 0; i < models.size(); i++) {
            ModelStore.Model model = models.get(i);
            if (model.id.equals(value.id)) { models.set(i, value); return; }
        }
        for (ModelStore.Model model : models) {
            if (model.modelID.equals(value.modelID) && model.baseURL.equals(value.baseURL)
                    && model.protocol.equals(value.protocol)) return;
        }
        models.add(value);
    }

    private static boolean validModel(ModelStore.Model model) {
        return model.requiresKey && !model.freeCatalog && !model.name.trim().isEmpty()
                && !model.modelID.trim().isEmpty() && !safePublicLink(model.baseURL).isEmpty()
                && ("openAI".equals(model.protocol) || "gemini".equals(model.protocol) || "anthropic".equals(model.protocol));
    }

    static String safePublicLink(String value) {
        if (value == null || value.isEmpty() || value.length() > 2048 || !value.equals(value.trim())) return "";
        try {
            URI url = new URI(value);
            String host = url.getHost();
            if (!"https".equals(url.getScheme()) || host == null || url.getRawUserInfo() != null
                    || url.getRawQuery() != null || url.getRawFragment() != null
                    || (url.getPort() != -1 && url.getPort() != 443)) return "";
            host = host.toLowerCase(Locale.ROOT);
            if (!host.contains(".") || host.endsWith(".") || host.endsWith(".local") || host.endsWith(".localhost")
                    || host.matches("[0-9.]+")) return "";
            return value;
        } catch (Exception invalid) { return ""; }
    }

    private static String key(String value) {
        String source = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFKD).toLowerCase(Locale.ROOT);
        StringBuilder result = new StringBuilder(source.length());
        for (int i = 0; i < source.length();) {
            int codePoint = source.codePointAt(i);
            if (Character.isLetterOrDigit(codePoint)) result.appendCodePoint(codePoint);
            i += Character.charCount(codePoint);
        }
        return result.toString();
    }
}
