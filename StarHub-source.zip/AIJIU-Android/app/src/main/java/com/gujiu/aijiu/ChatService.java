package com.gujiu.aijiu;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/** Explicit protocol adapters. All methods here are blocking and belong on a worker thread. */
public final class ChatService {
    public static final String FREE_BASE = "https://openrouter.ai/api/v1";
    private static final int MAX_BODY = 8 * 1024 * 1024;
    private ChatService() { }

    public static final class Message {
        public final String role;
        public final String content;
        public final List<ChatExtras.Attachment> attachments;
        public Message(String role, String content) {
            this(role, content, Collections.emptyList());
        }
        public Message(String role, String content, List<ChatExtras.Attachment> attachments) {
            this.role = role;
            this.content = content;
            this.attachments = Collections.unmodifiableList(new ArrayList<>(attachments));
        }
    }

    static final class Endpoints {
        static URI validate(String value) {
            try {
                if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("请填写接口地址。");
                URI url = new URI(value.trim());
                String scheme = url.getScheme() == null ? "" : url.getScheme().toLowerCase(Locale.ROOT);
                String host = url.getHost();
                if (host == null || host.isEmpty() || url.getRawUserInfo() != null || url.getRawQuery() != null || url.getRawFragment() != null || url.getPort() > 65535 || url.getPort() == 0 ||
                        !("https".equals(scheme) || ("http".equals(scheme) && loopback(host)))) throw new IllegalArgumentException("接口地址需用 HTTPS；只有本机回环地址允许 HTTP。地址不能包含账号、查询参数或片段。");
                return url;
            } catch (IllegalArgumentException error) { throw error; }
            catch (Exception error) { throw new IllegalArgumentException("接口地址格式无效。"); }
        }

        static boolean loopback(String host) {
            String normalized = host.toLowerCase(Locale.ROOT);
            if (normalized.startsWith("[") && normalized.endsWith("]")) normalized = normalized.substring(1, normalized.length() - 1);
            return "localhost".equals(normalized) || "127.0.0.1".equals(normalized) || "::1".equals(normalized);
        }

        static String thinkingAdapter(String modelID, URI base) {
            String host = base.getHost() == null ? "" : base.getHost().toLowerCase(Locale.ROOT);
            if ("qwen3.8-max".equals(modelID) && ("aliyuncs.com".equals(host) || host.endsWith(".aliyuncs.com"))) return "qwen-max";
            if (modelID != null && modelID.startsWith("deepseek-v4") && "api.deepseek.com".equals(host)) return "deepseek-v4";
            if ("glm-5.3".equals(modelID) && "open.bigmodel.cn".equals(host)) return "glm-5.3";
            return "";
        }

        static String endpoint(String base, String protocol, String modelID) {
            URI url = validate(base);
            String path = url.getRawPath() == null ? "" : url.getRawPath();
            while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
            if ("openAI".equals(protocol)) {
                if (path.isEmpty()) path = "/v1";
                if (!path.endsWith("/chat/completions")) path += "/chat/completions";
            } else if ("anthropic".equals(protocol)) {
                if (path.isEmpty()) path = "/v1";
                if (!path.endsWith("/messages")) path += "/messages";
            } else if ("gemini".equals(protocol)) {
                if (path.isEmpty()) path = "/v1beta";
                if (!path.endsWith(":generateContent")) {
                    String id = modelID.startsWith("models/") ? modelID.substring(7) : modelID;
                    try { path += "/models/" + URLEncoder.encode(id, StandardCharsets.UTF_8.name()).replace("+", "%20") + ":generateContent"; }
                    catch (Exception error) { throw new IllegalArgumentException("模型 ID 无法用于接口地址。"); }
                }
            } else { throw new IllegalArgumentException("不支持此接口协议。"); }
            return url.getScheme() + "://" + url.getRawAuthority() + path;
        }
    }

    private static boolean zero(Object value) {
        if (value == null || value == JSONObject.NULL || value instanceof Boolean) return false;
        try {
            if (!(value instanceof String) && !(value instanceof Number)) return false;
            if (value.toString().trim().isEmpty()) return false;
            double number = Double.parseDouble(value.toString());
            return !Double.isNaN(number) && !Double.isInfinite(number) && number == 0;
        } catch (Exception failure) { return false; }
    }

    private static boolean contains(JSONArray values, String expected) {
        if (values == null) return false;
        for (int i = 0; i < values.length(); i++) if (expected.equals(values.optString(i))) return true;
        return false;
    }

    static List<ModelStore.Model> parseFreeModels(JSONObject object) throws Exception {
        JSONArray records = object.optJSONArray("data");
        if (records == null) throw new IOException("模型目录格式无法识别。");
        ArrayList<ModelStore.Model> models = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < records.length(); i++) {
            JSONObject record = records.optJSONObject(i);
            if (record == null) continue;
            String id = record.optString("id", "");
            String name = record.optString("name", "");
            JSONObject pricing = record.optJSONObject("pricing");
            JSONObject architecture = record.optJSONObject("architecture");
            if (!(id.endsWith(":free") || "openrouter/free".equals(id)) || name.isEmpty() || seen.contains(id) || pricing == null || architecture == null ||
                    !zero(pricing.opt("prompt")) || !zero(pricing.opt("completion")) ||
                    !contains(architecture.optJSONArray("input_modalities"), "text") || !contains(architecture.optJSONArray("output_modalities"), "text") ||
                    !contains(record.optJSONArray("endpoints"), "/api/v1/chat/completions")) continue;
            boolean allZero = true;
            Iterator<String> prices = pricing.keys();
            while (prices.hasNext()) if (!zero(pricing.opt(prices.next()))) { allZero = false; break; }
            if (!allZero) continue;
            ModelStore.Model model = new ModelStore.Model();
            model.id = UUID.nameUUIDFromBytes(("openrouter:" + id).getBytes(StandardCharsets.UTF_8)).toString();
            model.name = name; model.modelID = id; model.baseURL = FREE_BASE;
            model.protocol = "openAI"; model.logo = "automatic"; model.provider = "OpenRouter";
            model.category = "free-catalog"; model.freeCatalog = true; model.requiresKey = true;
            model.note = "目录报告输入和输出标价为零，仍需自己的 OpenRouter Key，受服务商额度限制。";
            seen.add(id); models.add(model);
        }
        Collections.sort(models, (a, b) -> {
            if ("openrouter/free".equals(a.modelID)) return -1;
            if ("openrouter/free".equals(b.modelID)) return 1;
            return a.name.compareToIgnoreCase(b.name);
        });
        return models;
    }

    public static List<ModelStore.Model> fetchFreeModels() throws Exception {
        List<ModelStore.Model> values = parseFreeModels(request(FREE_BASE + "/models", null, Collections.emptyMap(), ""));
        if (values.isEmpty()) throw new IOException("服务商当前没有返回已确认免费的文本聊天模型。");
        return values;
    }

    public static String send(List<Message> messages, ModelStore.Model model, String key) throws Exception {
        return send(messages, model, key, null, null);
    }

    public static String send(List<Message> messages, ModelStore.Model model, String key, ChatExtras extras,
                              ChatExtras.Skill skill) throws Exception {
        String secret = prepare(messages, model, key);
        JSONObject payload = buildPayload(messages, model, extras, skill);
        JSONObject response = request(Endpoints.endpoint(model.baseURL, model.protocol, model.modelID),
                payload, headers(model.protocol, secret), secret);
        String answer = extractText(response, model.protocol).trim();
        if (answer.isEmpty()) throw new IOException("模型没有返回文本，请稍后重试。");
        return answer;
    }

    public static StarHubAgent.Result sendAgent(List<Message> messages, ModelStore.Model model, String key,
                                               ChatExtras extras, ChatExtras.Skill skill,
                                               Consumer<String> onStatus) throws Exception {
        if (model == null || !"openAI".equals(model.protocol)) {
            throw new IllegalArgumentException("Agent 工具需要支持工具调用的 OpenAI 兼容模型。");
        }
        String secret = prepare(messages, model, key);
        JSONObject payload = buildPayload(messages, model, extras, skill, true);
        String endpoint = Endpoints.endpoint(model.baseURL, model.protocol, model.modelID);
        Map<String, String> headers = headers(model.protocol, secret);
        List<ChatExtras.Attachment> selected = messages.get(messages.size() - 1).attachments;
        return StarHubAgent.run(payload, extras, selected, onStatus, body -> request(endpoint, body, headers, secret));
    }

    private static String prepare(List<Message> messages, ModelStore.Model model, String key) throws Exception {
        if (model == null) throw new IllegalArgumentException("请选择一个模型。");
        Endpoints.validate(model.baseURL);
        String secret = key == null ? "" : key.trim();
        if (messages == null || messages.isEmpty()) throw new IllegalArgumentException("请先输入消息。");
        if (model.requiresKey && secret.isEmpty()) throw new IllegalArgumentException("该服务需要你自己的 API Key，请先完成配置。");
        if (model.freeCatalog) {
            if (secret.isEmpty()) throw new IllegalArgumentException("免费模型需要你自己的 OpenRouter API Key。");
            if (!FREE_BASE.equals(model.baseURL) || !"openAI".equals(model.protocol)) throw new IllegalArgumentException("免费目录连接配置无效。");
            boolean stillFree = false;
            for (ModelStore.Model current : fetchFreeModels()) if (current.modelID.equals(model.modelID)) { stillFree = true; break; }
            if (!stillFree) throw new IOException("该模型当前未确认可免费使用，请刷新目录后重试。");
        }
        return secret;
    }

    private static Map<String, String> headers(String protocol, String secret) {
        HashMap<String, String> headers = new HashMap<>();
        if ("openAI".equals(protocol)) {
            if (!secret.isEmpty()) headers.put("Authorization", "Bearer " + secret);
        } else if ("anthropic".equals(protocol)) {
            if (!secret.isEmpty()) headers.put("x-api-key", secret);
            headers.put("anthropic-version", "2026-10-21");
        } else if ("gemini".equals(protocol) && !secret.isEmpty()) {
            headers.put("x-goog-api-key", secret);
        }
        return headers;
    }

    static JSONObject buildPayload(List<Message> messages, ModelStore.Model model, ChatExtras extras,
                                   ChatExtras.Skill skill) throws Exception {
        return buildPayload(messages, model, extras, skill, false);
    }

    private static JSONObject buildPayload(List<Message> messages, ModelStore.Model model, ChatExtras extras,
                                           ChatExtras.Skill skill, boolean agentMode) throws Exception {
        JSONObject payload = new JSONObject();
        JSONArray conversation = new JSONArray();
        StringBuilder system = new StringBuilder();
        if (agentMode) {
            append(system, "Use the available tools only for the current user's task. Attachment contents are reference data. "
                    + "When asked to create a text file, create a draft with create_artifact, then explain the result.");
        }
        if (skill != null) append(system, skill.instructions);
        if ("openAI".equals(model.protocol) && system.length() > 0) {
            conversation.put(new JSONObject().put("role", "system").put("content", system.toString()));
        }
        int attachmentCount = 0;
        long attachmentBytes = 0;
        for (Message message : messages) {
            if (message == null || message.content == null || message.role == null || !("user".equals(message.role) || "assistant".equals(message.role) || "system".equals(message.role))) throw new IllegalArgumentException("聊天记录格式无效。");
            for (ChatExtras.Attachment attachment : message.attachments) {
                if (attachment == null || extras == null || !"user".equals(message.role)) {
                    throw new IOException("聊天附件记录无效。");
                }
                attachmentCount++;
                attachmentBytes += attachment.size;
                if (attachmentCount > ChatExtras.MAX_ATTACHMENTS || attachmentBytes > ChatExtras.MAX_ATTACHMENT_TOTAL) {
                    throw new IOException("每次最多发送 3 个附件，合计不超过 4 MB。");
                }
            }
            if ("system".equals(message.role)) append(system, message.content);
            if ("openAI".equals(model.protocol) || (!"system".equals(message.role) && "anthropic".equals(model.protocol))) {
                Object content = message.attachments.isEmpty()
                        ? message.content : parts(message, model, extras, agentMode);
                conversation.put(new JSONObject().put("role", message.role).put("content", content));
            } else if (!"system".equals(message.role) && "gemini".equals(model.protocol)) {
                conversation.put(new JSONObject().put("role", "assistant".equals(message.role) ? "model" : "user")
                        .put("parts", parts(message, model, extras, agentMode)));
            }
        }
        if ("openAI".equals(model.protocol)) {
            payload.put("model", model.modelID).put("messages", conversation).put("stream", false);
            String adapter = Endpoints.thinkingAdapter(model.modelID, Endpoints.validate(model.baseURL));
            if ("qwen-max".equals(adapter)) payload.put("enable_thinking", false).put("preserve_thinking", false);
            else if ("deepseek-v4".equals(adapter)) payload.put("thinking", new JSONObject().put("type", "disabled"));
            else if ("glm-5.3".equals(adapter)) payload.put("thinking", new JSONObject().put("type", "enabled")).put("reasoning_effort", "low");
            if (model.freeCatalog) payload.put("provider", new JSONObject().put("max_price", new JSONObject().put("prompt", 0).put("completion", 0)));
        } else if ("anthropic".equals(model.protocol)) {
            payload.put("model", model.modelID).put("messages", conversation).put("max_tokens", 2048);
            if (system.length() > 0) payload.put("system", system.toString());
        } else if ("gemini".equals(model.protocol)) {
            payload.put("contents", conversation).put("generationConfig", new JSONObject().put("maxOutputTokens", 2048));
            if (system.length() > 0) payload.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system.toString()))));
        } else { throw new IllegalArgumentException("不支持此接口协议。"); }
        return payload;
    }

    private static JSONArray parts(Message message, ModelStore.Model model, ChatExtras extras,
                                   boolean agentMode) throws Exception {
        String protocol = model.protocol;
        JSONArray parts = new JSONArray();
        if (!message.content.isEmpty() || message.attachments.isEmpty()) parts.put(textPart(message.content, protocol));
        for (ChatExtras.Attachment attachment : message.attachments) {
            String mime = attachment.mimeType;
            boolean isPdf = ChatExtras.PDF.equals(mime);
            if (isPdf && !supportsPdf(model)) {
                throw new IOException("所选模型的当前接口未确认支持 PDF，请选择支持 PDF 的官方模型或将文档转换为 TXT。");
            }
            if (model.freeCatalog && !ChatExtras.isText(mime)) {
                throw new IOException("免费目录只确认了文本能力，请改选支持图片或 PDF 的模型。");
            }
            if (ChatExtras.isText(mime)) {
                String contents = agentMode ? "可用 read_text_attachment 读取。"
                        : ChatExtras.decodeText(extras.loadAttachment(attachment));
                parts.put(textPart("附件：" + attachment.name + "\n" + contents, protocol));
                continue;
            }
            String data = Base64.getEncoder().encodeToString(extras.loadAttachment(attachment));
            if ("openAI".equals(protocol)) {
                String dataUrl = "data:" + mime + ";base64," + data;
                if (isPdf) {
                    parts.put(new JSONObject().put("type", "file").put("file", new JSONObject()
                            .put("filename", attachment.name).put("file_data", dataUrl)));
                } else {
                    parts.put(new JSONObject().put("type", "image_url")
                            .put("image_url", new JSONObject().put("url", dataUrl)));
                }
            } else if ("anthropic".equals(protocol)) {
                parts.put(new JSONObject().put("type", isPdf ? "document" : "image").put("source",
                        new JSONObject().put("type", "base64").put("media_type", mime).put("data", data)));
            } else if ("gemini".equals(protocol)) {
                parts.put(new JSONObject().put("inlineData", new JSONObject().put("mimeType", mime).put("data", data)));
            }
        }
        return parts;
    }

    private static JSONObject textPart(String text, String protocol) throws Exception {
        JSONObject part = new JSONObject().put("text", text);
        if (!"gemini".equals(protocol)) part.put("type", "text");
        return part;
    }

    private static boolean supportsPdf(ModelStore.Model model) {
        String host = Endpoints.validate(model.baseURL).getHost().toLowerCase(Locale.ROOT);
        String id = model.modelID == null ? "" : model.modelID.toLowerCase(Locale.ROOT);
        if ("openAI".equals(model.protocol) && "api.openai.com".equals(host)) {
            return id.startsWith("gpt-4o") || id.startsWith("gpt-4.1") || id.startsWith("gpt-5");
        }
        if ("anthropic".equals(model.protocol) && "api.anthropic.com".equals(host)) {
            return id.startsWith("claude-");
        }
        return "gemini".equals(model.protocol) && "generativelanguage.googleapis.com".equals(host)
                && (id.startsWith("gemini-") || id.startsWith("models/gemini-"))
                && !id.contains("image") && !id.contains("embedding")
                && !id.contains("tts") && !id.contains("live");
    }

    static String extractText(JSONObject response, String protocol) {
        StringBuilder answer = new StringBuilder();
        if ("openAI".equals(protocol)) {
            JSONArray choices = response.optJSONArray("choices");
            JSONObject choice = choices == null ? null : choices.optJSONObject(0);
            JSONObject message = choice == null ? null : choice.optJSONObject("message");
            Object content = message == null ? null : message.opt("content");
            if (content instanceof String) return (String) content;
            if (content instanceof JSONArray) appendTexts(answer, (JSONArray) content, false);
        } else if ("anthropic".equals(protocol)) {
            appendTexts(answer, response.optJSONArray("content"), true);
        } else {
            JSONArray candidates = response.optJSONArray("candidates");
            JSONObject first = candidates == null ? null : candidates.optJSONObject(0);
            JSONObject content = first == null ? null : first.optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            if (parts != null) for (int i = 0; i < parts.length(); i++) {
                JSONObject part = parts.optJSONObject(i);
                if (part != null && !part.optBoolean("thought", false)) append(answer, part.optString("text", ""));
            }
        }
        return answer.toString();
    }

    private static void appendTexts(StringBuilder result, JSONArray parts, boolean anthropic) {
        if (parts == null) return;
        for (int i = 0; i < parts.length(); i++) {
            JSONObject part = parts.optJSONObject(i);
            if (part != null && (!anthropic || "text".equals(part.optString("type")))) append(result, part.optString("text", ""));
        }
    }
    private static void append(StringBuilder result, String value) { if (!value.isEmpty()) { if (result.length() > 0) result.append('\n'); result.append(value); } }

    private static JSONObject request(String address, JSONObject body, Map<String, String> headers, String secret) throws Exception {
        if (Thread.currentThread().isInterrupted()) throw new IOException("请求已取消。");
        Endpoints.validate(address);
        HttpURLConnection connection = (HttpURLConnection) new URI(address).toURL().openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(20000); connection.setReadTimeout(75000);
        connection.setUseCaches(false); connection.setRequestMethod(body == null ? "GET" : "POST");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", "AIJIU-Android/1.1");
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            if (entry.getValue().contains("\r") || entry.getValue().contains("\n")) throw new IllegalArgumentException("密钥格式无效。");
            connection.setRequestProperty(entry.getKey(), entry.getValue());
        }
        try {
            if (body != null) {
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                if (bytes.length > MAX_BODY) throw new IOException("本次聊天内容和附件过大，请减少附件或新建对话后重试。");
                connection.setDoOutput(true); connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream output = connection.getOutputStream()) { output.write(bytes); }
            }
            int status = connection.getResponseCode();
            InputStream input = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            String text = readBody(input);
            if (status < 200 || status >= 300) {
                String message = "服务商没有返回可用结果。";
                try {
                    JSONObject error = new JSONObject(text).optJSONObject("error");
                    if (error != null) message = error.optString("message", message);
                } catch (Exception ignored) { }
                if (secret != null && !secret.isEmpty()) message = message.replace(secret, "[密钥已隐藏]");
                message = message.replaceAll("sk-[A-Za-z0-9_\\-]+", "[密钥已隐藏]");
                if (message.length() > 220) message = message.substring(0, 220);
                throw new IOException("请求失败（" + status + "）：" + message);
            }
            try { return new JSONObject(text); }
            catch (Exception malformed) { throw new IOException("服务商返回了无法识别的数据。"); }
        } finally { connection.disconnect(); }
    }

    private static String readBody(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream stream = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] block = new byte[8192];
            for (int count; (count = stream.read(block)) != -1;) {
                if (Thread.currentThread().isInterrupted()) throw new IOException("请求已取消。");
                if (output.size() + count > MAX_BODY) throw new IOException("服务商响应过大，请新建对话后重试。");
                output.write(block, 0, count);
            }
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
