package com.gujiu.aijiu;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Local conversation snapshots. The active pointer and its content commit together. */
final class ChatHistory {
    private static final int MAX_BYTES = 24 * 1024 * 1024;

    static final class Conversation {
        final String id, modelId, draft, skillId;
        final long updatedAt;
        final JSONArray messages, draftAttachments;
        final JSONObject pending;

        private Conversation(String id, String modelId, String draft, String skillId, long updatedAt,
                             JSONArray messages, JSONObject pending, JSONArray draftAttachments) {
            this.id = id;
            this.modelId = modelId;
            this.draft = draft;
            this.skillId = skillId;
            this.updatedAt = updatedAt;
            this.messages = messages;
            this.pending = pending;
            this.draftAttachments = draftAttachments;
        }

        Conversation withContent(JSONArray messages, JSONObject pending, String draft, JSONArray attachments) {
            return new Conversation(id, modelId, draft, skillId, System.currentTimeMillis(), messages, pending, attachments);
        }

        Conversation withModel(String modelId) {
            return new Conversation(id, modelId, draft, skillId, updatedAt, messages, pending, draftAttachments);
        }

        Conversation withSkill(String skillId) {
            return new Conversation(id, modelId, draft, skillId, updatedAt, messages, pending, draftAttachments);
        }

        boolean hasContent() {
            return messages.length() > 0 || pending != null || !draft.trim().isEmpty() || draftAttachments.length() > 0;
        }

        String title() {
            for (int index = 0; index < messages.length(); index++) {
                JSONObject message = messages.optJSONObject(index);
                if (message != null && "user".equals(message.optString("role"))) return titleOf(message.optString("text"));
            }
            return titleOf(pending == null ? draft : pending.optString("text"));
        }

        private String titleOf(String text) {
            String title = text.trim().replace('\n', ' ').replace('\r', ' ');
            if (title.isEmpty()) return "无标题对话";
            int count = title.codePointCount(0, title.length());
            return count > 40 ? title.substring(0, title.offsetByCodePoints(0, 40)) + "…" : title;
        }

        private JSONObject json() throws JSONException {
            return new JSONObject().put("id", id).put("modelId", modelId).put("draft", draft)
                    .put("skillId", skillId).put("updatedAt", updatedAt).put("messages", messages)
                    .put("pending", pending == null ? JSONObject.NULL : pending).put("draftAttachments", draftAttachments);
        }

        private static Conversation from(JSONObject row) throws JSONException {
            return new Conversation(row.getString("id"), row.optString("modelId"), row.optString("draft"),
                    row.optString("skillId"), row.getLong("updatedAt"), row.getJSONArray("messages"),
                    row.optJSONObject("pending"), row.getJSONArray("draftAttachments"));
        }
    }

    private final Path path;
    private LinkedHashMap<String, Conversation> conversations = new LinkedHashMap<>();
    private String activeId = "";

    ChatHistory(Path path) throws IOException {
        this.path = path;
        if (Files.notExists(path)) return;
        if (Files.size(path) > MAX_BYTES) throw new IOException("本地聊天记录超过可读取的大小。");
        try {
            JSONObject snapshot = new JSONObject(new String(Files.readAllBytes(path), StandardCharsets.UTF_8));
            if (snapshot.getInt("version") != 1) throw new IOException("无法打开此版本的聊天记录。");
            JSONArray rows = snapshot.getJSONArray("conversations");
            for (int index = 0; index < rows.length(); index++) {
                Conversation value = Conversation.from(rows.getJSONObject(index));
                conversations.put(value.id, value);
            }
            activeId = snapshot.getString("activeId");
        } catch (JSONException invalid) {
            throw new IOException("本地聊天记录格式无效。", invalid);
        }
    }

    synchronized Conversation open(String modelId) {
        Conversation current = conversations.get(activeId);
        return current == null ? empty(modelId) : current;
    }

    synchronized Conversation start(String modelId) throws IOException {
        Conversation created = empty(modelId);
        save(created, true);
        return created;
    }

    synchronized List<Conversation> list() {
        ArrayList<Conversation> result = new ArrayList<>();
        for (Conversation conversation : conversations.values()) {
            if (conversation.hasContent()) result.add(conversation);
        }
        result.sort((left, right) -> Long.compare(right.updatedAt, left.updatedAt));
        return result;
    }

    synchronized Conversation activate(String id) throws IOException {
        Conversation selected = conversations.get(id);
        if (selected == null) throw new IOException("找不到这条对话。");
        save(selected, true);
        return selected;
    }

    synchronized void delete(String id, String modelId) throws IOException {
        LinkedHashMap<String, Conversation> next = new LinkedHashMap<>(conversations);
        next.remove(id);
        String active = activeId;
        if (id.equals(activeId)) {
            Conversation created = empty(modelId);
            next.put(created.id, created);
            active = created.id;
        }
        write(next, active);
    }

    synchronized void save(Conversation conversation, boolean makeActive) throws IOException {
        LinkedHashMap<String, Conversation> next = new LinkedHashMap<>(conversations);
        if (makeActive && !activeId.equals(conversation.id)) {
            Conversation prior = next.get(activeId);
            if (prior != null && !prior.hasContent()) next.remove(activeId);
        }
        next.put(conversation.id, conversation);
        write(next, makeActive ? conversation.id : activeId);
    }

    private static Conversation empty(String modelId) {
        return new Conversation(UUID.randomUUID().toString(), modelId, "", "", System.currentTimeMillis(),
                new JSONArray(), null, new JSONArray());
    }

    private void write(LinkedHashMap<String, Conversation> next, String active) throws IOException {
        byte[] bytes;
        try {
            JSONArray rows = new JSONArray();
            for (Conversation value : next.values()) rows.put(value.json());
            bytes = new JSONObject().put("version", 1).put("activeId", active)
                    .put("conversations", rows).toString().getBytes(StandardCharsets.UTF_8);
        } catch (JSONException invalid) {
            throw new IOException("无法写入聊天记录。", invalid);
        }
        if (bytes.length > MAX_BYTES) throw new IOException("本地聊天记录已满。请先删除部分旧对话。");
        Path temp = Files.createTempFile(path.getParent(), "chat-history", ".tmp");
        try {
            try (FileChannel channel = FileChannel.open(temp, StandardOpenOption.WRITE)) {
                ByteBuffer buffer = ByteBuffer.wrap(bytes);
                while (buffer.hasRemaining()) channel.write(buffer);
                channel.force(true);
            }
            Files.move(temp, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(temp);
        }
        conversations = next;
        activeId = active;
    }
}
