package com.gujiu.aijiu;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;

/** Public, data-only catalog. It has no access to local models, credentials, or chat messages. */
public final class CloudCatalog {
    public static final String CATALOG_URL = "https://raw.githubusercontent.com/gujiu520/aihub-ios/main/catalog.json";
    public static final String RELEASE_URL = "https://github.com/gujiu520/aihub-ios/releases/latest";
    public static final int MAX_BYTES = 256 * 1024;
    public static final long HOUR = 60L * 60L * 1000L;
    private static final Set<String> PROTOCOLS = new HashSet<>(Arrays.asList("openAI", "anthropic", "gemini"));
    private static final Set<String> LOGOS = new HashSet<>(Arrays.asList("automatic", "openai", "anthropic", "google", "deepseek", "qwen", "glm", "kimi", "baidu", "custom"));
    private static final Set<String> CATEGORIES = new HashSet<>(Arrays.asList("large", "domestic-free"));
    private CloudCatalog() { }

    public static final class Preset {
        public final String id, name, modelID, baseURL, protocol, logo, provider, note, category;
        public final boolean requiresKey = true, freeCatalog = false;
        private Preset(JSONObject row) throws Exception {
            id = string(row,"id",128,false); name = string(row,"name",128,false);
            modelID = string(row,"modelID",256,false); baseURL = string(row,"baseURL",2048,false);
            protocol = string(row,"protocol",32,false); logo = string(row,"logo",32,false);
            provider = string(row,"provider",128,false); note = string(row,"note",2000,true);
            category = string(row,"category",32,false);
            require(PROTOCOLS.contains(protocol) && LOGOS.contains(logo) && CATEGORIES.contains(category), "不支持的模型类型。");
            require(Boolean.TRUE.equals(row.get("requiresKey")) && Boolean.FALSE.equals(row.get("freeCatalog")), "推荐模型必须使用个人 API Key。");
            validatePresetURL(baseURL);
        }
    }
    public static final class Manifest {
        public final long revision;
        public final String updatedAt, announcement, latestVersion, releaseURL;
        public final List<Preset> presets;
        final String encoded;
        private Manifest(long revision,String updatedAt,String announcement,String latestVersion,List<Preset> presets,String encoded) {
            this.revision=revision; this.updatedAt=updatedAt; this.announcement=announcement;
            this.latestVersion=latestVersion; this.releaseURL=RELEASE_URL;
            this.presets=Collections.unmodifiableList(presets); this.encoded=encoded;
        }
    }

    /** Validates the whole document before returning anything suitable for persistence. */
    public static Manifest parse(byte[] bytes,long minimumRevision) {
        try {
            require(bytes!=null && bytes.length>0 && bytes.length<=MAX_BYTES,"云端目录为空或超过大小限制。");
            String json=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            // Android's org.json accepts JavaScript-like syntax; reject that before decoding real JSON.
            new StrictJson(json).validate();
            JSONTokener tokener=new JSONTokener(json); Object decoded=tokener.nextValue();
            require(decoded instanceof JSONObject && tokener.nextClean()==0,"云端目录 JSON 无效。");
            JSONObject root=(JSONObject)decoded;
            require(integer(root.get("schemaVersion"))==1,"不支持的目录版本。");
            long revision=integer(root.get("revision"));
            require(revision>0 && revision>=minimumRevision,"目录修订号无效或早于本地缓存。");
            String updatedAt=string(root,"updatedAt",64,false);
            require(updatedAt.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d{1,9})?(?:Z|[+-]\\d{2}:\\d{2})"),"目录时间格式无效。");
            OffsetDateTime.parse(updatedAt,DateTimeFormatter.ISO_OFFSET_DATE_TIME.withResolverStyle(ResolverStyle.STRICT));
            String announcement=string(root,"announcement",2000,true);
            String version=string(root,"latestVersion",32,false); versionParts(version);
            require(RELEASE_URL.equals(string(root,"releaseURL",256,false)),"下载链接无效。");
            Object rows=root.get("presets"); require(rows instanceof JSONArray,"推荐列表类型无效。");
            JSONArray array=(JSONArray)rows; require(array.length()>=1 && array.length()<=100,"推荐列表数量无效。");
            ArrayList<Preset> presets=new ArrayList<>(); HashSet<String> ids=new HashSet<>();
            for(int i=0;i<array.length();i++) {
                Object item=array.get(i); require(item instanceof JSONObject,"推荐模型格式无效。");
                Preset preset=new Preset((JSONObject)item); require(ids.add(preset.id),"推荐模型 ID 重复。"); presets.add(preset);
            }
            return new Manifest(revision,updatedAt,announcement,version,presets,json);
        } catch(IllegalArgumentException failure) { throw failure; }
        catch(Exception failure) { throw new IllegalArgumentException("云端目录格式或字段无效。",failure); }
    }

    private static String string(JSONObject object,String field,int maximum,boolean allowEmpty) throws Exception {
        Object raw=object.get(field); require(raw instanceof String,"目录字段类型无效。");
        String value=(String)raw;
        require(value.codePointCount(0,value.length())<=maximum && (allowEmpty || !value.trim().isEmpty()),"目录字段为空或过长。");
        for(int i=0;i<value.length();i++) {
            char c=value.charAt(i);
            require((c>=0x20 || c=='\n' || c=='\r' || c=='\t') && c!=0x7f,"目录字段包含控制字符。");
            if(Character.isHighSurrogate(c)) { require(i+1<value.length() && Character.isLowSurrogate(value.charAt(i+1)),"目录文本编码无效。"); i++; }
            else require(!Character.isLowSurrogate(c),"目录文本编码无效。");
        }
        if(!allowEmpty) require(value.equals(value.trim()),"目录字段包含多余空白。");
        return value;
    }
    private static long integer(Object raw) {
        require(raw instanceof Integer || raw instanceof Long,"目录整数类型无效。"); return ((Number)raw).longValue();
    }
    private static void validatePresetURL(String text) throws Exception {
        URI uri=new URI(text); String host=uri.getHost();
        require("https".equalsIgnoreCase(uri.getScheme()) && host!=null && !host.isEmpty()
                && uri.getRawUserInfo()==null && uri.getRawQuery()==null && uri.getRawFragment()==null
                && (uri.getPort()==-1 || uri.getPort()>=1 && uri.getPort()<=65535),"推荐接口必须是无凭据的 HTTPS 地址。");
        host=host.toLowerCase(Locale.ROOT);
        while(host.endsWith(".")) host=host.substring(0,host.length()-1);
        require(!host.equals("localhost") && !host.endsWith(".localhost") && !host.equals("0.0.0.0")
                && !host.startsWith("127.") && !host.equals("[::1]") && !host.equals("::1")
                && !host.equals("[0:0:0:0:0:0:0:1]") && !host.equals("[::ffff:127.0.0.1]")
                && !host.equals("[::]") && !host.equals("0") && !host.equals("2130706433"),"推荐接口不能指向回环地址。");
        // Resolve only literal addresses, never a remote hostname during validation.
        if(host.indexOf(':')>=0 || host.matches("[0-9.]+")) {
            InetAddress address=InetAddress.getByName(host);
            require(!address.isLoopbackAddress() && !address.isAnyLocalAddress(),"推荐接口不能指向回环地址。");
        }
    }
    private static long[] versionParts(String value) {
        require(value!=null && value.matches("(?:0|[1-9]\\d{0,8})\\.(?:0|[1-9]\\d{0,8})\\.(?:0|[1-9]\\d{0,8})"),"版本号无效。");
        String[] parts=value.split("\\."); return new long[]{Long.parseLong(parts[0]),Long.parseLong(parts[1]),Long.parseLong(parts[2])};
    }
    public static int compareVersions(String first,String second) {
        long[] a=versionParts(first),b=versionParts(second);
        for(int i=0;i<3;i++) if(a[i]!=b[i]) return a[i]<b[i]?-1:1;
        return 0;
    }
    public static boolean shouldRefresh(boolean enabled,long lastSuccess,long now) {
        return enabled && (lastSuccess<=0 || now<lastSuccess || now-lastSuccess>=HOUR);
    }

    /** Fixed public URL only. Never accepts an endpoint, credentials, cookies, or user payload. */
    public static byte[] fetch() throws IOException {
        HttpsURLConnection connection=(HttpsURLConnection)new URL(CATALOG_URL).openConnection();
        long deadline=System.nanoTime()+25_000_000_000L;
        try {
            connection.setInstanceFollowRedirects(false); connection.setRequestMethod("GET");
            connection.setConnectTimeout(10_000); connection.setReadTimeout(10_000);
            connection.setUseCaches(false); connection.setAllowUserInteraction(false);
            connection.setRequestProperty("Accept","application/json");
            connection.setRequestProperty("Accept-Encoding","identity");
            // The app installs no CookieHandler or Authenticator. Empty cookie headers also prevent cached cookie propagation.
            connection.setRequestProperty("Cookie",""); connection.setRequestProperty("Cookie2","");
            requireRemaining(deadline,connection);
            int status=connection.getResponseCode();
            if(status!=200) throw new IOException("云端目录返回 HTTP "+status+"。");
            long length=connection.getContentLengthLong();
            if(length>MAX_BYTES) throw new IllegalArgumentException("云端目录超过大小限制。");
            String encoding=connection.getContentEncoding();
            if(encoding!=null && !encoding.equalsIgnoreCase("identity")) throw new IOException("不支持的目录压缩格式。");
            try(InputStream input=connection.getInputStream()) { return readBounded(input,deadline,connection); }
        } finally { connection.disconnect(); }
    }
    public static byte[] readBounded(InputStream input) throws IOException { return readBounded(input,0,null); }
    private static byte[] readBounded(InputStream input,long deadline,HttpsURLConnection connection) throws IOException {
        ByteArrayOutputStream output=new ByteArrayOutputStream(); byte[] block=new byte[4096];
        while(true) {
            if(deadline!=0) requireRemaining(deadline,connection);
            int count=input.read(block); if(count==-1) break; if(count==0) continue;
            if(output.size()+count>MAX_BYTES) throw new IllegalArgumentException("云端目录超过大小限制。");
            output.write(block,0,count);
        }
        return output.toByteArray();
    }
    private static void requireRemaining(long deadline,HttpsURLConnection connection) throws IOException {
        long remaining=(deadline-System.nanoTime())/1_000_000L;
        if(remaining<=0) throw new IOException("云端目录请求超时。");
        connection.setReadTimeout((int)Math.max(1,Math.min(10_000,remaining)));
    }
    private static void require(boolean condition,String message) { if(!condition) throw new IllegalArgumentException(message); }

    /** Only enforces RFC JSON grammar; all data extraction and type validation uses real org.json above. */
    private static final class StrictJson {
        private final String text; private int position;
        StrictJson(String text) { this.text=text; }
        void validate() { whitespace(); value(0); whitespace(); require(position==text.length(),"JSON 包含多余内容。"); }
        private void value(int depth) {
            require(depth<=32 && position<text.length(),"JSON 嵌套过深或不完整。"); char c=text.charAt(position);
            if(c=='{') { position++; whitespace(); Set<String> keys=new HashSet<>(); if(take('}'))return;
                do { require(position<text.length() && text.charAt(position)=='"',"JSON 字段名无效。");
                    int start=position; string(); String key;
                    try { key=(String)new JSONTokener(text.substring(start,position)).nextValue(); } catch(Exception error) { throw new IllegalArgumentException("JSON 字段名无效。",error); }
                    require(keys.add(key),"JSON 字段重复。"); whitespace(); require(take(':'),"JSON 缺少冒号。"); whitespace(); value(depth+1); whitespace(); if(take('}'))return; require(take(','),"JSON 缺少逗号。"); whitespace();
                } while(true);
            } else if(c=='[') { position++; whitespace(); if(take(']'))return;
                do { value(depth+1); whitespace(); if(take(']'))return; require(take(','),"JSON 缺少逗号。"); whitespace(); } while(true);
            } else if(c=='"') string();
            else if(c=='t') literal("true"); else if(c=='f') literal("false"); else if(c=='n') literal("null"); else number();
        }
        private void string() {
            require(take('"'),"JSON 字符串无效。");
            while(position<text.length()) { char c=text.charAt(position++); if(c=='"')return; require(c>=0x20,"JSON 字符串包含控制字符。");
                if(c=='\\') { require(position<text.length(),"JSON 转义不完整。"); char escaped=text.charAt(position++);
                    if(escaped=='u') { require(position+4<=text.length(),"JSON Unicode 转义不完整。"); for(int i=0;i<4;i++) require(Character.digit(text.charAt(position++),16)>=0,"JSON Unicode 转义无效。"); }
                    else require("\"\\/bfnrt".indexOf(escaped)>=0,"JSON 转义无效。");
                }
            }
            throw new IllegalArgumentException("JSON 字符串不完整。");
        }
        private void number() {
            take('-'); require(position<text.length(),"JSON 数字无效。");
            if(!take('0')) { require(position<text.length() && text.charAt(position)>='1' && text.charAt(position)<='9',"JSON 数字无效。"); while(digit())position++; }
            if(take('.')) { require(digit(),"JSON 小数无效。"); while(digit())position++; }
            if(take('e')||take('E')) { if(!take('+'))take('-'); require(digit(),"JSON 指数无效。"); while(digit())position++; }
        }
        private boolean digit() { return position<text.length() && text.charAt(position)>='0' && text.charAt(position)<='9'; }
        private void literal(String value) { require(text.startsWith(value,position),"JSON 字面量无效。"); position+=value.length(); }
        private boolean take(char c) { if(position<text.length() && text.charAt(position)==c) { position++; return true; } return false; }
        private void whitespace() { while(position<text.length() && " \n\r\t".indexOf(text.charAt(position))>=0)position++; }
    }
}
