package com.gujiu.aijiu;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListPopupWindow;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Native Android UI, with real requests delegated to ChatService and no embedded credentials. */
public final class MainActivity extends Activity {
    private static final int PICK_ATTACHMENT = 20;
    private static final int PICK_SKILL = 21;
    private static final int EXPORT_ARTIFACT = 22;
    private ModelStore store;
    private ChatExtras extras;
    private List<SupplierDirectory.Entry> bundledSuppliers;
    private List<ChatExtras.Skill> builtInSkills;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    // Application-lifetime worker: finishing an Activity must not interrupt an atomic cache write.
    private static final ExecutorService CLOUD_EXECUTOR = Executors.newSingleThreadExecutor();
    private final ArrayList<Runnable> cloudObservers = new ArrayList<>();
    private boolean cloudSyncQueued;
    private final ArrayList<ChatService.Message> messages = new ArrayList<>();
    private ChatHistory history;
    private ChatHistory.Conversation conversation;
    private final ArrayList<ChatExtras.Attachment> attachments = new ArrayList<>();
    private ChatExtras.Skill selectedSkill;
    private JSONObject pendingExport;
    private LinearLayout root, chatContent;
    private ScrollView chatScroll;
    private EditText composer;
    private Button sendButton;
    private TextView stateLabel, errorLabel;
    private boolean dark, sending, refreshing, importing;
    private int bg, surface, soft, ink, muted, line, accent, onAccent, danger;
    private String draft = "", failure = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = ModelStore.get(this);
        extras = new ChatExtras(this);
        try {
            history = new ChatHistory(getNoBackupFilesDir().toPath().resolve("chat-history-v1.json"));
            loadConversation(history.open(store.getSelectedId()));
            if (state != null && !conversation.hasContent()) restorePreviousInstance(state);
        } catch (IOException | JSONException error) {
            history = null;
            failure = "无法打开本地聊天记录。";
        }
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        renderHome(); RefreshJobService.schedule(this);
    }

    @Override protected void onResume() { super.onResume(); if (store != null) { if(store.isAutoRefresh()) refresh(false, false, null); syncCloud(false,false); } }
    @Override public void onConfigurationChanged(Configuration configuration) { super.onConfigurationChanged(configuration); rememberDraft(); renderHome(); }
    @Override protected void onPause() {
        super.onPause();
        saveDraft();
    }
    @Override protected void onDestroy() { cloudObservers.clear(); executor.shutdownNow(); super.onDestroy(); }

    private void palette() {
        String theme = store.getTheme();
        dark = "dark".equals(theme) || (!"light".equals(theme) && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        bg = dark ? 0xff12131a : 0xfffafaff; surface = dark ? 0xff1e202b : Color.WHITE; soft = dark ? 0xff292b3b : 0xfff0f0f9;
        ink = dark ? 0xffeeeff8 : 0xff222433; muted = dark ? 0xffaaaec5 : 0xff696e85; line = dark ? 0xff343747 : 0xffe3e4ee;
        accent = dark ? 0xffbec0ff : 0xff565cce; onAccent = dark ? 0xff23264a : Color.WHITE; danger = dark ? 0xffffada5 : 0xffb43f3c;
        setTheme(dark ? android.R.style.Theme_Material_NoActionBar : android.R.style.Theme_Material_Light_NoActionBar);
        getWindow().setStatusBarColor(Build.VERSION.SDK_INT >= 30 ? Color.TRANSPARENT : bg);
        getWindow().setNavigationBarColor(Build.VERSION.SDK_INT >= 30 ? Color.TRANSPARENT : bg);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private void renderHome() {
        palette(); root = column(); root.setBackgroundColor(bg);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                android.graphics.Insets keyboard = insets.getInsets(WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, keyboard.bottom)); return insets;
            });
        }
        LinearLayout header = row(); header.setPadding(dp(14),dp(9),dp(14),dp(9));
        Button settings = iconButton("☰", "设置与开发者信息"); settings.setOnClickListener(v -> showSettings()); header.addView(settings, lp(44,44));
        Button historyButton = iconButton("◷","聊天记录");
        historyButton.setOnClickListener(v -> showHistory());
        header.addView(historyButton,lp(44,44));
        ModelStore.Model current = activeModel();
        String modelName = current == null ? "选择模型" : current.name;
        LinearLayout model = row();
        model.setPadding(dp(10),0,dp(10),0);
        model.setBackground(shape(surface,23,line));
        model.setContentDescription(current == null ? modelName : "当前模型：" + modelName + "，点按切换");
        model.addView(logo(current,23),lp(23,23));
        TextView modelTitle = text(modelName,16,ink,true);
        modelTitle.setMaxLines(1);
        modelTitle.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0,-2,1);
        titleParams.setMargins(dp(8),0,dp(4),0);
        model.addView(modelTitle,titleParams);
        model.addView(text("⌄",17,muted,false),lp(16,24));
        model.setOnClickListener(this::showModelDropdown);
        LinearLayout.LayoutParams modelParams = new LinearLayout.LayoutParams(0,dp(44),1);
        modelParams.setMargins(dp(8),0,dp(8),0);
        header.addView(model,modelParams);
        Button fresh = iconButton("＋","新建对话");
        fresh.setOnClickListener(v -> startConversation());
        header.addView(fresh,lp(44,44)); root.addView(header);
        chatScroll = new ScrollView(this); chatScroll.setFillViewport(true); chatScroll.setClipToPadding(false); chatScroll.setPadding(dp(24),0,dp(24),0);
        chatContent = column(); chatScroll.addView(chatContent,new ScrollView.LayoutParams(-1,-1)); root.addView(chatScroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout dock = column(); dock.setPadding(dp(16),0,dp(16),dp(12));
        errorLabel = text(failure,13,danger,false); errorLabel.setPadding(dp(11),dp(10),dp(11),dp(10)); errorLabel.setBackground(shape(dark?0xff352326:0xffffefec,14,Color.TRANSPARENT)); errorLabel.setTextIsSelectable(true); errorLabel.setVisibility(failure.isEmpty()?View.GONE:View.VISIBLE); dock.addView(errorLabel);
        LinearLayout connection = row(); connection.setPadding(dp(6),0,0,0); stateLabel = text(connectionText(),11,muted,false); stateLabel.setMaxLines(1); stateLabel.setEllipsize(TextUtils.TruncateAt.END); connection.addView(stateLabel,new LinearLayout.LayoutParams(0,dp(40),1));
        Button setup = linkButton(current != null && current.freeCatalog ? "配置 Key" : "API 配置"); setup.setTextSize(12); setup.setOnClickListener(v -> configureCurrent()); connection.addView(setup,lp(-2,44)); dock.addView(connection);
        LinearLayout additions = row();
        Button attach = linkButton("添加附件");
        attach.setContentDescription("添加图片、PDF 或文本附件");
        attach.setOnClickListener(v -> pickAttachment());
        additions.addView(attach,lp(-2,44));
        String skillTitle = selectedSkill == null ? "Skill" : selectedSkill.name;
        Button skill = linkButton(skillTitle);
        skill.setMaxLines(1);
        skill.setEllipsize(TextUtils.TruncateAt.END);
        skill.setContentDescription("选择 Skill：" + skillTitle);
        skill.setOnClickListener(v -> showSkills());
        additions.addView(skill,new LinearLayout.LayoutParams(0,dp(44),1));
        dock.addView(additions);
        for (ChatExtras.Attachment attachment : attachments) {
            LinearLayout item = row();
            TextView filename = text(attachment.name,12,muted,false);
            filename.setSingleLine();
            filename.setEllipsize(TextUtils.TruncateAt.END);
            item.addView(filename,new LinearLayout.LayoutParams(0,-2,1));
            Button remove = linkButton("移除");
            remove.setContentDescription("移除附件 " + attachment.name);
            remove.setOnClickListener(v -> removeAttachment(attachment));
            item.addView(remove,lp(-2,44));
            dock.addView(item);
        }
        LinearLayout inputRow = row(); inputRow.setGravity(Gravity.BOTTOM); inputRow.setPadding(dp(15),dp(8),dp(8),dp(8)); inputRow.setBackground(shape(surface,26,line));
        composer = new EditText(this); composer.setTextColor(ink); composer.setHintTextColor(muted); composer.setTextSize(17); composer.setHint("发消息…"); composer.setBackgroundColor(Color.TRANSPARENT); composer.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); composer.setMinLines(1); composer.setMaxLines(5); composer.setPadding(0,dp(10),dp(5),dp(10)); composer.setText(draft); composer.setContentDescription("消息内容"); inputRow.addView(composer,new LinearLayout.LayoutParams(0,-2,1));
        sendButton = new Button(this); sendButton.setAllCaps(false); sendButton.setTextSize(22); sendButton.setTypeface(Typeface.DEFAULT,Typeface.BOLD); sendButton.setTextColor(onAccent); sendButton.setPadding(0,0,0,0); sendButton.setMinWidth(0); sendButton.setMinimumWidth(0); sendButton.setBackground(shape(accent,24,Color.TRANSPARENT)); sendButton.setContentDescription("发送消息"); sendButton.setOnClickListener(v -> send()); inputRow.addView(sendButton,lp(44,44)); dock.addView(inputRow); root.addView(dock);
        composer.addTextChangedListener(watcher(() -> { draft=composer.getText().toString(); updateSend(); }));
        setContentView(root); renderMessages(); updateSend();
        if (Build.VERSION.SDK_INT >= 30) root.requestApplyInsets();
    }

    private String connectionText() { ModelStore.Model m=activeModel(); if(m==null)return "选择模型，开始对话"; if(m.freeCatalog)return "OpenRouter · 目录标价为零"; return (empty(m.provider)?"自定义服务":m.provider)+" · 按配置连接"; }
    private void rememberDraft() { if(composer!=null) draft=composer.getText().toString(); }
    private void updateSend() { if(sendButton==null)return; sendButton.setText(sending?"…":"↑"); sendButton.setEnabled(!sending&&!importing&&(!draft.trim().isEmpty()||!attachments.isEmpty())); sendButton.setAlpha(sendButton.isEnabled()?1:.4f); if(composer!=null)composer.setEnabled(!sending); }
    private LogoView logo(ModelStore.Model model,int size) { return new LogoView(this).brand(model==null?"custom":model.resolvedLogo()).palette(ink,accent); }

    private void renderMessages() {
        chatContent.removeAllViews();
        if(messages.isEmpty()) {
            LinearLayout welcome=column(); welcome.setGravity(Gravity.CENTER_HORIZONTAL); welcome.setPadding(0,dp(22),0,dp(8));
            welcome.addView(new View(this),new LinearLayout.LayoutParams(1,0,1));
            welcome.addView(logo(activeModel(),58),lp(58,58)); TextView title=text("有什么想聊的？",28,ink,true); title.setGravity(Gravity.CENTER); marginAdd(welcome,title,0,20,0,0); TextView caption=text("写下问题，或试试下面的灵感。",14,muted,false); caption.setGravity(Gravity.CENTER); marginAdd(welcome,caption,0,10,0,0);
            welcome.addView(new View(this),new LinearLayout.LayoutParams(1,0,1));
            addPrompt(welcome,"≡","把想法写清楚","帮我把这个想法表达得更清楚："); addPrompt(welcome,"◇","帮我理一理","帮我梳理这件事的思路："); addPrompt(welcome,"○","随便聊聊","推荐一个轻松又有趣的聊天话题。");
            chatContent.addView(welcome,new LinearLayout.LayoutParams(-1,-1));
        } else {
            chatContent.setPadding(0,dp(15),0,dp(18));
            for(int index = 0; index < messages.size(); index++) {
                ChatService.Message message = messages.get(index);
                boolean user="user".equals(message.role); LinearLayout holder=column(); holder.setGravity(user?Gravity.RIGHT:Gravity.LEFT);
                if(!user) { TextView tag=text("星枢",11,muted,true); marginAdd(holder,tag,0,0,0,8); }
                TextView content=text(message.content,17,ink,false); content.setTextIsSelectable(true); content.setLineSpacing(dp(4),1); content.setMaxWidth((int)(getResources().getDisplayMetrics().widthPixels*.83));
                if(user) { content.setPadding(dp(15),dp(12),dp(15),dp(12)); content.setBackground(shape(soft,20,Color.TRANSPARENT)); }
                if(!message.content.isEmpty()) holder.addView(content,new LinearLayout.LayoutParams(-2,-2));
                for (ChatExtras.Attachment attachment : message.attachments) {
                    holder.addView(text("附件 · " + attachment.name,12,muted,false));
                }
                if (conversation != null && index < conversation.messages.length()) {
                    addArtifactButtons(holder,conversation.messages.optJSONObject(index));
                }
                marginAdd(chatContent,holder,0,0,0,24);
            }
            if(sending) { TextView waiting=text("正在回复…",14,muted,false); waiting.setPadding(0,dp(3),0,dp(12)); chatContent.addView(waiting); }
            chatScroll.post(()->chatScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void addPrompt(LinearLayout target,String symbol,String title,String prompt) {
        LinearLayout row=row(); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4),0,dp(4),0); TextView mark=text(symbol,20,accent,false); row.addView(mark,lp(30,44)); TextView label=text(title,15,ink,false); row.addView(label,new LinearLayout.LayoutParams(0,dp(44),1)); row.addView(text("↖",16,muted,false),lp(22,44)); row.setContentDescription(title); row.setOnClickListener(v->{ composer.setText(prompt); composer.requestFocus(); ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(composer,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT); }); target.addView(row,new LinearLayout.LayoutParams(-1,dp(47)));
    }

    private void configureCurrent() { ModelStore.Model selected=activeModel(); if(selected!=null&&selected.freeCatalog)showOpenRouterKey(); else showEditor(selected,null); }
    private void send() {
        rememberDraft();
        String input = draft.trim();
        if (sending || importing || (input.isEmpty() && attachments.isEmpty())) return;
        if (conversation == null) { showChatError("无法打开本地聊天记录。"); return; }
        ModelStore.Model model = activeModel();
        if (model == null) { showModels(3); return; }
        String key = store.getKey(model);
        if (model.freeCatalog && key.trim().isEmpty()) { showOpenRouterKey(); return; }
        if (model.requiresKey && key.trim().isEmpty()) { showEditor(model,null); return; }
        ChatService.Message user = new ChatService.Message("user",input,new ArrayList<>(attachments));
        try {
            commitConversation(conversation.withModel(model.id)
                    .withContent(conversation.messages, encodeMessage(user), "", new JSONArray()));
        } catch (IOException | JSONException error) {
            showChatError("无法保存这条消息，请检查手机存储后重试。");
            return;
        }
        List<ChatService.Message> request = new ArrayList<>();
        for (ChatService.Message previous : messages) {
            String messageText = previous.content;
            if (messageText.isEmpty() && !previous.attachments.isEmpty()) messageText = "（此前发送的附件）";
            request.add(new ChatService.Message(previous.role,messageText));
        }
        request.add(user);
        messages.add(user);
        attachments.clear();
        draft = "";
        composer.setText("");
        showChatError("");
        sending = true;
        ChatExtras.Skill skillForTurn = selectedSkill;
        renderHome();
        executor.execute(() -> {
            try {
                if (skillForTurn == null) {
                    String answer = ChatService.send(request, new ModelStore.Model(model), key, extras, null);
                    runOnUiThread(() -> finishSend(user,new ChatService.Message("assistant",answer),new JSONArray(),""));
                } else {
                    StarHubAgent.Result result = ChatService.sendAgent(request,new ModelStore.Model(model),key,extras,skillForTurn,
                            status -> runOnUiThread(() -> {
                                if (!isFinishing() && !isDestroyed() && sending) stateLabel.setText(status);
                            }));
                    JSONArray artifacts = new JSONArray();
                    for (StarHubAgent.Artifact artifact : result.artifacts) {
                        artifacts.put(new JSONObject().put("name",artifact.name).put("mimeType",artifact.mimeType).put("text",artifact.text));
                    }
                    runOnUiThread(() -> finishSend(user,new ChatService.Message("assistant",result.text),artifacts,""));
                }
            } catch (Exception error) {
                runOnUiThread(() -> finishSend(user,null,new JSONArray(),safeError(error,key)));
            }
        });
    }

    private ModelStore.Model activeModel() {
        if (conversation == null || empty(conversation.modelId)) return store.getSelected();
        return store.findModel(conversation.modelId);
    }

    private void selectModel(ModelStore.Model model) {
        rememberDraft();
        if (conversation != null) {
            try {
                commitConversation(conversation.withModel(model.id));
            } catch (IOException error) {
                showChatError("无法保存当前模型，请检查手机存储后重试。");
                return;
            }
        }
        store.select(model.id);
        renderHome();
    }

    private void loadConversation(ChatHistory.Conversation value) throws JSONException, IOException {
        messages.clear();
        for (int i = 0; i < value.messages.length(); i++) {
            JSONObject row = value.messages.getJSONObject(i);
            messages.add(new ChatService.Message(row.getString("role"),row.getString("text"),decodeAttachments(row.optJSONArray("attachments"))));
        }
        conversation = value;
        draft = value.draft;
        attachments.clear();
        attachments.addAll(decodeAttachments(value.draftAttachments));
        selectedSkill = findSkill(value.skillId);
        failure = "";
        if (value.pending != null) {
            if (draft.isEmpty() && attachments.isEmpty()) {
                draft = value.pending.getString("text");
                attachments.addAll(decodeAttachments(value.pending.optJSONArray("attachments")));
            }
            commitConversation(value.withContent(value.messages,null,draft,encodeAttachments(attachments)));
            failure = "上条消息未收到回复。可编辑后手动发送。";
        }
    }

    private void restorePreviousInstance(Bundle state) throws JSONException, IOException {
        JSONArray old = new JSONArray(state.getString("messages", "[]"));
        String oldDraft = state.getString("draft", "");
        if (old.length() == 0 && oldDraft.isEmpty()) return;
        JSONArray migrated = new JSONArray();
        for (int i = 0; i < old.length(); i++) {
            JSONObject item = old.getJSONObject(i);
            migrated.put(new JSONObject().put("role", item.getString("role")).put("text", item.getString("content")));
        }
        ChatHistory.Conversation next = conversation.withContent(migrated, null, oldDraft, new JSONArray());
        commitConversation(next);
        loadConversation(next);
    }

    private static JSONObject encodeMessage(ChatService.Message message) throws JSONException {
        return new JSONObject().put("role",message.role).put("text",message.content).put("attachments",encodeAttachments(message.attachments));
    }

    private static JSONArray encodeAttachments(List<ChatExtras.Attachment> values) throws JSONException {
        JSONArray result = new JSONArray();
        for (ChatExtras.Attachment attachment : values) result.put(attachment.toJson());
        return result;
    }

    private static List<ChatExtras.Attachment> decodeAttachments(JSONArray values) throws JSONException {
        List<ChatExtras.Attachment> result = new ArrayList<>();
        if (values != null) {
            for (int i = 0; i < values.length(); i++) result.add(ChatExtras.Attachment.fromJson(values.getJSONObject(i)));
        }
        return result;
    }

    private void commitConversation(ChatHistory.Conversation next) throws IOException {
        if (history == null) throw new IOException("聊天存储不可用。");
        history.save(next, true);
        conversation = next;
    }

    private boolean saveDraft() {
        rememberDraft();
        if (conversation == null) return false;
        try {
            JSONArray storedAttachments = encodeAttachments(attachments);
            if (!draft.equals(conversation.draft) || !storedAttachments.toString().equals(conversation.draftAttachments.toString())) {
                commitConversation(conversation.withContent(conversation.messages,conversation.pending,draft,storedAttachments));
            }
            return true;
        } catch (IOException | JSONException error) {
            showChatError("无法保存聊天草稿，请检查手机存储。");
            return false;
        }
    }

    private boolean canChangeConversation() {
        if (sending || importing) {
            Toast.makeText(this,sending?"请等待当前回复完成":"请等待文件导入完成",Toast.LENGTH_SHORT).show();
            return false;
        }
        if (history == null) {
            showChatError("无法打开本地聊天记录。");
            return false;
        }
        return saveDraft();
    }

    private void startConversation() {
        if (!canChangeConversation()) return;
        try {
            loadConversation(history.start(store.getSelectedId()));
            renderHome();
        } catch (IOException | JSONException error) {
            showChatError("无法新建对话，请检查手机存储。");
        }
    }

    private void showHistory() {
        if (!canChangeConversation()) return;
        Dialog dialog = sheet("聊天记录");
        LinearLayout body = dialogBody(dialog);
        ScrollView scroll = new ScrollView(this);
        LinearLayout rows = column();
        scroll.addView(rows);
        body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        List<ChatHistory.Conversation> entries = history.list();
        if (entries.isEmpty()) marginAdd(rows,text("还没有保存的对话",15,muted,false),4,12,4,12);
        for (ChatHistory.Conversation entry : entries) {
            String title = entry.title();
            if (entry.id.equals(conversation.id)) title = "✓ " + title;
            String date = DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT)
                    .format(new Date(entry.updatedAt));
            settingsRow(rows,title,date,() -> {
                try {
                    loadConversation(history.activate(entry.id));
                    dialog.dismiss();
                    renderHome();
                } catch (IOException | JSONException error) {
                    showChatError("无法打开这条对话。");
                }
            });
            Button delete = linkButton("删除");
            delete.setContentDescription("删除对话 " + entry.title());
            delete.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("删除这条对话？")
                    .setMessage(entry.title()).setNegativeButton("取消",null)
                    .setPositiveButton("删除",(confirm,which) -> {
                        try {
                            history.delete(entry.id,store.getSelectedId());
                            List<ChatExtras.Attachment> privateFiles = conversationFiles(entry);
                            executor.execute(() -> {
                                for (ChatExtras.Attachment attachment : privateFiles) removePrivateAttachment(attachment);
                            });
                            loadConversation(history.open(store.getSelectedId()));
                            dialog.dismiss();
                            renderHome();
                            showHistory();
                        } catch (IOException | JSONException error) {
                            showChatError("无法删除这条对话。");
                        }
                    }).show());
            rows.addView(delete,lp(-2,44));
        }
        Button create = primaryButton("新建对话");
        create.setOnClickListener(v -> { dialog.dismiss(); startConversation(); });
        body.addView(create,lp(-1,52));
        dialog.show();
        sizeSheet(dialog);
    }

    private void finishSend(ChatService.Message user, ChatService.Message answer, JSONArray artifacts, String error) {
        if (isFinishing() || isDestroyed()) return;
        if (answer != null) {
            try {
                JSONArray completed = new JSONArray();
                for (int i = 0; i < conversation.messages.length(); i++) completed.put(conversation.messages.getJSONObject(i));
                completed.put(encodeMessage(user)).put(encodeMessage(answer).put("artifacts",artifacts));
                commitConversation(conversation.withContent(completed, null, "", new JSONArray()));
                messages.add(answer);
            } catch (IOException | JSONException failure) {
                error = "收到回复，但未能保存。请检查手机存储。";
                answer = null;
            }
        }
        if (answer == null) {
            messages.remove(user);
            draft = user.content;
            attachments.addAll(user.attachments);
            try {
                commitConversation(conversation.withContent(conversation.messages,null,draft,encodeAttachments(attachments)));
            } catch (IOException | JSONException ignored) { /* The original pending turn is still on disk. */ }
        }
        sending = false;
        failure = error;
        renderHome();
    }

    private void showChatError(String error) {
        failure = error;
        if (errorLabel != null) {
            errorLabel.setText(error);
            errorLabel.setVisibility(error.isEmpty() ? View.GONE : View.VISIBLE);
        }
    }

    private void pickAttachment() {
        if (sending || importing || conversation == null) return;
        if (attachments.size() >= ChatExtras.MAX_ATTACHMENTS) {
            showChatError("每条消息最多添加 " + ChatExtras.MAX_ATTACHMENTS + " 个附件。");
            return;
        }
        openDocument(PICK_ATTACHMENT);
    }

    private void openDocument(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try {
            startActivityForResult(intent,requestCode);
        } catch (Exception error) {
            showChatError("无法打开文件选择器。");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode,resultCode,result);
        if (requestCode == EXPORT_ARTIFACT) {
            JSONObject artifact = pendingExport;
            pendingExport = null;
            if (resultCode == RESULT_OK && result != null && result.getData() != null && artifact != null) {
                writeArtifact(result.getData(),artifact.optString("text"));
            }
            return;
        }
        if (resultCode != RESULT_OK || result == null || result.getData() == null || conversation == null) return;
        if (requestCode == PICK_ATTACHMENT) importAttachment(result.getData());
        if (requestCode == PICK_SKILL) importSkill(result.getData());
    }

    private void importAttachment(Uri uri) {
        if (sending || importing) return;
        importing = true;
        updateSend();
        final String conversationId = conversation.id;
        executor.execute(() -> {
            ChatExtras.Attachment imported = null;
            try {
                imported = extras.importAttachment(uri);
                final ChatExtras.Attachment attachment = imported;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) {
                        removePrivateAttachment(attachment);
                        return;
                    }
                    importing = false;
                    long total = attachment.size;
                    for (ChatExtras.Attachment existing : attachments) total += existing.size;
                    if (!conversationId.equals(conversation.id) || attachments.size() >= ChatExtras.MAX_ATTACHMENTS
                            || total > ChatExtras.MAX_ATTACHMENT_TOTAL) {
                        removePrivateAttachment(attachment);
                        showChatError("每条消息最多 3 个附件，总大小不超过 4 MB。");
                        updateSend();
                        return;
                    }
                    rememberDraft();
                    attachments.add(attachment);
                    if (!saveDraft()) {
                        attachments.remove(attachment);
                        executor.execute(() -> removePrivateAttachment(attachment));
                        updateSend();
                        return;
                    }
                    renderHome();
                });
            } catch (Exception error) {
                if (imported != null) removePrivateAttachment(imported);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    importing = false;
                    showChatError(safeError(error,""));
                    updateSend();
                });
            }
        });
    }

    private void removeAttachment(ChatExtras.Attachment attachment) {
        if (sending || importing || conversation == null) return;
        rememberDraft();
        attachments.remove(attachment);
        if (!saveDraft()) {
            attachments.add(attachment);
            return;
        }
        if (!attachmentInPending(attachment)) executor.execute(() -> removePrivateAttachment(attachment));
        renderHome();
    }

    private boolean attachmentInPending(ChatExtras.Attachment attachment) {
        if (conversation.pending == null) return false;
        JSONArray values = conversation.pending.optJSONArray("attachments");
        if (values == null) return false;
        for (int i = 0; i < values.length(); i++) {
            JSONObject row = values.optJSONObject(i);
            if (row != null && attachment.id.equals(row.optString("id"))) return true;
        }
        return false;
    }

    private void removePrivateAttachment(ChatExtras.Attachment attachment) {
        try {
            extras.deleteAttachment(attachment);
        } catch (IOException ignored) { /* The private file remains available for later cleanup. */ }
    }

    private static List<ChatExtras.Attachment> conversationFiles(ChatHistory.Conversation value) {
        LinkedHashMap<String,ChatExtras.Attachment> files = new LinkedHashMap<>();
        addFiles(files,value.draftAttachments);
        if (value.pending != null) addFiles(files,value.pending.optJSONArray("attachments"));
        for (int i = 0; i < value.messages.length(); i++) {
            JSONObject message = value.messages.optJSONObject(i);
            if (message != null) addFiles(files,message.optJSONArray("attachments"));
        }
        return new ArrayList<>(files.values());
    }

    private static void addFiles(LinkedHashMap<String,ChatExtras.Attachment> files, JSONArray values) {
        if (values == null) return;
        for (int i = 0; i < values.length(); i++) {
            JSONObject item = values.optJSONObject(i);
            if (item == null) continue;
            try {
                ChatExtras.Attachment attachment = ChatExtras.Attachment.fromJson(item);
                files.put(attachment.id,attachment);
            } catch (JSONException ignored) { /* Ignore damaged metadata without touching other files. */ }
        }
    }

    private ChatExtras.Skill findSkill(String id) {
        if (empty(id)) return null;
        for (ChatExtras.Skill skill : getBuiltInSkills()) if (id.equals(skill.id)) return skill;
        try {
            for (ChatExtras.Skill skill : extras.loadSkills()) if (id.equals(skill.id)) return skill;
        } catch (IOException ignored) { /* Imported skills remain on disk if unavailable. */ }
        return null;
    }

    private List<ChatExtras.Skill> getBuiltInSkills() {
        if (builtInSkills == null) {
            try (InputStream input = getAssets().open("default-chat-skills.json")) {
                builtInSkills = ChatExtras.readBuiltInSkills(input);
            } catch (IOException error) { builtInSkills = Collections.emptyList(); }
        }
        return builtInSkills;
    }

    private void showSkills() {
        if (sending || importing || conversation == null) return;
        Dialog dialog = sheet("聊天技能");
        LinearLayout body = dialogBody(dialog);
        ScrollView scroll = new ScrollView(this);
        LinearLayout rows = column();
        scroll.addView(rows);
        body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView info = text("选择内置技能或导入 SKILL.md。发送时，星枢会把选中的技能说明交给当前模型。",13,muted,false);
        marginAdd(rows,info,4,6,4,10);
        settingsRow(rows,"不使用技能",selectedSkill==null?"当前选择":"",() -> {
            if (selectSkill(null)) dialog.dismiss();
        });
        List<ChatExtras.Skill> builtIn = getBuiltInSkills();
        if (!builtIn.isEmpty()) {
            section(rows,"内置技能");
            for (ChatExtras.Skill skill : builtIn) {
                boolean current = selectedSkill != null && selectedSkill.id.equals(skill.id);
                settingsRow(rows,skill.name,current?"当前选择":"选择用于本对话",() -> {
                    if (selectSkill(skill)) dialog.dismiss();
                });
            }
        }
        try {
            List<ChatExtras.Skill> imported = extras.loadSkills();
            if (!imported.isEmpty()) section(rows,"我的技能");
            for (ChatExtras.Skill skill : imported) {
                boolean current = selectedSkill != null && selectedSkill.id.equals(skill.id);
                settingsRow(rows,skill.name,current?"当前选择":"选择用于本对话",() -> {
                    if (selectSkill(skill)) dialog.dismiss();
                });
                Button delete = linkButton("删除");
                delete.setContentDescription("删除 Skill " + skill.name);
                delete.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("删除这个 Skill？")
                        .setMessage(skill.name).setNegativeButton("取消",null)
                        .setPositiveButton("删除",(confirm,which) -> {
                            try {
                                if (current && !selectSkill(null)) return;
                                extras.deleteSkill(skill);
                                dialog.dismiss();
                                showSkills();
                            } catch (IOException error) {
                                Toast.makeText(this,"无法删除这个 Skill。",Toast.LENGTH_SHORT).show();
                            }
                        }).show());
                rows.addView(delete,lp(-2,44));
            }
        } catch (IOException error) {
            marginAdd(rows,text("无法读取本地 Skill",13,danger,false),4,8,4,8);
        }
        Button upload = primaryButton("导入 SKILL.md");
        upload.setOnClickListener(v -> { dialog.dismiss(); openDocument(PICK_SKILL); });
        body.addView(upload,lp(-1,52));
        dialog.show();
        sizeSheet(dialog);
    }

    private boolean selectSkill(ChatExtras.Skill skill) {
        rememberDraft();
        try {
            commitConversation(conversation.withSkill(skill == null ? "" : skill.id));
        } catch (IOException error) {
            Toast.makeText(this,"无法保存这个选择。",Toast.LENGTH_SHORT).show();
            return false;
        }
        selectedSkill = skill;
        renderHome();
        return true;
    }

    private void importSkill(Uri uri) {
        if (sending || importing) return;
        importing = true;
        updateSend();
        executor.execute(() -> {
            try {
                extras.importSkill(uri);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    importing = false;
                    updateSend();
                    showSkills();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    importing = false;
                    showChatError(safeError(error,""));
                    updateSend();
                });
            }
        });
    }

    private void addArtifactButtons(LinearLayout holder, JSONObject row) {
        JSONArray artifacts = row == null ? null : row.optJSONArray("artifacts");
        if (artifacts == null) return;
        for (int i = 0; i < artifacts.length(); i++) {
            JSONObject artifact = artifacts.optJSONObject(i);
            if (artifact == null) continue;
            Button button = linkButton("保存 " + artifact.optString("name"));
            button.setSingleLine();
            button.setEllipsize(TextUtils.TruncateAt.END);
            button.setOnClickListener(v -> {
                pendingExport = artifact;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(artifact.optString("mimeType","text/plain"));
                intent.putExtra(Intent.EXTRA_TITLE,artifact.optString("name","StarHub.txt"));
                try {
                    startActivityForResult(intent,EXPORT_ARTIFACT);
                } catch (Exception error) {
                    pendingExport = null;
                    showChatError("无法打开文件保存位置。");
                }
            });
            holder.addView(button,lp(-1,44));
        }
    }

    private void writeArtifact(Uri uri, String text) {
        executor.execute(() -> {
            try (OutputStream output = getContentResolver().openOutputStream(uri,"wt")) {
                if (output == null) throw new IOException("无法写入文件。");
                output.write(text.getBytes(StandardCharsets.UTF_8));
                output.flush();
                runOnUiThread(() -> Toast.makeText(this,"文件已保存",Toast.LENGTH_SHORT).show());
            } catch (IOException error) {
                runOnUiThread(() -> showChatError("无法保存这个文件。"));
            }
        });
    }

    private void showModelDropdown(View anchor) {
        ModelStore.Model selected = activeModel();
        ArrayList<ModelStore.Model> configured = new ArrayList<>(store.getCustomModels());
        if (selected != null && !containsID(configured, selected.id)) configured.add(0, selected);
        ArrayList<String> labels = new ArrayList<>();
        for (ModelStore.Model model : configured) labels.add(model.name);
        labels.add("浏览和添加模型");

        ListPopupWindow dropdown = new ListPopupWindow(this);
        dropdown.setAnchorView(anchor);
        dropdown.setWidth(anchor.getWidth());
        dropdown.setModal(true);
        dropdown.setInputMethodMode(ListPopupWindow.INPUT_METHOD_NOT_NEEDED);
        dropdown.setBackgroundDrawable(shape(surface,14,line));
        dropdown.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            @Override public View getView(int position, View recycled, ViewGroup parent) {
                LinearLayout entry = row();
                entry.setMinimumHeight(dp(48));
                entry.setPadding(dp(12),0,dp(12),0);
                String label = getItem(position);
                boolean isModel = position < configured.size();
                TextView title = text(label,14,isModel ? ink : accent,false);
                title.setSingleLine();
                title.setEllipsize(TextUtils.TruncateAt.END);
                entry.addView(title,new LinearLayout.LayoutParams(0,-2,1));
                if (isModel && selected != null && selected.id.equals(configured.get(position).id)) {
                    entry.addView(text("✓",16,accent,true),lp(20,28));
                    entry.setContentDescription(label + "，当前模型");
                }
                return entry;
            }
        });
        dropdown.setOnItemClickListener((parent, view, position, id) -> {
            dropdown.dismiss();
            if (position == configured.size()) {
                showModels(3);
                return;
            }
            selectModel(configured.get(position));
        });
        dropdown.show();
    }

    private void showModels(int initialFilter) {
        rememberDraft(); Dialog dialog=sheet("选择模型"); LinearLayout body=dialogBody(dialog); EditText query=input("搜索供应商、网址或模型 ID",false); marginAdd(body,query,0,0,0,12);
        LinearLayout tabs=row(); String[] names={"全部","我的","免费","供应商"}; final int[] filter={initialFilter}; Button[] buttons=new Button[4];
        for(int i=0;i<4;i++){ final int value=i; Button b=linkButton(names[i]); buttons[i]=b; tabs.addView(b,new LinearLayout.LayoutParams(0,dp(44),1)); b.setOnClickListener(v->{filter[0]=value;renderModelList(dialog,query,filter[0],buttons);}); } body.addView(tabs);
        ScrollView scroll=new ScrollView(this); LinearLayout results=column(); results.setTag("model-results"); scroll.addView(results); body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button add=primaryButton("添加自定义模型"); add.setOnClickListener(v->showEditor(null,()->renderModelList(dialog,query,filter[0],buttons))); marginAdd(body,add,0,12,0,0);
        Button refresh=linkButton(refreshing?"正在刷新…":"刷新免费模型目录"); refresh.setOnClickListener(v->refresh(true,true,()->renderModelList(dialog,query,filter[0],buttons))); body.addView(refresh,lp(-1,44));
        Button official=linkButton("官方账号与文档");
        official.setOnClickListener(v->showOfficialLinks());
        body.addView(official,lp(-1,44));
        query.addTextChangedListener(watcher(()->renderModelList(dialog,query,filter[0],buttons)));
        Runnable catalogChanged=()->{if(dialog.isShowing()&&filter[0]==3)renderModelList(dialog,query,filter[0],buttons);};cloudObservers.add(catalogChanged);dialog.setOnDismissListener(d->cloudObservers.remove(catalogChanged));
        dialog.show(); sizeSheet(dialog); renderModelList(dialog,query,filter[0],buttons);
    }

    private void renderModelList(Dialog dialog,EditText query,int filter,Button[] tabs) {
        LinearLayout results=(LinearLayout)dialog.findViewById(android.R.id.content).findViewWithTag("model-results"); if(results==null)return; results.removeAllViews();
        for(int i=0;i<tabs.length;i++){tabs[i].setBackground(shape(i==filter?soft:Color.TRANSPARENT,12,Color.TRANSPARENT));tabs[i].setTextColor(i==filter?accent:muted);}
        String search=query.getText().toString().trim().toLowerCase(Locale.ROOT);
        if (filter == 3) { renderSuppliers(results, search, () -> renderModelList(dialog, query, filter, tabs)); return; }
        List<ModelStore.Model> list=filter==1?store.getCustomModels():filter==2?store.getFreeModels():store.getAllModels(); int count=0;
        for(ModelStore.Model model:list) {
            if(!search.isEmpty()&&!(str(model.name)+" "+str(model.modelID)+" "+str(model.provider)).toLowerCase(Locale.ROOT).contains(search))continue; count++;
            ModelStore.Model selected=activeModel();
            boolean isSelected=selected!=null&&model.id.equals(selected.id);
            LinearLayout entry=row(); entry.setPadding(dp(12),dp(11),dp(4),dp(11)); entry.setBackground(shape(isSelected?soft:surface,16,Color.TRANSPARENT));
            LinearLayout choice=row(); choice.addView(logo(model,30),lp(36,42)); LinearLayout words=column(); words.setPadding(dp(10),0,dp(5),0); TextView title=text(model.name,16,ink,true);title.setMaxLines(1);title.setEllipsize(TextUtils.TruncateAt.END);words.addView(title);
            String detail=str(model.modelID);
            if(model.freeCatalog) {
                detail="OpenRouter · 目录标价为零";
            }
            TextView subtitle=text(detail,11,muted,false);subtitle.setMaxLines(1);subtitle.setEllipsize(TextUtils.TruncateAt.END);marginAdd(words,subtitle,0,5,0,0);choice.addView(words,new LinearLayout.LayoutParams(0,-2,1));
            if(isSelected){TextView check=text("✓",17,accent,true);choice.addView(check,lp(22,30));choice.setContentDescription(model.name+"，当前模型");}
            choice.setOnClickListener(v->{dialog.dismiss();selectModel(model);});entry.addView(choice,new LinearLayout.LayoutParams(0,dp(48),1));
            Button configure=linkButton(model.freeCatalog?"Key":"设置");configure.setTextSize(12);configure.setOnClickListener(v->{if(model.freeCatalog){showOpenRouterKey();}else{showEditor(new ModelStore.Model(model),()->renderModelList(dialog,query,filter,tabs));}});entry.addView(configure,lp(50,44));marginAdd(results,entry,0,7,0,0);
        }
        if(count==0){TextView empty=text(search.isEmpty()?(filter==2?"尚未获取免费目录":"这里还没有模型"):"没有找到模型",17,ink,true);marginAdd(results,empty,8,30,8,9);TextView help=text(search.isEmpty()?"添加自己的 API，或刷新免费模型目录。":"试试其他名称或模型 ID。",13,muted,false);marginAdd(results,help,8,0,8,20);}
    }

    private List<SupplierDirectory.Entry> getSupplierGroups() {
        if (bundledSuppliers == null) {
            try (InputStream input = getAssets().open(SupplierDirectory.ASSET)) {
                bundledSuppliers = SupplierDirectory.read(input);
            } catch (IOException | JSONException error) { bundledSuppliers = Collections.emptyList(); }
        }
        return SupplierDirectory.grouped(bundledSuppliers, store.getPresets());
    }

    private String supplierCategory(String category) {
        switch (category) {
            case "account": return "账号登录";
            case "official": return "模型厂商";
            case "cloud": return "云服务商";
            case "local": return "本地";
            case "unified": return "统一供应商";
            default: return "第三方平台";
        }
    }

    private void renderSuppliers(LinearLayout results, String search, Runnable onChanged) {
        List<SupplierDirectory.Entry> entries = getSupplierGroups();
        LinkedHashMap<String,ArrayList<SupplierDirectory.Entry>> groups = new LinkedHashMap<>();
        for (String key : new String[]{"official","cloud","account","third-party","local","unified"}) groups.put(key,new ArrayList<>());
        int visible = 0;
        for (SupplierDirectory.Entry entry : entries) {
            if (!entry.matches(search)) continue;
            groups.get(groups.containsKey(entry.category) ? entry.category : "third-party").add(entry);
            visible++;
        }
        TextView summary = text("显示 " + visible + " / " + entries.size() + " 家供应商。点供应商查看模型、官网或手动配置。",12,muted,false);
        marginAdd(results,summary,4,12,4,10);
        if (visible == 0) {
            marginAdd(results,text("没有找到供应商或模型。",15,muted,false),4,14,4,14);
            return;
        }
        for (String category : groups.keySet()) {
            List<SupplierDirectory.Entry> group = groups.get(category);
            if (group.isEmpty()) continue;
            section(results,supplierCategory(category) + " · " + group.size());
            for (SupplierDirectory.Entry entry : group) {
                String detail = !entry.models.isEmpty() ? entry.models.size() + " 个模型预设"
                        : entry.website.isEmpty() ? "手动配置" : "网站入口 · 未预填 API";
                settingsRow(results,entry.name,detail,() -> showSupplierDetails(entry,onChanged));
            }
        }
    }

    private void showSupplierDetails(SupplierDirectory.Entry entry, Runnable onChanged) {
        Dialog dialog = sheet(entry.name);
        LinearLayout body = dialogBody(dialog);
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = column();
        scroll.addView(content);
        body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if (!entry.models.isEmpty()) {
            section(content,"选择模型");
            for (ModelStore.Model model : entry.models) {
                String host = java.net.URI.create(model.baseURL).getHost();
                String detail = model.modelID + " · " + host + " · 需个人 Key";
                if ("domestic-free".equals(model.category)) detail += " · 免费预设";
                settingsRow(content,model.name,detail,() -> {
                    ModelStore.Model copy = new ModelStore.Model(model);
                    copy.id = UUID.randomUUID().toString();
                    showEditor(copy,onChanged);
                });
            }
        } else {
            marginAdd(content,text("暂未提供此供应商的预填模型。请以该服务商公开文档为准，使用其支持的接口和模型 ID。",13,muted,false),4,10,4,12);
        }
        if (!entry.website.isEmpty()) {
            settingsRow(content,"打开供应商网站",entry.website,() -> openOfficial(entry.website));
        }
        settingsRow(content,"手动添加模型","填写你自己的接口地址、模型 ID 和 Key",() -> {
            ModelStore.Model custom = new ModelStore.Model();
            custom.provider = entry.name;
            showEditor(custom,onChanged);
        });
        dialog.show();
        sizeSheet(dialog);
    }

    private void showEditor(ModelStore.Model existing,Runnable onSaved) {
        boolean actuallyStored=existing!=null&&containsID(store.getCustomModels(),existing.id); ModelStore.Model model=existing==null?new ModelStore.Model():new ModelStore.Model(existing); model.freeCatalog=false;
        String initialSecret=actuallyStored?store.getKey(model):"";
        Dialog dialog=sheet(actuallyStored?"编辑模型":"添加模型"); LinearLayout body=dialogBody(dialog); ScrollView scroll=new ScrollView(this); LinearLayout form=column(); scroll.addView(form); body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout hero=row();hero.setPadding(dp(4),dp(8),dp(4),dp(18));LogoView brand=logo(model,42);hero.addView(brand,lp(52,52));LinearLayout heading=column();heading.setPadding(dp(12),0,0,0);TextView heroName=text(empty(model.name)?"自定义模型":model.name,21,ink,true);heading.addView(heroName);marginAdd(heading,text("连接自己的模型服务",12,muted,false),0,5,0,0);hero.addView(heading,new LinearLayout.LayoutParams(0,-2,1));form.addView(hero);
        EditText name=labelInput(form,"显示名称",str(model.name),"例如：我的通义千问",false); EditText id=labelInput(form,"模型 ID",str(model.modelID),"服务商提供的准确模型 ID",false);
        Spinner protocol=spinner(form,"接口协议",new String[]{"OpenAI 兼容","Anthropic Messages","Google Gemini"},new String[]{"openAI","anthropic","gemini"},str(model.protocol));
        EditText url=labelInput(form,"接口地址",str(model.baseURL),"https://…",false);url.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        TextView help=text("接口地址和模型需符合所选协议。远程使用 HTTPS，本机服务可用 HTTP 回环地址。",12,muted,false);help.setLineSpacing(dp(3),1);marginAdd(form,help,3,7,3,8);
        EditText key=labelInput(form,"API Key",initialSecret,"按服务商要求填写",true);CheckBox reveal=new CheckBox(this);reveal.setText("显示密钥");reveal.setTextColor(muted);reveal.setTextSize(12);reveal.setButtonTintList(android.content.res.ColorStateList.valueOf(accent));reveal.setOnCheckedChangeListener((button,visible)->{int selection=key.getSelectionStart();key.setInputType(InputType.TYPE_CLASS_TEXT|(visible?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));key.setTypeface(Typeface.DEFAULT);key.setSelection(Math.min(Math.max(selection,0),key.length()));});form.addView(reveal);
        Spinner logo=spinner(form,"模型标识",new String[]{"自动识别","OpenAI","Claude","Gemini","DeepSeek","通义千问","智谱 GLM","Kimi","文心","星枢"},new String[]{"automatic","openai","anthropic","google","deepseek","qwen","glm","kimi","baidu","custom"},str(model.logo));
        Runnable preview=()->{model.name=name.getText().toString();model.modelID=id.getText().toString();model.logo=(String)logo.getSelectedItem();brand.brand(model.resolvedLogo());heroName.setText(empty(model.name)?"自定义模型":model.name);};name.addTextChangedListener(watcher(preview));id.addTextChangedListener(watcher(preview));logo.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>parent,View view,int position,long itemId){preview.run();}public void onNothingSelected(android.widget.AdapterView<?>parent){}});
        if(!empty(model.note)){TextView note=text(model.note,12,muted,false);note.setLineSpacing(dp(3),1);marginAdd(form,note,3,12,3,8);}
        TextView privacy=text("密钥由 Android Keystore 加密保存在此设备。免费预设不等于无需鉴权；用户免填 Key 需要开发者授权的服务通道。",12,muted,false);privacy.setLineSpacing(dp(3),1);marginAdd(form,privacy,3,12,3,12);
        TextView error=text("",13,danger,false);error.setVisibility(View.GONE);form.addView(error);
        if(actuallyStored){Button remove=linkButton("删除模型");remove.setTextColor(danger);remove.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("删除这个模型？").setMessage(model.name).setNegativeButton("取消",null).setPositiveButton("删除",(d,which)->{try{store.delete(model);dialog.dismiss();rememberDraft();renderHome();if(onSaved!=null)onSaved.run();}catch(Exception ex){error.setText(safeError(ex,key.getText().toString()));error.setVisibility(View.VISIBLE);}}).show());form.addView(remove,lp(-1,44));}
        final String baseline=editorSnapshot(name,id,url,key,protocol,logo);
        Runnable close=()->{if(!baseline.equals(editorSnapshot(name,id,url,key,protocol,logo)))new AlertDialog.Builder(this).setTitle("放弃未保存的更改？").setNegativeButton("保留编辑",null).setPositiveButton("放弃更改",(d,which)->dialog.dismiss()).show();else dialog.dismiss();};setCloseAction(dialog,close);dialog.setCancelable(false);dialog.setOnKeyListener((d,keyCode,event)->{if(keyCode==android.view.KeyEvent.KEYCODE_BACK&&event.getAction()==android.view.KeyEvent.ACTION_UP){close.run();return true;}return false;});dialog.setCanceledOnTouchOutside(false);
        Button save=primaryButton("保存模型");save.setOnClickListener(v->{model.name=name.getText().toString().trim();model.modelID=id.getText().toString().trim();model.baseURL=url.getText().toString().trim();model.protocol=selectedValue(protocol);model.logo=selectedValue(logo);model.category="custom";try{store.save(model,key.getText().toString());dialog.dismiss();selectModel(model);if(onSaved!=null)onSaved.run();}catch(Exception ex){error.setText(safeError(ex,key.getText().toString()));error.setVisibility(View.VISIBLE);scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));}});marginAdd(body,save,0,12,0,0);dialog.show();sizeSheet(dialog);
    }

    private void showSettings() {
        rememberDraft();Dialog dialog=sheet("星枢 设置");LinearLayout body=dialogBody(dialog);ScrollView scroll=new ScrollView(this);LinearLayout list=column();scroll.addView(list);body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        section(list,"模型与服务");
        settingsRow(list,"模型与 API 配置","管理已配置模型",()->showModels(1));
        settingsRow(list,"推荐服务商与模型","预填 API 地址与模型信息",()->showModels(3));
        settingsRow(list,"官方账号与文档","打开服务商网页或查看官方文档",this::showOfficialLinks);
        settingsRow(list,"OpenRouter Key","免费目录使用你自己的 Key",this::showOpenRouterKey);
        section(list,"外观");String theme=store.getTheme();settingsRow(list,"主题","dark".equals(theme)?"深色":"light".equals(theme)?"浅色":"跟随系统",()->new AlertDialog.Builder(this).setTitle("外观").setSingleChoiceItems(new String[]{"跟随系统","浅色","深色"},"dark".equals(theme)?2:"light".equals(theme)?1:0,(choice,which)->{store.setTheme(new String[]{"system","light","dark"}[which]);choice.dismiss();dialog.dismiss();rememberDraft();renderHome();showSettings();}).setNegativeButton("取消",null).show());
        addCloudSettings(list,dialog);
        section(list,"免费模型目录");CheckBox auto=new CheckBox(this);auto.setText("每天自动更新");auto.setTextColor(ink);auto.setTextSize(15);auto.setChecked(store.isAutoRefresh());auto.setPadding(dp(8),dp(8),dp(8),dp(8));auto.setButtonTintList(android.content.res.ColorStateList.valueOf(accent));auto.setOnCheckedChangeListener((button,checked)->{store.setAutoRefresh(checked);if(checked)RefreshJobService.schedule(this);else RefreshJobService.cancel(this);});list.addView(auto,lp(-1,52));
        String updated=store.getLastRefresh()==0?"尚未获取":DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(store.getLastRefresh()));settingsRow(list,"最近更新",updated,()->refresh(true,true,()->{dialog.dismiss();showSettings();}));settingsRow(list,"立即刷新",refreshing?"正在更新":"从 OpenRouter 获取当前免费目录",()->refresh(true,true,()->{dialog.dismiss();showSettings();}));
        TextView note=text("目录每隔 24 小时检查，并在回到 App 时补刷新。后台调度由 Android 系统决定，不保证固定时刻执行。免费额度、价格与可用性以服务商为准。",12,muted,false);note.setLineSpacing(dp(3),1);marginAdd(list,note,10,12,10,12);
        if(!empty(store.getDiscoveryError())){TextView error=text(store.getDiscoveryError(),12,danger,false);error.setTextIsSelectable(true);marginAdd(list,error,10,0,10,14);}
        section(list,"开发者");settingsRow(list,"关于 星枢","GUJIU · 开发者与联系",this::showAbout);dialog.show();sizeSheet(dialog);
    }

    private void addCloudSettings(LinearLayout list,Dialog dialog) {
        section(list,"云端推荐与公告");
        CheckBox auto=new CheckBox(this);auto.setText("自动同步推荐与公告");auto.setTextColor(ink);auto.setTextSize(15);auto.setChecked(store.isCloudAutoSync());auto.setPadding(dp(8),dp(8),dp(8),dp(8));auto.setButtonTintList(android.content.res.ColorStateList.valueOf(accent));list.addView(auto,lp(-1,52));
        auto.setOnCheckedChangeListener((button,checked)->{store.setCloudAutoSync(checked);if(checked)syncCloud(false,false);});
        TextView status=text("",12,muted,false);status.setTextIsSelectable(true);status.setLineSpacing(dp(3),1);marginAdd(list,status,10,8,10,8);
        TextView announcement=text("",14,ink,false);announcement.setTextIsSelectable(true);announcement.setLineSpacing(dp(4),1);marginAdd(list,announcement,10,6,10,8);
        Button manual=linkButton("立即同步推荐与公告");manual.setOnClickListener(v->syncCloud(true,true));list.addView(manual,lp(-1,48));
        Button release=linkButton("查看最新版本");release.setOnClickListener(v->openOfficial(CloudCatalog.RELEASE_URL));list.addView(release,lp(-1,48));
        TextView note=text("打开或回到 App 时检查，成功后 1 小时内不重复自动获取。仅更新推荐与公告；添加模型仍需你确认并配置自己的 Key。此开关与下方 OpenRouter 每日目录独立。",12,muted,false);note.setLineSpacing(dp(3),1);marginAdd(list,note,10,6,10,8);
        Runnable update=()->{
            boolean busy=cloudSyncQueued||store.isCloudRefreshing();String error=store.getCloudError();long last=store.getCloudLastSuccess();
            String detail=last==0?"当前使用内置推荐，尚未成功同步。":"上次同步："+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(last))+" · 修订 "+store.getCloudRevision();
            status.setText((busy?"正在同步…\n":"")+detail+(empty(error)?"":"\n"+error));status.setTextColor(empty(error)?muted:danger);
            String message=store.getCloudAnnouncement();announcement.setText(empty(message)?"暂无云端公告。":"公告\n"+message);
            manual.setEnabled(!busy);manual.setText(busy?"正在同步…":"立即同步推荐与公告");
            String latest=store.getCloudLatestVersion();String current=installedVersion();boolean newer=!empty(latest)&&CloudCatalog.compareVersions(latest,current)>0;
            release.setText(empty(latest)?"当前 "+current+" · 查看发布页":(newer?"发现新版本 ":"云端版本 ")+latest+" · 当前 "+current+" · 查看发布页");
        };
        cloudObservers.add(update);dialog.setOnDismissListener(d->cloudObservers.remove(update));update.run();
    }

    private String installedVersion() {
        try { String version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;CloudCatalog.compareVersions(version,"0.0.0");return version; }
        catch(Exception ignored) { return "1.2.2"; }
    }

    private void notifyCloudObservers() { for(Runnable observer:new ArrayList<>(cloudObservers))observer.run(); }

    private void syncCloud(boolean force,boolean visible) {
        if(isFinishing()||isDestroyed()||cloudSyncQueued)return;
        if(!force&&!CloudCatalog.shouldRefresh(store.isCloudAutoSync(),store.getCloudLastSuccess(),System.currentTimeMillis()))return;
        cloudSyncQueued=true;notifyCloudObservers();
        CLOUD_EXECUTOR.execute(()->{
            Exception failure=null;boolean changed=false;
            try { changed=store.refreshCloudCatalog(force); } catch(Exception error) { failure=error; }
            final Exception result=failure;final boolean updated=changed;
            runOnUiThread(()->{cloudSyncQueued=false;if(isFinishing()||isDestroyed())return;notifyCloudObservers();if(visible)Toast.makeText(this,result!=null?"同步失败，保留上次有效推荐":updated?"推荐与公告已同步":"目录正在同步或已是最新",Toast.LENGTH_SHORT).show();});
        });
    }

    private void showOpenRouterKey() {
        Dialog dialog=sheet("OpenRouter Key");LinearLayout body=dialogBody(dialog);String initial=store.getOpenRouterKey();TextView note=text("免费模型仍需要自己的 OpenRouter Key。仅同步目录不需要 Key；密钥保存在本机加密存储。",14,muted,false);note.setLineSpacing(dp(4),1);marginAdd(body,note,2,8,2,16);EditText key=labelInput(body,"API Key",initial,"输入 OpenRouter API Key",true);TextView error=text("",13,danger,false);body.addView(error);body.addView(new View(this),new LinearLayout.LayoutParams(1,0,1));
        Runnable close=()->{if(!initial.equals(key.getText().toString()))new AlertDialog.Builder(this).setTitle("放弃未保存的密钥更改？").setNegativeButton("保留编辑",null).setPositiveButton("放弃更改",(d,which)->dialog.dismiss()).show();else dialog.dismiss();};setCloseAction(dialog,close);dialog.setCancelable(false);dialog.setCanceledOnTouchOutside(false);dialog.setOnKeyListener((d,code,event)->{if(code==android.view.KeyEvent.KEYCODE_BACK&&event.getAction()==android.view.KeyEvent.ACTION_UP){close.run();return true;}return false;});
        Button save=primaryButton("保存 Key");save.setOnClickListener(v->{try{store.setOpenRouterKey(key.getText().toString());dialog.dismiss();Toast.makeText(this,key.getText().toString().trim().isEmpty()?"Key 已清除":"Key 已保存在此设备",Toast.LENGTH_SHORT).show();}catch(Exception ex){error.setText(safeError(ex,key.getText().toString()));}});marginAdd(body,save,0,18,0,0);dialog.show();sizeSheet(dialog);
    }

    private void showOfficialLinks() {
        Dialog dialog=sheet("官方账号与文档");
        LinearLayout body=dialogBody(dialog);
        ScrollView scroll=new ScrollView(this);
        LinearLayout links=column();
        scroll.addView(links);
        body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        TextView explanation=text("链接会在星枢外打开。部分网页需要登录服务商账号，网页账号与星枢的 API 配置独立。",13,muted,false);
        explanation.setLineSpacing(dp(4),1);
        marginAdd(links,explanation,4,8,4,12);
        settingsRow(links,"GitHub Copilot","GitHub 官方网页",()->openOfficial("https://github.com/copilot"));
        settingsRow(links,"OpenAI 官方 · Codex","Codex 官方网页",()->openOfficial("https://chatgpt.com/codex"));
        settingsRow(links,"xAI · Grok","Grok 官方网页",()->openOfficial("https://grok.com/"));
        settingsRow(links,"Astron Coding Plan","科大讯飞官方文档 · 面向编程工具",()->openOfficial("https://www.xfyun.cn/doc/spark/CodingPlan.html"));
        settingsRow(links,"DeepSeek","官方网页",()->openOfficial("https://chat.deepseek.com/"));
        settingsRow(links,"千问","官方网页",()->openOfficial("https://www.qianwen.com/"));
        settingsRow(links,"智谱清言","官方网页",()->openOfficial("https://chatglm.cn/"));
        dialog.show();
        sizeSheet(dialog);
    }

    private void openOfficial(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); }
        catch(Exception error) { Toast.makeText(this,"未找到可打开官方网页的浏览器",Toast.LENGTH_LONG).show(); }
    }

    private void showAbout() {
        Dialog dialog=sheet("关于 星枢");LinearLayout body=dialogBody(dialog);ScrollView scroll=new ScrollView(this);LinearLayout list=column();scroll.addView(list);body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout hero=column();hero.setGravity(Gravity.CENTER);hero.setPadding(0,dp(15),0,dp(25));LogoView appLogo=new LogoView(this).brand("custom").palette(ink,accent);hero.addView(appLogo,lp(82,82));TextView brand=text("星枢 StarHub",25,ink,true);brand.setGravity(Gravity.CENTER);brand.setLetterSpacing(.1f);marginAdd(hero,brand,0,14,0,4);hero.addView(text("AI 模型，随心连接",13,muted,false));list.addView(hero);
        LinearLayout developer=row();developer.setPadding(dp(16),dp(16),dp(16),dp(16));developer.setBackground(shape(surface,20,line));TextView avatar=text("GJ",23,Color.WHITE,true);avatar.setGravity(Gravity.CENTER);GradientDrawable avatarBg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff34345f,0xff7678be});avatarBg.setCornerRadius(dp(20));avatar.setBackground(avatarBg);avatar.setContentDescription("GUJIU 开发者头像");developer.addView(avatar,lp(65,65));LinearLayout bio=column();bio.setPadding(dp(15),0,0,0);bio.addView(text("GUJIU",21,ink,true));marginAdd(bio,text("星枢 开发者",12,muted,false),0,5,0,0);developer.addView(bio);list.addView(developer);
        section(list,"联系方式");contact(list,"邮箱","gujiu520@proton.me",true);contact(list,"QQ","401738182",false);contact(list,"微信","V909800",false);TextView privacy=text("自定义模型按所选服务商的规则调用。免费目录不提供共享密钥，也不代表无限免费使用。",12,muted,false);privacy.setLineSpacing(dp(3),1);marginAdd(list,privacy,8,20,8,10);dialog.show();sizeSheet(dialog);
    }

    private void refresh(boolean force,boolean visible,Runnable completion) {
        if(refreshing)return;if(!force&&!store.isAutoRefresh())return;refreshing=true;
        executor.execute(()->{Exception failure=null;try{store.refreshFreeModels(force);}catch(Exception error){failure=error;}Exception result=failure;runOnUiThread(()->{refreshing=false;if(isFinishing()||isDestroyed())return;if(visible)Toast.makeText(this,result==null?"免费目录已更新":"目录更新失败，保留上次缓存",Toast.LENGTH_SHORT).show();rememberDraft();renderHome();if(completion!=null)completion.run();});});
    }

    private Dialog sheet(String title) {
        Dialog dialog=new Dialog(this);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);LinearLayout shell=column();shell.setPadding(dp(18),dp(10),dp(18),dp(18));shell.setBackground(shape(bg,27,Color.TRANSPARENT));LinearLayout header=row();TextView heading=text(title,19,ink,true);header.addView(heading,new LinearLayout.LayoutParams(0,dp(48),1));Button close=iconButton("×","关闭");close.setTag("sheet-close");close.setOnClickListener(v->dialog.dismiss());header.addView(close,lp(44,44));shell.addView(header);LinearLayout body=column();body.setTag("sheet-body");shell.addView(body,new LinearLayout.LayoutParams(-1,0,1));dialog.setContentView(shell);dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);return dialog;
    }
    private LinearLayout dialogBody(Dialog dialog){return (LinearLayout)dialog.findViewById(android.R.id.content).findViewWithTag("sheet-body");}
    private void setCloseAction(Dialog dialog,Runnable close){View button=dialog.findViewById(android.R.id.content).findViewWithTag("sheet-close");button.setOnClickListener(v->close.run());}
    private void sizeSheet(Dialog dialog){Window w=dialog.getWindow();if(w!=null){w.setGravity(Gravity.BOTTOM);w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,(int)(getResources().getDisplayMetrics().heightPixels*.88));}}
    private LinearLayout column(){LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);return view;}
    private LinearLayout row(){LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.HORIZONTAL);view.setGravity(Gravity.CENTER_VERTICAL);return view;}
    private TextView text(String value,float sp,int color,boolean bold){TextView view=new TextView(this);view.setText(str(value));view.setTextSize(sp);view.setTextColor(color);view.setGravity(Gravity.CENTER_VERTICAL);if(bold)view.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return view;}
    private Button linkButton(String title){Button button=new Button(this);button.setAllCaps(false);button.setText(title);button.setTextColor(accent);button.setTextSize(14);button.setPadding(dp(10),0,dp(10),0);button.setMinWidth(0);button.setMinimumWidth(0);button.setMinHeight(dp(44));button.setBackground(shape(Color.TRANSPARENT,12,Color.TRANSPARENT));return button;}
    private Button iconButton(String title,String label){Button button=linkButton(title);button.setTextSize(22);button.setTextColor(ink);button.setPadding(0,0,0,0);button.setContentDescription(label);button.setBackground(shape(surface,23,line));return button;}
    private Button primaryButton(String title){Button button=linkButton(title);button.setTextSize(16);button.setTypeface(Typeface.DEFAULT,Typeface.BOLD);button.setTextColor(onAccent);button.setMinHeight(dp(52));button.setBackground(shape(accent,17,Color.TRANSPARENT));return button;}
    private GradientDrawable shape(int color,int radius,int border){GradientDrawable shape=new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(radius));if(border!=Color.TRANSPARENT)shape.setStroke(dp(1),border);return shape;}
    private EditText input(String hint,boolean secret){EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(16);input.setTextColor(ink);input.setHintTextColor(muted);input.setHint(hint);input.setPadding(dp(13),dp(12),dp(13),dp(12));input.setBackground(shape(surface,13,line));input.setInputType(InputType.TYPE_CLASS_TEXT|(secret?InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS));input.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);return input;}
    private EditText labelInput(LinearLayout target,String label,String value,String hint,boolean secret){TextView caption=text(label,12,muted,true);marginAdd(target,caption,3,14,3,8);EditText field=input(hint,secret);field.setText(value);target.addView(field,lp(-1,52));return field;}
    private Spinner spinner(LinearLayout target,String label,String[] labels,String[] values,String selected){marginAdd(target,text(label,12,muted,true),3,17,3,8);Spinner spinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){@Override public View getView(int position,View convert,ViewGroup parent){TextView v=(TextView)super.getView(position,convert,parent);v.setText(labels[position]);v.setTextColor(ink);v.setTextSize(15);return v;}@Override public View getDropDownView(int position,View convert,ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convert,parent);v.setText(labels[position]);v.setTextSize(15);v.setTextColor(ink);v.setBackgroundColor(surface);v.setPadding(dp(15),dp(15),dp(15),dp(15));return v;}};adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(adapter);spinner.setBackground(shape(surface,13,line));for(int i=0;i<values.length;i++)if(values[i].equals(selected)){spinner.setSelection(i);break;}target.addView(spinner,lp(-1,52));return spinner;}
    private String selectedValue(Spinner spinner){Object item=spinner.getSelectedItem();return item==null?"":item.toString();}
    private String editorSnapshot(EditText name,EditText id,EditText url,EditText key,Spinner protocol,Spinner logo){return name.getText()+"\n"+id.getText()+"\n"+url.getText()+"\n"+key.getText()+"\n"+selectedValue(protocol)+"\n"+selectedValue(logo);}
    private void settingsRow(LinearLayout target,String title,String detail,Runnable action){LinearLayout row=row();row.setPadding(dp(11),dp(12),dp(11),dp(12));row.setBackground(shape(surface,16,Color.TRANSPARENT));LinearLayout copy=column();copy.addView(text(title,15,ink,false));if(!empty(detail))marginAdd(copy,text(detail,11,muted,false),0,5,0,0);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(text("›",23,muted,false),lp(16,30));row.setOnClickListener(v->action.run());marginAdd(target,row,0,5,0,0);}
    private void section(LinearLayout target,String title){marginAdd(target,text(title,12,muted,true),10,22,10,8);}
    private void contact(LinearLayout target,String label,String value,boolean email){LinearLayout row=row();row.setPadding(dp(11),dp(9),dp(4),dp(9));row.setBackground(shape(surface,16,Color.TRANSPARENT));row.addView(text(label,12,muted,false),lp(43,44));TextView content=text(value,email?13:15,ink,false);content.setTextIsSelectable(true);content.setMaxLines(2);if(email)content.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+value)));}catch(Exception ignored){copy(value,label);}});row.addView(content,new LinearLayout.LayoutParams(0,-2,1));Button copy=linkButton("复制");copy.setTextSize(12);copy.setOnClickListener(v->copy(value,label));row.addView(copy,lp(52,44));marginAdd(target,row,0,5,0,0);}
    private void copy(String value,String label){ClipboardManager manager=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(manager!=null){manager.setPrimaryClip(ClipData.newPlainText(label,value));Toast.makeText(this,"已复制"+label,Toast.LENGTH_SHORT).show();}}
    private void marginAdd(LinearLayout target,View child,int left,int top,int right,int bottom){LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2);params.setMargins(dp(left),dp(top),dp(right),dp(bottom));target.addView(child,params);}
    private LinearLayout.LayoutParams lp(int width,int height){return new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height));}
    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private static boolean containsID(List<ModelStore.Model> models,String id){for(ModelStore.Model model:models)if(str(model.id).equals(id))return true;return false;}
    private static String str(String value){return value==null?"":value;}
    private static boolean empty(String value){return value==null||value.trim().isEmpty();}
    private static String safeError(Exception error,String secret){String text=error.getMessage()==null?"请求未能完成，请稍后重试。":error.getMessage();if(secret!=null&&!secret.isEmpty())text=text.replace(secret,"[密钥已隐藏]");return text.length()>400?text.substring(0,400):text;}
    private static TextWatcher watcher(Runnable action){return new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){action.run();}public void afterTextChanged(Editable text){}};}
}
